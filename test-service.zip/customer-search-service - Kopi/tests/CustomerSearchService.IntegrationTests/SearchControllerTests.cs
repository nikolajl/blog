﻿using CustomerSearchService.Controllers.Responses;
using CustomerSearchService.Models;
using CustomerSearchService.Services.Interfaces;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using UserServiceClient.Model;
using Xunit;

namespace CustomerSearchService.IntegrationTests;

public class SearchControllerTests
{
    private const string reason = "Test Fails on CI, set this const to null locally to run";

    [Fact(Skip = "WIP, fails on CI")]
    public async Task Search_ShouldFindSsoIdMockBackend()
    {
        var guid = Guid.NewGuid();
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.LookupSsoUserBySsoId(guid.ToString())).ReturnsAsync(new SsoUser { Email = "test@eksempel.dk", SsoId = guid });

        var application = new WebApplicationFactory<Program>()
            .WithWebHostBuilder(builder =>
            {
                builder.ConfigureTestServices(services =>
                {
                    // Disable Authentication.
                    services.RemoveAll<Microsoft.AspNetCore.Authorization.Policy.IPolicyEvaluator>();
                    services.AddSingleton<Microsoft.AspNetCore.Authorization.Policy.IPolicyEvaluator, DisableAuthenticationPolicyEvaluator>();

                    // Add mocks
                    services.AddScoped<ISsoService>(s => ssoService.Object);
                });
            });

        var client = application.CreateClient();
        var response = await client.GetAsync($"/api/v1/Search?brands=JyllandsPosten&input={guid}");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var json = await response.Content.ReadAsStringAsync();
        var result = JsonConvert.DeserializeObject<List<SearchResponse>>(json);

        Assert.Single(result);
    }
}
