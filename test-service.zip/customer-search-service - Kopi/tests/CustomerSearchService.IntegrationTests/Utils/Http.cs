﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CustomerSearchService.IntegrationTests.Utils
{
    internal static class Http
    {
        public static async Task<T> GetJson<T>(HttpClient client, string url, HttpStatusCode expectedResponse = HttpStatusCode.OK)
        {
            var response = await client.GetAsync(url);

            if (expectedResponse != response.StatusCode) throw new InvalidOperationException($"Expected status: {expectedResponse}. Got: {response.StatusCode}");

            var json = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<T>(json);
        }
    }
}
