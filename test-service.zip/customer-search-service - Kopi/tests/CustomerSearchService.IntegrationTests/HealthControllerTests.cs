﻿using CustomerSearchService.Models;
using CustomerSearchService.Services.Interfaces;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace CustomerSearchService.IntegrationTests;

public class HealthControllerTests
{
    [Fact(Skip = "WIP, fails on CI")]
    public async Task Health_ShouldReturn200StatusCode()
    {
        var application = new WebApplicationFactory<Program>();

        var client = application.CreateClient();

        var response = await client.GetAsync("/api/Health");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var json = await response.Content.ReadAsStringAsync();
        var data = JsonConvert.DeserializeObject<List<string>>(json);

        Assert.Equal(new List<string> { "I AM ALIVE" }, data);
    }
}
