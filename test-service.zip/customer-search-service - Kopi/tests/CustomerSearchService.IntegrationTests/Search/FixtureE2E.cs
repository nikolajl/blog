using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using CustomerSearchService.Models;
using Microsoft.AspNetCore.Mvc.Testing;
using Newtonsoft.Json;
using Xunit;

namespace CustomerSearchService.IntegrationTests.Search;

public class FixtureE2E : IAsyncLifetime
{
    public readonly HttpClient client;

    public FixtureE2E()
    {
        var application = new WebApplicationFactory<Program>();
        client = application.CreateClient();
        // continues in InitializeAsync()
    }

    protected async Task<string> GetToken(string clientId, string clientSecret)
    {
        var config = new JpPolAuth.JpPolAuthConfiguration(
            basePath: "https://authtest.medielogin.dk",
            clientId: clientId,
            clientSecret,
            serviceName: "customer-search-service-test"
        );

        var authProxy = new JpPolAuth.Client.JpPolAuthProxy(config);
        return await authProxy.GetBearerToken("CSS-Read");
    }

    public async Task InitializeAsync()
    {
        var token = await GetToken(
            // Secret values; do not put in the code.
            clientId: Environment.GetEnvironmentVariable("AUTH_CLIENT_ID") ?? "fb4860d9241240b7a5b32d1a2752f143",
            clientSecret: Environment.GetEnvironmentVariable("AUTH_CLIENT_SECRET") ?? "IaUaUi1aMq0bgcSSdTuLRfDDzcJYuEgY0OFvcfk6qViEc4eRAqsyDdEcHQIikgNF"
        );

        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    public Task DisposeAsync()
    {
        // Nothing to clean up, yet.
        return Task.CompletedTask;
    }
}
