using System.Collections.Generic;
using System.Threading.Tasks;
using CustomerSearchService.Controllers.Responses;
using CustomerSearchService.IntegrationTests.Utils;
using Xunit;

namespace CustomerSearchService.IntegrationTests.Search;

public class SearchControllerE2ETests : IClassFixture<FixtureE2E>
{
    private const string reason = null;//"Test Fails on CI, set this const to null when running tests locally";
    private readonly FixtureE2E fixture;
    public SearchControllerE2ETests(FixtureE2E fixture)
    {
        this.fixture = fixture;
    }

    [Fact(Skip = reason)]
    public async Task Search_ShouldFindSsoId()
    {
        var input = "f25b909f-5ec3-455d-b87f-53613a390b74";
        var brands = "JyllandsPosten,Finans";

        var result = await Http.GetJson<List<SearchResponse>>(fixture.client, $"/api/v1/Search?brands={brands}&input={input}");

        Assert.Single(result);
        Assert.Equal("findmig@jp.dk", result[0].Email);
        Assert.Equal("Find Mig Hansen", result[0].Name);
        Assert.Equal(input, result[0].SsoId.ToString());
    }

    [Theory(Skip = reason)]
    [InlineData("f25b909f-5ec3-455d-b87f-53613a390b74", "JyllandsPosten,Finans", "JP")] // SsoId
    [InlineData("1f27b09e-49ae-4d41-9675-4b1505962b47", "JyllandsPosten,Finans", "JP")] // SsoId
    [InlineData("ABN00115157", "JyllandsPosten,Finans", "JP")] // SubscriptionNumber
    [InlineData("K13367925", "JyllandsPosten,Finans", "JP")] // AccountNumber
    [InlineData("FAK06550911", "JyllandsPosten,Finans", "JP")] // InvoiceNumber
    [InlineData("P-01242941", "JyllandsPosten,Finans", "JP")] // PaymentNumber
    [InlineData("MK-0100142735", "JyllandsPosten,Finans", "JP")] // OrderNumber
    [InlineData("WR-0100028054", "JyllandsPosten,Finans", "JP")] // OrderNumber
    public async Task Search_ShouldFindSingleResult(string input, string brands, string publicationCodes)
    {
        var result = await Http.GetJson<List<SearchResponse>>(fixture.client, $"/api/v1/Search?publicationCodes={publicationCodes}&brands={brands}&input={input}");

        Assert.Single(result);
    }

    [Theory(Skip = reason)]
    [InlineData("findmig@jp.dk", "JyllandsPosten,Finans", "JP")] // Email
    [InlineData("jp.dk", "JyllandsPosten,Finans", "JP")] // Domain
    [InlineData("98765432", "JyllandsPosten,Finans", "JP")] // PhoneNumber
    [InlineData("+45 98765432", "JyllandsPosten,Finans", "JP")] // PhoneNumber
    [InlineData("+1 23456789", "JyllandsPosten,Finans", "JP")] // PhoneNumber
    [InlineData("DK11111111", "JyllandsPosten,Finans", "JP")] // CVR
    [InlineData("Boring", "JyllandsPosten,Finans", "JP")] // Name (company name)
    [InlineData("Elon Muxk", "JyllandsPosten,Finans", "JP")] // Name (company att: name, fuzzy match)
    [InlineData("Find mig", "JyllandsPosten,Finans", "JP")] // Name (consumer, fuzzy match)
    [InlineData("EAN6870748636118", "JyllandsPosten,Finans", "JP")] // EAN
    public async Task Search_ShouldFindMultipleResults(string input, string brands, string publicationCodes)
    {
        var result = await Http.GetJson<List<SearchResponse>>(fixture.client, $"/api/v1/Search?publicationCodes={publicationCodes}&brands={brands}&input={input}");

        Assert.True(result.Count > 1);
    }

    [Theory(Skip = reason)]
    //[InlineData("f25b909f-5ec3-455d-b87f-53613a390b74", "Politiken", "POL")] // SsoId
    [InlineData("ABN00115157", "Politiken", "POL")] // SubscriptionNumber
    [InlineData("K13367925", "Politiken", "POL")] // AccountNumber
    [InlineData("FAK06550911", "Politiken", "POL")] // InvoiceNumber
    [InlineData("P-01242941", "Politiken", "POL")] // PaymentNumber
    //[InlineData("MK-0100142735", "Politiken", "POL")] // OrderNumber
    //[InlineData("WR-0100028054", "Politiken", "POL")] // OrderNumber
    //[InlineData("findmig@jp.dk", "Politiken", "POL")] // Email
    //[InlineData("98765432", "Politiken", "POL")] // PhoneNumber
    //[InlineData("+45 98765432", "Politiken", "POL")] // PhoneNumber
    //[InlineData("+1 23456789", "Politiken", "POL")] // PhoneNumber
    [InlineData("DK11111111", "Politiken", "POL")] // CVR
    [InlineData("Boring", "Politiken", "POL")] // Name (company name)
    //[InlineData("Elon Muxk", "Politiken", "POL")] // Name (company att: name, fuzzy match)
    //[InlineData("Find mig", "Politiken", "POL")] // Name (consumer, fuzzy match)
    [InlineData("EAN6870748636118", "Politiken", "POL")] // EAN
    public async Task Search_ShouldFindNoResults_WhenBrandDoesNotMatch(string input, string brands, string publicationCodes)
    {
        var result = await Http.GetJson<List<SearchResponse>>(fixture.client, $"/api/v1/Search?publicationCodes={publicationCodes}&brands={brands}&input={input}");

        Assert.Empty(result);
    }
}
