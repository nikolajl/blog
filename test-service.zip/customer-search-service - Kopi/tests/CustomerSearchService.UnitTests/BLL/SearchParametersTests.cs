﻿using Xunit;
using CustomerSearchService.BLL;

namespace CustomerSearchService.UnitTests.BLL;

public class SearchParametersTests
{
    [Fact]
    public void InputIsEmail_ShouldReturnTrue_WhenInputMatchesEmail()
    {
        //Arrange
        var searchParameters = new SearchParameters("test@eksempel.dk", "JyllandsPosten");

        //Assert
        Assert.True(searchParameters.IsInputEmail());
        Assert.False(searchParameters.IsInputGuid());
    }

    [Fact]
    public void InputIsGuid_ShouldReturnTrue_WhenInputMatchesGuid()
    {
        //Arrange
        var searchParameters = new SearchParameters("3fa85f64-5717-4562-b3fc-2c963f66afa6", "JyllandsPosten");

        //Assert
        Assert.True(searchParameters.IsInputGuid());
        Assert.False(searchParameters.IsInputEmail());
    }
}
