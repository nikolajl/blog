﻿using Xunit;
using Moq;
using System;
using CustomerSearchService.BLL;
using CustomerSearchService.BLL.SearchCommands;
using CustomerSearchService.Services.Interfaces;
using System.Collections.Generic;
using CustomerSearchService.Models;
using ZuoraClient.NET.RestApi.Model.AccountApi;
using System.Linq;
using UserServiceClient.Model;

namespace CustomerSearchService.UnitTests.BLL.SearchCommands;

public class SearchByNameTests
{
    [Fact]
    public async void Execute_ShouldReturn0Results_WhenNotFound()
    {
        var searchParameters = new SearchParameters("Navn der ikke findes", "JyllandsPosten");

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.GetMatchingUsersByName(searchParameters.Input)).ReturnsAsync(Enumerable.Empty<Guid>());

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsForName(searchParameters.Input)).ReturnsAsync(new List<ZuoraContact>());

        var distributionService = new Mock<IDistributionService>(MockBehavior.Strict);
        foreach (var namepart in searchParameters.Input.Split(' '))
        {
            distributionService.Setup(x => x.DeprecatedSearchByName(It.IsAny<List<string>>(), namepart)).ReturnsAsync(new List<DistClient.NET.Model.Distribution.Subscriber>());
        }

        // Act
        var command = new SearchByName(ssoService.Object, zuoraService.Object, distributionService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public async void Execute_ShouldReturn3Result_WhenNameIsFoundOnceInAllDatasources()
    {
        var searchParameters = new SearchParameters("Navn der findes", "JyllandsPosten");
        var expectedUser = new SsoUser
        {
            SsoId = Guid.NewGuid(),
            Firstname = "Navn der",
            Lastname = "findes"
        };

        var expectedContactList = new List<ZuoraContact>()
        {
            new ZuoraContact
            {
                AccountId = "account-test-id",
                PersonalEmail = "test@eksempel.dk",
                FirstName = "Navn der",
                LastName = "findes",
            }
        };

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.GetMatchingUsersByName(searchParameters.Input)).ReturnsAsync(new List<Guid>() { expectedUser.SsoId });
        ssoService.Setup(x => x.GetSsoUser(expectedUser.SsoId)).ReturnsAsync(expectedUser);

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsForName(searchParameters.Input)).ReturnsAsync(expectedContactList);
        zuoraService.Setup(x => x.GetAccountsForContacts(expectedContactList)).ReturnsAsync(new List<RealZuoraAccount>() {
            new RealZuoraAccount
            {
                Id = "account-test-id",
                SsoId__c = expectedUser.SsoId.ToString(),
                Brand__c = "JyllandsPosten"
            }
        });

        zuoraService.Setup(x => x.GetSubscriptionsByAccountId("account-test-id")).ReturnsAsync(new List<SubscriptionCompact>
        {
            new SubscriptionCompact {
                Name = "ABN00112233"
            }
        });

        // TODO: Currently, Search service returns 1 result per partial match, i.e. 3 matches if search input is 3 words.
        // ... for this reason this test mocks 0 search results from distribution
        var distributionService = new Mock<IDistributionService>(MockBehavior.Strict);
        distributionService.Setup(x => x.DeprecatedSearchByName(It.IsAny<List<string>>(), "Navn")).ReturnsAsync(new List<DistClient.NET.Model.Distribution.Subscriber>());
        distributionService.Setup(x => x.DeprecatedSearchByName(It.IsAny<List<string>>(), "der")).ReturnsAsync(new List<DistClient.NET.Model.Distribution.Subscriber>());
        distributionService.Setup(x => x.DeprecatedSearchByName(It.IsAny<List<string>>(), "findes")).ReturnsAsync(new List<DistClient.NET.Model.Distribution.Subscriber>());

        // Act 
        var command = new SearchByName(ssoService.Object, zuoraService.Object, distributionService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Equal(2, result.Count);
    }
}
