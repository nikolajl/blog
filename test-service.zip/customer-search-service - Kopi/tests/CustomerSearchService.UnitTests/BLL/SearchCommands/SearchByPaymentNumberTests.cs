﻿using CustomerSearchService.BLL;
using CustomerSearchService.BLL.SearchCommands;
using CustomerSearchService.Models;
using CustomerSearchService.Services.Interfaces;
using Moq;
using System;
using Xunit;
using ZuoraClient.NET.RestApi.Model.AccountApi;

namespace CustomerSearchService.UnitTests.BLL.SearchCommands;

public class SearchByPaymentNumberTests
{
    [Fact]
    public async void Execute_ShouldReturn0Results_WhenNotFound()
    {
        var paymentNumber = "P-00030573";
        var searchParameters = new SearchParameters(paymentNumber, "JyllandsPosten");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetPaymentByPaymentNumber(searchParameters.Input)).ReturnsAsync((ZuoraPayment?)null);

        // Act 
        var command = new SearchByPaymentNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public async void Execute_ShouldReturn1Result_WhenPaymentIsFound()
    {
        var paymentNumber = "P-00030573";
        var searchParameters = new SearchParameters(paymentNumber, "JyllandsPosten");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetPaymentByPaymentNumber(searchParameters.Input)).ReturnsAsync(new ZuoraPayment
        {
            Id = "fake-payment-id",
            AccountId = "fake-account-id",
            Amount = 42,
            PaymentNumber = paymentNumber,
        });
        zuoraService.Setup(x => x.GetInvoicePaymentByPaymentNumber("fake-payment-id")).ReturnsAsync(new ZuoraInvoicePayment
        {
            Id = "fake-invoice-payment-id",
            InvoiceId = "fake-inovice-id",
            PaymentId = "fake-payment-id",
        });

        zuoraService.Setup(x => x.GetAccount("fake-account-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo
            {
                Id = "fakeid",
                SsoIdC = Guid.NewGuid().ToString(),
                BrandC = "JyllandsPosten",
                AccountNumber = "fake-account-id"
            }
        });

        // Act 
        var command = new SearchByPaymentNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);
    }
    [Fact]

    public async void Execute_ShouldReturn0Results_WhenPaymentIsFound_AndBrandIsDifferent()
    {
        var paymentNumber = "P-00030573";
        var searchParameters = new SearchParameters(paymentNumber, "EkstraBladet");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetPaymentByPaymentNumber(searchParameters.Input)).ReturnsAsync(new ZuoraPayment
        {
            Id = "fake-payment-id",
            AccountId = "fake-account-id",
            Amount = 42,
            PaymentNumber = paymentNumber,
        });
        zuoraService.Setup(x => x.GetInvoicePaymentByPaymentNumber("fake-payment-id")).ReturnsAsync(new ZuoraInvoicePayment
        {
            Id = "fake-invoice-payment-id",
            InvoiceId = "fake-inovice-id",
            PaymentId = "fake-payment-id",
        });

        zuoraService.Setup(x => x.GetAccount("fake-account-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo
            {
                Id = "fakeid",
                SsoIdC = Guid.NewGuid().ToString(),
                BrandC = "JyllandsPosten",
                AccountNumber = "fake-account-id"
            }
        });

        // Act 
        var command = new SearchByPaymentNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }
}
