﻿using Xunit;
using Moq;
using System;
using CustomerSearchService.BLL;
using CustomerSearchService.BLL.SearchCommands;
using CustomerSearchService.Services.Interfaces;
using System.Collections.Generic;
using CustomerSearchService.Models;
using ZuoraClient.NET.RestApi.Model.AccountApi;
using UserServiceClient.Model;

namespace CustomerSearchService.UnitTests.BLL.SearchCommands;

public class SearchByEmailTests
{
    [Fact]
    public async void Execute_ShouldReturn0Results_WhenNotFound()
    {
        var searchParameters = new SearchParameters("test@eksempel.dk", "JyllandsPosten");

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.LookupSsoUserByEmail(It.IsAny<string>())).ReturnsAsync((SsoUser?)null);

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsFromEmailAsync(It.IsAny<string>())).ReturnsAsync(new List<ZuoraContact>());

        var subscriptionRelationService = new Mock<ISubscriptionRelationService>(MockBehavior.Strict);
        subscriptionRelationService.Setup(x => x.GetSubscriptionsBySsoId(It.IsAny<Guid>()))
            .ReturnsAsync(new List<string>());

        var accessAgreementService = new Mock<IAccessAgreementService>(MockBehavior.Strict);
        accessAgreementService.Setup(x => x.GetAccessAgreementsByEmail(It.IsAny<string>()))
            .ReturnsAsync(new List<AccessAgreement>());

        // Act 
        var command = new SearchByEmail(ssoService.Object, zuoraService.Object, subscriptionRelationService.Object, accessAgreementService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public async void Execute_ShouldReturn4Results_WhenTheEmailIsFoundOnceInAllDataSources()
    {
        var searchParameters = new SearchParameters("test@eksempel.dk", "JyllandsPosten");
        var ssoId = Guid.NewGuid();
        var accountId = "K932485293";
        var accountIdTwo = "K234958598";

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.LookupSsoUserByEmail(It.IsAny<string>())).ReturnsAsync(new SsoUser { Email = "test@eksempel.dk", SsoId = ssoId });

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsFromEmailAsync(It.IsAny<string>())).ReturnsAsync(new List<ZuoraContact>()
        {
            new ZuoraContact
            {
                PersonalEmail = "test@eksempel.dk",
                AccountId = "account-test-id",
            }
        });
        zuoraService.Setup(x => x.GetAccount("account-test-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo { BrandC = "JyllandsPosten", SsoIdC = ssoId.ToString() },
            BillToContact = new Contact
            {
                FirstName = "Fornavn",
                LastName = "Efternavn"
            }
        });

        zuoraService.Setup(x => x.GetSubscriptionsByAccountId("account-test-id")).ReturnsAsync(new List<SubscriptionCompact>
        {
            new SubscriptionCompact {
                Name = "Subscription"
            } 
        });

        zuoraService.Setup(x => x.GetSubscriptionBySubscriptionNumber(It.IsAny<string>())).ReturnsAsync(
            new SubscriptionCompact()
            {
                AccountId = accountId,
                Name = "ABN3284756",
                Status = "Active"
            });

        zuoraService.Setup(x => x.GetAccount(accountId)).ReturnsAsync(new Account()
        {
            BasicInfo = new AccountBasicInfo()
            {
                AccountNumber = accountId,
                BrandC = "JyllandsPosten",
                SsoIdC = Guid.NewGuid().ToString(),
            },
            BillToContact = new Contact()
            {
                FirstName = "Test",
                LastName = "McTest"
            }
        });

        var subscriptionRelationService = new Mock<ISubscriptionRelationService>(MockBehavior.Strict);
        subscriptionRelationService.Setup(x => x.GetSubscriptionsBySsoId(It.IsAny<Guid>()))
            .ReturnsAsync(new List<string>()
            {
                accountId
            });

        var accessAgreementService = new Mock<IAccessAgreementService>(MockBehavior.Strict);
        accessAgreementService.Setup(x => x.GetAccessAgreementsByEmail(It.IsAny<string>()))
            .ReturnsAsync(new List<AccessAgreement>()
            {
                new AccessAgreement()
                {
                    AccountNumber = accountIdTwo,
                    Id = 3249857
                }
            });

        zuoraService.Setup(x => x.GetAccount(accountIdTwo)).ReturnsAsync(new Account()
        {
            BasicInfo = new AccountBasicInfo()
            {
                AccountNumber = accountIdTwo,
                BrandC = "JyllandsPosten",
                SsoIdC = Guid.NewGuid().ToString()
            },
            BillToContact = new Contact()
            {
                FirstName = "Test2",
                LastName = "McTest2"
            }
        });

        // Act 
        var command = new SearchByEmail(ssoService.Object, zuoraService.Object, subscriptionRelationService.Object, accessAgreementService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Equal(4, result.Count);
    }

    [Fact]
    public async void Execute_ShouldReturn1Result_WhenTheEmailIsFoundOnlyInSsoDataSource() {
        var searchParameters = new SearchParameters("test@eksempel.dk", "JyllandsPosten");
        var ssoId = Guid.NewGuid();

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.LookupSsoUserByEmail(It.IsAny<string>())).ReturnsAsync(new SsoUser { Email = "test@eksempel.dk", SsoId = ssoId });

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsFromEmailAsync(It.IsAny<string>())).ReturnsAsync(new List<ZuoraContact>());

        var subscriptionRelationService = new Mock<ISubscriptionRelationService>(MockBehavior.Strict);
        subscriptionRelationService.Setup(x => x.GetSubscriptionsBySsoId(It.IsAny<Guid>()))
            .ReturnsAsync(new List<string>());

        var accessAgreementService = new Mock<IAccessAgreementService>(MockBehavior.Strict);
        accessAgreementService.Setup(x => x.GetAccessAgreementsByEmail(It.IsAny<string>()))
            .ReturnsAsync(new List<AccessAgreement>());

        // Act 
        var command = new SearchByEmail(ssoService.Object, zuoraService.Object, subscriptionRelationService.Object, accessAgreementService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);
    }


    [Fact]
    public async void Execute_ShouldReturn1Result_WhenTheEmailIsFoundInZuoraWithDifferentBrand() 
    {
        var searchParameters = new SearchParameters("test@eksempel.dk", "JyllandsPosten");
        var ssoId = Guid.NewGuid();

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.LookupSsoUserByEmail(It.IsAny<string>())).ReturnsAsync(new SsoUser { Email = "test@eksempel.dk", SsoId = ssoId });

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsFromEmailAsync(It.IsAny<string>())).ReturnsAsync(new List<ZuoraContact>()
        {
            new ZuoraContact
            {
                PersonalEmail = "test@eksempel.dk",
                AccountId = "account-test-id",
            }
        });
        zuoraService.Setup(x => x.GetAccount("account-test-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo { BrandC = "EkstraBladet", SsoIdC = ssoId.ToString() },
            BillToContact = new Contact
            {
                FirstName = "Fornavn",
                LastName = "Efternavn"
            }
        });

        var subscriptionRelationService = new Mock<ISubscriptionRelationService>(MockBehavior.Strict);
        subscriptionRelationService.Setup(x => x.GetSubscriptionsBySsoId(It.IsAny<Guid>()))
            .ReturnsAsync(new List<string>());

        var accessAgreementService = new Mock<IAccessAgreementService>(MockBehavior.Strict);
        accessAgreementService.Setup(x => x.GetAccessAgreementsByEmail(It.IsAny<string>()))
            .ReturnsAsync(new List<AccessAgreement>());


        // Act 
        var command = new SearchByEmail(ssoService.Object, zuoraService.Object, subscriptionRelationService.Object, accessAgreementService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);
    }

    [Fact] 
    // Since the call to SRS are relying on the SSO call, we can never have a result only exist in SRS
    public async void Execute_ShouldReturn2Results_WhenTheEmailIsFoundInSrsAndSsoDataSource()
    {
        var searchParameters = new SearchParameters("test@eksempel.dk", "JyllandsPosten");
        var ssoId = Guid.NewGuid();
        const string accountNumber = "K932485293";

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.LookupSsoUserByEmail(It.IsAny<string>())).ReturnsAsync(new SsoUser { Email = "test@eksempel.dk", SsoId = ssoId });

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsFromEmailAsync(It.IsAny<string>())).ReturnsAsync(new List<ZuoraContact>());

        zuoraService.Setup(x => x.GetSubscriptionBySubscriptionNumber(It.IsAny<string>())).ReturnsAsync(
            new SubscriptionCompact()
            {
                AccountId = accountNumber,
                Name = "ABN3284756",
                Status = "Active"
            });

        zuoraService.Setup(x => x.GetAccount(accountNumber)).ReturnsAsync(new Account()
        {
            BasicInfo = new AccountBasicInfo()
            {
                AccountNumber = accountNumber,
                BrandC = "JyllandsPosten",
                SsoIdC = Guid.NewGuid().ToString(),
            },
            BillToContact = new Contact()
            {
                FirstName = "Test",
                LastName = "McTest"
            }
        });

        var subscriptionRelationService = new Mock<ISubscriptionRelationService>(MockBehavior.Strict);
        subscriptionRelationService.Setup(x => x.GetSubscriptionsBySsoId(It.IsAny<Guid>()))
            .ReturnsAsync(new List<string>()
            {
                accountNumber
            });

        var accessAgreementService = new Mock<IAccessAgreementService>(MockBehavior.Strict);
        accessAgreementService.Setup(x => x.GetAccessAgreementsByEmail(It.IsAny<string>()))
            .ReturnsAsync(new List<AccessAgreement>());

        // Act 
        var command = new SearchByEmail(ssoService.Object, zuoraService.Object, subscriptionRelationService.Object, accessAgreementService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Equal(2, result.Count);
    }

    [Fact]
    public async void Execute_ShouldReturn1Result_WhenTheEmailIsFoundOnlyInAasDataSource()
    {
        var searchParameters = new SearchParameters("test@eksempel.dk", "JyllandsPosten");
        var ssoId = Guid.NewGuid();
        var accountNumber = "K23987458";

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.LookupSsoUserByEmail(It.IsAny<string>())).ReturnsAsync((SsoUser?)null);

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsFromEmailAsync(It.IsAny<string>())).ReturnsAsync(new List<ZuoraContact>());

        var subscriptionRelationService = new Mock<ISubscriptionRelationService>(MockBehavior.Strict);
        subscriptionRelationService.Setup(x => x.GetSubscriptionsBySsoId(It.IsAny<Guid>()))
            .ReturnsAsync(new List<string>());

        var accessAgreementService = new Mock<IAccessAgreementService>(MockBehavior.Strict);
        accessAgreementService.Setup(x => x.GetAccessAgreementsByEmail(It.IsAny<string>()))
            .ReturnsAsync(new List<AccessAgreement>()
            {
                new AccessAgreement()
                {
                    AccountNumber = accountNumber,
                    Id = 1832475
                }
            });

        zuoraService.Setup(x => x.GetAccount(accountNumber)).ReturnsAsync(new Account()
        {
            BasicInfo = new AccountBasicInfo()
            {
                AccountNumber = accountNumber,
                BrandC = "JyllandsPosten",
                SsoIdC = Guid.NewGuid().ToString(),
            },
            BillToContact = new Contact()
            {
                FirstName = "Test",
                LastName = "McTest"
            }
        });

        // Act 
        var command = new SearchByEmail(ssoService.Object, zuoraService.Object, subscriptionRelationService.Object, accessAgreementService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);
    }

    // TODO: Test brands filter
}
