﻿using Xunit;
using Moq;
using System;
using CustomerSearchService.BLL;
using CustomerSearchService.BLL.SearchCommands;
using CustomerSearchService.Services.Interfaces;
using System.Collections.Generic;
using CustomerSearchService.Models;
using ZuoraClient.NET.RestApi.Model.AccountApi;
using System.Linq;

namespace CustomerSearchService.UnitTests.BLL.SearchCommands;

public class SearchByCvrTests
{
    [Fact]
    public async void Execute_ShouldReturn0Results_WhenNotFound()
    {
        var searchParameters = new SearchParameters("DK11223344", "JyllandsPosten");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsByCvr("11223344")).ReturnsAsync(new List<ZuoraContact>());

        // Act 
        var command = new SearchByCvr(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public async void Execute_ShouldReturn1Result_WhenPhoneNumberIsFoundOnceInBothDatasources()
    {
        var searchParameters = new SearchParameters("DK11223344", "JyllandsPosten");

        // Arrange
        var ssoId = Guid.NewGuid().ToString();
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsByCvr("11223344")).ReturnsAsync(new List<ZuoraContact>()
        {
            new ZuoraContact
            {
                PersonalEmail = "test@eksempel.dk",
                CompanyName__c = "Firmanavn",
                AccountId = "account-test-id",
            }
        });

        zuoraService.Setup(x => x.GetAccount("account-test-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo { BrandC = "JyllandsPosten", SsoIdC = ssoId },
            BillToContact = new Contact
            {
                CompanyNameC = "Firmanavn",
            }
        });

        zuoraService.Setup(x => x.GetSubscriptionsByAccountId("account-test-id")).ReturnsAsync(new List<SubscriptionCompact>
        {
            new SubscriptionCompact {
                Name = "Subscription"
            }
        });

        // Act 
        var command = new SearchByCvr(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);
    }


    [Fact]
    public async void Execute_ShouldReturn0Results_WhenAccountIsFound_AndBrandIsDifferent()
    {
        var searchParameters = new SearchParameters("DK11223344", "Politiken");

        // Arrange
        var ssoId = Guid.NewGuid().ToString();
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsByCvr("11223344")).ReturnsAsync(new List<ZuoraContact>()
        {
            new ZuoraContact
            {
                PersonalEmail = "test@eksempel.dk",
                CompanyName__c = "Firmanavn",
                AccountId = "account-test-id",
            }
        });

        zuoraService.Setup(x => x.GetAccount("account-test-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo { BrandC = "JyllandsPosten", SsoIdC = ssoId },
            BillToContact = new Contact
            {
                CompanyNameC = "Firmanavn",
            }
        });

        zuoraService.Setup(x => x.GetSubscriptionsByAccountId("account-test-id")).ReturnsAsync(new List<SubscriptionCompact>
        {
            new SubscriptionCompact {
                Name = "Subscription"
            }
        });

        // Act 
        var command = new SearchByCvr(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }
}
