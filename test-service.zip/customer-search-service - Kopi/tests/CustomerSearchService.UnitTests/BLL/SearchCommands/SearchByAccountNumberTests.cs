﻿using CustomerSearchService.BLL;
using CustomerSearchService.BLL.SearchCommands;
using CustomerSearchService.Services.Interfaces;
using Moq;
using System;
using System.Collections.Generic;
using CustomerSearchService.Models;
using Xunit;
using ZuoraClient.NET.RestApi.Model.AccountApi;

namespace CustomerSearchService.UnitTests.BLL.SearchCommands;

public class SearchByAccountNumberTests
{
    [Fact]
    public async void Execute_ShouldReturn0Results_WhenNotFound()
    {
        var accountNumber = "K12345678";
        var searchParameters = new SearchParameters(accountNumber, "JyllandsPosten");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetAccount(searchParameters.Input)).ReturnsAsync((Account?)null);

        // Act 
        var command = new SearchByAccountNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public async void Execute_ShouldReturn1Result_WhenAccountIsFound()
    {
        var accountNumber = "K12345678";
        var searchParameters = new SearchParameters(accountNumber, "JyllandsPosten");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetAccount(searchParameters.Input)).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo
            {
                Id = "fakeid",
                SsoIdC = Guid.NewGuid().ToString(),
                BrandC = "JyllandsPosten",
                AccountNumber = accountNumber
            },
            BillToContact = new Contact
            {
                FirstName = "Finn",
                LastName = "Holger",
                PersonalEmail = "finn@mig.dk"
            }
        });

        zuoraService.Setup(x => x.GetSubscriptionsByAccountId(searchParameters.Input)).ReturnsAsync(new List<SubscriptionCompact>());

        // Act 
        var command = new SearchByAccountNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);
    }

    [Fact]
    public async void Execute_ShouldReturn0Results_WhenAccountIsFound_AndBrandIsDifferent()
    {
        var accountNumber = "K12345678";
        var searchParameters = new SearchParameters(accountNumber, "EkstraBladet");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetAccount(searchParameters.Input)).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo
            {
                Id = "internalid",
                SsoIdC = Guid.NewGuid().ToString(),
                BrandC = "JyllandsPosten",
                AccountNumber = accountNumber
            }
        });

        // Act 
        var command = new SearchByAccountNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }
}
