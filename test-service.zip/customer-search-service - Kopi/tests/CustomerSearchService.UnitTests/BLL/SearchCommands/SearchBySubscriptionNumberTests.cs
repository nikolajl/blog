﻿using CustomerSearchService.BLL;
using CustomerSearchService.BLL.SearchCommands;
using CustomerSearchService.Models;
using CustomerSearchService.Services.Interfaces;
using Moq;
using System;
using Xunit;
using ZuoraClient.NET.RestApi.Model.AccountApi;

namespace CustomerSearchService.UnitTests.BLL.SearchCommands;

public class SearchBySubscriptionNumberTests
{
    [Fact]
    public async void Execute_ShouldReturn0Results_WhenNotFound()
    {
        var subscriptionNumber = "ABN10115157";
        var searchParameters = new SearchParameters(subscriptionNumber, "JyllandsPosten");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetSubscriptionBySubscriptionNumber(searchParameters.Input)).ReturnsAsync((SubscriptionCompact?)null);

        // Act 
        var command = new SearchBySubscriptionNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public async void Execute_ShouldReturn1Result_WhenSubscriptionIsFound()
    {
        var subscriptionNumber = "ABN00115157";
        var searchParameters = new SearchParameters(subscriptionNumber, "JyllandsPosten");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetSubscriptionBySubscriptionNumber(searchParameters.Input)).ReturnsAsync(new SubscriptionCompact
        {
            AccountId = "fake-account-id",
            Name = subscriptionNumber
        });

        zuoraService.Setup(x => x.GetAccount("fake-account-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo
            {
                Id = "fake-account-id",
                SsoIdC = Guid.NewGuid().ToString(),
                BrandC = "JyllandsPosten",
                AccountNumber = "K00112233"
            }
        });

        // Act 
        var command = new SearchBySubscriptionNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);
    }
    [Fact]

    public async void Execute_ShouldReturn0Results_WhenAccountIsFound_AndBrandIsDifferent()
    {
        var subscriptionNumber = "ABN00115157";
        var searchParameters = new SearchParameters(subscriptionNumber, "Politiken");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetSubscriptionBySubscriptionNumber(searchParameters.Input)).ReturnsAsync(new SubscriptionCompact
        {
            AccountId = "fake-account-id",
            Name = subscriptionNumber
        });

        zuoraService.Setup(x => x.GetAccount("fake-account-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo
            {
                Id = "fake-account-id",
                SsoIdC = Guid.NewGuid().ToString(),
                BrandC = "JyllandsPosten",
                AccountNumber = "K00112233"
            }
        });

        // Act 
        var command = new SearchBySubscriptionNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }
}
