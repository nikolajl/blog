﻿using CustomerSearchService.BLL;
using CustomerSearchService.BLL.SearchCommands;
using CustomerSearchService.Models;
using CustomerSearchService.Services.Interfaces;
using Moq;
using System;
using UserServiceClient.Model;
using Xunit;

namespace CustomerSearchService.UnitTests.BLL.SearchCommands;

public class SearchBySsoIdTests
{
    [Fact]
    public async void Execute_ShouldReturn0Results_WhenNotFound()
    {
        var guid = Guid.NewGuid();
        var searchParameters = new SearchParameters(guid.ToString(), "JyllandsPosten");

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.LookupSsoUserBySsoId(searchParameters.Input)).ReturnsAsync((SsoUser?)null);

        // Act 
        var command = new SearchBySsoId(ssoService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public async void Execute_ShouldReturn1Result_WhenSsoIdIsFound()
    {
        var guid = Guid.NewGuid();
        var searchParameters = new SearchParameters(guid.ToString(), "JyllandsPosten");

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.LookupSsoUserBySsoId(searchParameters.Input)).ReturnsAsync(new SsoUser { Email = "test@eksempel.dk", SsoId = guid });

        // Act 
        var command = new SearchBySsoId(ssoService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);
    }
}
