﻿using Xunit;
using Moq;
using System;
using CustomerSearchService.BLL;
using CustomerSearchService.BLL.SearchCommands;
using CustomerSearchService.Services.Interfaces;
using System.Collections.Generic;
using CustomerSearchService.Models;
using ZuoraClient.NET.RestApi.Model.AccountApi;
using System.Linq;
using System.Xml.Linq;

namespace CustomerSearchService.UnitTests.BLL.SearchCommands;

public class SearchByPipedriveTests
{
    [Fact]
    public async void Execute_ShouldReturn0Results_WhenNotFound()
    {
        var searchParameters = new SearchParameters("1234567", "JyllandsPosten");

        // Arrange
        var accountRelationService = new Mock<IAccountRelationService>(MockBehavior.Strict);
        accountRelationService.Setup(x => x.SearchByPipedriveId(searchParameters.Input, It.IsAny<string>())).ReturnsAsync(new List<string>());

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        
        // Act 
        var command = new SearchByPipedriveId(accountRelationService.Object, zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public async void Execute_ShouldReturn1Result_When1PipedriveIdIsFound()
    {
        var searchParameters = new SearchParameters("1234567", "JyllandsPosten");
        var expectedPipedriveIdList = new List<string>()
        {
            "K00000001"
        };
        // Arrange
        var accountRelationService = new Mock<IAccountRelationService>(MockBehavior.Strict);
        accountRelationService.Setup(x => x.SearchByPipedriveId(searchParameters.Input, It.IsAny<string>())).ReturnsAsync(expectedPipedriveIdList);
        
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetAccount(It.IsAny<string>())).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo
            {
                Id = "fakeid",
                SsoIdC = Guid.NewGuid().ToString(),
                BrandC = "JyllandsPosten",
                AccountNumber = "K00000001"
            },
            BillToContact = new Contact
            {
                FirstName = "Finn",
                LastName = "Holger",
                PersonalEmail = "finn@mig.dk"
            }
        });
        zuoraService.Setup(x => x.GetSubscriptionsByAccountId(It.IsAny<string>())).ReturnsAsync(new List<SubscriptionCompact>
        {
            new SubscriptionCompact {
                Name = "Subscription"
            }
        });

        // Act 
        var command = new SearchByPipedriveId(accountRelationService.Object, zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);
    }

    [Fact]
    public async void Execute_ShouldReturnMultipleResults_WhenMultiplePipedriveIdsAreFound()
    {
        var searchParameters = new SearchParameters("1234567", "JyllandsPosten");
        var expectedPipedriveIdList = new List<string>()
        {
            "K00000001",
            "K00000002",
            "K00000003"
        };

        // Arrange
        var accountRelationService = new Mock<IAccountRelationService>(MockBehavior.Strict);
        accountRelationService.Setup(x => x.SearchByPipedriveId(searchParameters.Input, It.IsAny<string>())).ReturnsAsync(expectedPipedriveIdList);

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetAccount(It.IsAny<string>())).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo
            {
                Id = "fakeid",
                SsoIdC = Guid.NewGuid().ToString(),
                BrandC = "JyllandsPosten",
                AccountNumber = "K0000000X"
            },
            BillToContact = new Contact
            {
                FirstName = "Finn",
                LastName = "Holger",
                PersonalEmail = "finn@mig.dk"
            }
        });
        zuoraService.Setup(x => x.GetSubscriptionsByAccountId(It.IsAny<string>())).ReturnsAsync(new List<SubscriptionCompact>
        {
            new SubscriptionCompact {
                Name = "Subscription"
            }
        });

        // Act 
        var command = new SearchByPipedriveId(accountRelationService.Object, zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Equal(3, result.Count);
    }
}
