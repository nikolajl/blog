﻿using CustomerSearchService.BLL;
using CustomerSearchService.BLL.SearchCommands;
using CustomerSearchService.Models;
using CustomerSearchService.Services.Interfaces;
using Moq;
using System;
using Xunit;
using ZuoraClient.NET.RestApi.Model.AccountApi;

namespace CustomerSearchService.UnitTests.BLL.SearchCommands;

public class SearchByInvoiceNumberTests
{
    [Fact]
    public async void Execute_ShouldReturn0Results_WhenNotFound()
    {
        var invoiceNumber = "FAK06550911";
        var searchParameters = new SearchParameters(invoiceNumber, "JyllandsPosten");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetInvoice(searchParameters.Input)).ReturnsAsync((ZuoraInvoice?)null);

        // Act 
        var command = new SearchByInvoiceNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public async void Execute_ShouldReturn1Result_WhenInvoiceIsFound()
    {
        var invoiceNumber = "FAK06550911";
        var searchParameters = new SearchParameters(invoiceNumber, "JyllandsPosten");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetInvoice(searchParameters.Input)).ReturnsAsync(new ZuoraInvoice
        {
            Id = "fake-invoice-id",
            AccountId = "fake-account-id",
            Amount = 42,
            InvoiceNumber = invoiceNumber
        });

        zuoraService.Setup(x => x.GetAccount("fake-account-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo
            {
                Id = "fakeid",
                SsoIdC = Guid.NewGuid().ToString(),
                BrandC = "JyllandsPosten",
                AccountNumber = "fake-account-id"
            }
        });

        // Act 
        var command = new SearchByInvoiceNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);
    }
    [Fact]

    public async void Execute_ShouldReturn0Results_WhenInvoiceIsFound_AndBrandIsDifferent()
    {
        var invoiceNumber = "FAK06550911";
        var searchParameters = new SearchParameters(invoiceNumber, "Politiken");

        // Arrange
        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetInvoice(searchParameters.Input)).ReturnsAsync(new ZuoraInvoice
        {
            Id = "fake-invoice-id",
            AccountId = "fake-account-id",
            Amount = 42,
            InvoiceNumber = invoiceNumber
        });

        zuoraService.Setup(x => x.GetAccount("fake-account-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo
            {
                Id = "fakeid",
                SsoIdC = Guid.NewGuid().ToString(),
                BrandC = "JyllandsPosten",
                AccountNumber = "fake-account-id"
            }
        });

        // Act 
        var command = new SearchByInvoiceNumber(zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }
}
