﻿using Xunit;
using Moq;
using System;
using CustomerSearchService.BLL;
using CustomerSearchService.BLL.SearchCommands;
using CustomerSearchService.Services.Interfaces;
using System.Collections.Generic;
using CustomerSearchService.Models;
using ZuoraClient.NET.RestApi.Model.AccountApi;
using System.Linq;
using UserServiceClient.Model;

namespace CustomerSearchService.UnitTests.BLL.SearchCommands;

public class SearchByPhoneNumberTests
{
    [Fact]
    public async void Execute_ShouldReturn0Results_WhenNotFound()
    {
        var searchParameters = new SearchParameters("+45 11200000", "JyllandsPosten");

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.GetMatchingUsersByPhoneNumber(searchParameters.Input, true)).ReturnsAsync(Enumerable.Empty<Guid>());

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsFromPhoneNumberAsync(searchParameters.Input)).ReturnsAsync(new List<ZuoraContact>());

        // Act 
        var command = new SearchByPhoneNumber(ssoService.Object, zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public async void Execute_ShouldReturn1Result_WhenPhoneNumberIsFoundOnceInBothDatasources()
    {
        var searchParameters = new SearchParameters("+45 11200000", "JyllandsPosten");
        var expectedUser = new SsoUser
        {
            SsoId = Guid.NewGuid(),
            Email = "test@eksempel.dk",
            Firstname = "Karl",
            Lastname = "Koder"
        };

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.GetMatchingUsersByPhoneNumber(searchParameters.Input, true)).ReturnsAsync(new List<Guid>() { expectedUser.SsoId });
        ssoService.Setup(x => x.GetSsoUsers(new[] { expectedUser.SsoId })).ReturnsAsync(new List<SsoUser> { expectedUser });

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsFromPhoneNumberAsync(searchParameters.Input)).ReturnsAsync(new List<ZuoraContact>()
        {
            new ZuoraContact
            {
                PersonalEmail = "test@eksempel.dk",
                AccountId = "account-test-id",
            }
        });
        zuoraService.Setup(x => x.GetAccount("account-test-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo { BrandC = "JyllandsPosten", SsoIdC = expectedUser.SsoId.ToString() },
            BillToContact = new Contact
            {
                FirstName = "Fornavn",
                LastName = "Efternavn"
            }
        });

        zuoraService.Setup(x => x.GetSubscriptionsByAccountId("account-test-id")).ReturnsAsync(new List<SubscriptionCompact>
        {
            new SubscriptionCompact {
                Name = "Subscription"
            }
        });

        // Act 
        var command = new SearchByPhoneNumber(ssoService.Object, zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);
    }

    [Fact]
    public async void Execute_ShouldReturn1Result_WhenThePhoneNumberIsFoundOnlyInSsoDatasource()
    {
        var searchParameters = new SearchParameters("+45 11200000", "JyllandsPosten");
        var expectedUser = new SsoUser
        {
            SsoId = Guid.NewGuid(),
            Email = "test@eksempel.dk",
            Firstname = "Karl",
            Lastname = "Koder"
        };

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.GetMatchingUsersByPhoneNumber(searchParameters.Input, true)).ReturnsAsync(new List<Guid>() { expectedUser.SsoId });
        ssoService.Setup(x => x.GetSsoUsers(new[] { expectedUser.SsoId })).ReturnsAsync(new List<SsoUser> { expectedUser });

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsFromPhoneNumberAsync(searchParameters.Input)).ReturnsAsync(new List<ZuoraContact>());

        // Act 
        var command = new SearchByPhoneNumber(ssoService.Object, zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        Assert.Single(result);

        // TODO: Match expected values
        // Assert.AreEqual(JsonConvert.SerializeObject(result.First()), JsonConvert.SerializeObject(new SearchResult {expected values}));
    }

    [Fact(Skip = "TODO: Currently this test fails. Need confirmation on what is expected behavior")]
    public async void Execute_ShouldReturn0Results_WhenFoundInZuoraWithDifferentBrand()
    {
        var searchParameters = new SearchParameters("+45 11200000", "Politiken");
        var expectedUser = new SsoUser
        {
            SsoId = Guid.NewGuid(),
            Email = "test@eksempel.dk",
            Firstname = "Karl",
            Lastname = "Koder"
        };

        // Arrange
        var ssoService = new Mock<ISsoService>(MockBehavior.Strict);
        ssoService.Setup(x => x.GetMatchingUsersByPhoneNumber(searchParameters.Input, true)).ReturnsAsync(new List<Guid>() { expectedUser.SsoId });
        ssoService.Setup(x => x.GetSsoUser(expectedUser.SsoId)).ReturnsAsync(expectedUser);

        var zuoraService = new Mock<IZuoraService>(MockBehavior.Strict);
        zuoraService.Setup(x => x.GetContactsFromPhoneNumberAsync(searchParameters.Input)).ReturnsAsync(new List<ZuoraContact>()
        {
            new ZuoraContact
            {
                PersonalEmail = "test@eksempel.dk",
                AccountId = "account-test-id",
            }
        });
        zuoraService.Setup(x => x.GetAccount("account-test-id")).ReturnsAsync(new Account
        {
            BasicInfo = new AccountBasicInfo { BrandC = "JyllandsPosten", SsoIdC = expectedUser.SsoId.ToString() },
            BillToContact = new Contact
            {
                FirstName = "Fornavn",
                LastName = "Efternavn"
            }
        });

        zuoraService.Setup(x => x.GetSubscriptionsByAccountId("account-test-id")).ReturnsAsync(new List<SubscriptionCompact>
        {
            new SubscriptionCompact {
                Name = "Subscription"
            }
        });

        // Act 
        var command = new SearchByPhoneNumber(ssoService.Object, zuoraService.Object);
        var result = await command.Execute(searchParameters);

        // Assert
        // TODO: This should be empty, but it's not, since it is found in Sso with no regard for Brand :-/
        Assert.Empty(result);
    }
}
