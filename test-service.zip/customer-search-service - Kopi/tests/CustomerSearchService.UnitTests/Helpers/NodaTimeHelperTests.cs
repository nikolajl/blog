﻿using NodaTime;
using CustomerSearchService.Helpers;
using Xunit;

namespace CustomerSearchService.UnitTests.Helpers
{
    /// <summary>
    /// These initial tests are for example purposes. They are rather pointless in themselves.
    /// </summary>
    public class NodaTimeHelperTests
    {
        private NodaTimeHelper GetNodaTimeHelper() => new();

        [Fact]
        public void GetCopenhagenTimeZoneTest()
        {
            //Arrange
            var expectedResult = DateTimeZoneProviders.Tzdb["Europe/Copenhagen"];

            //Act
            var sut = GetNodaTimeHelper();
            var result = sut.GetCopenhagenTimeZone();

            //Assert
            Assert.Equal(result.Id, expectedResult.Id);
        }

        [Fact]
        public void GetCurrentNodaTimeWithOffsetTest()
        {
            //Arrange
            var expectedResult = SystemClock.Instance.GetCurrentInstant().InZone(DateTimeZoneProviders.Tzdb["Europe/Copenhagen"]).ToDateTimeOffset();

            //Act
            var sut = GetNodaTimeHelper();
            var result = sut.GetCurrentNodaTimeWithOffset();

            Assert.InRange(result, expectedResult.AddSeconds(-5), expectedResult.AddSeconds(5));
        }
    }
}