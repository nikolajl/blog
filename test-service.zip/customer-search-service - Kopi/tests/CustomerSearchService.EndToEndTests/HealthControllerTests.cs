﻿using System.Collections.Generic;
using CustomerSearchService.Controllers;
using JPLogging.Logging;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace CustomerSearchService.EndToEndTests;

public class HealthControllerTests
{

    private HealthController GetHealthController(ILogHandler loghandler = null)
    {
        loghandler ??= new Mock<ILogHandler>(MockBehavior.Loose).Object;

        return new HealthController(loghandler);
    }

    [Fact]
    public async void Health()
    {
        // Act
        var sut = GetHealthController();

        var result = sut.Health();

        // Assert
        var objectResult = result as OkObjectResult;
        Assert.NotNull(objectResult);

        var stringList = objectResult.Value as List<string>;
        Assert.Contains(stringList, item => item == "I AM ALIVE");
    }

}
