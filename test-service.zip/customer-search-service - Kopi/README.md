# Customer Search Service

## Scopes needed

- CCS-Read

## Environments

- [Development](https://customer-search-service.dev.aws.jyllands-posten.dk/)
- [Staging](https://customer-search-service.test.aws.jyllands-posten.dk/)
- [Prod](https://customer-search-service.aws.jyllands-posten.dk/)

## Dev notes

Search Service uses a Command / Strategy / Factory design pattern to determine which datasource to search.

Currently it supports

- [x] SearchBySsoId
- [x] SearchBySubscriptionNumber
- [x] SearchByAccountNumber
- [ ] SearchByOrderNumber
- [x] SearchByInvoiceNumber
- [x] SearchByPaymentNumber
- [x] SearchByEmail
- [x] SearchByPhoneNumber
- [x] SearchByDomain
- [x] SearchByName
- [x] SearchByPipedriveId
- [x] SearchByCvrNumber
- [x] SearchByEanNumber
- [x] SearchByAddress
- [x] SearchByMasterAddressPointId

### TODO

- [ ] SsoServiceTests
- [ ] ZuoraServiceTests
- [ ] IntegrationTests
- [ ] TestDataCollection instead of mocking new objects in each test?
- [ ] Exception handling - refactor response to return object with `List<SearchResult>`s and status in case a service throws exception?

### HOWTO: Add another search strategy

To add new search capability:

- create a new _SearchCommand_ (must implement `ISearchCommand`) in `BLL/SearchCommands`,
- add the strategy to the `BLL/SearchProvider.GetSearchCommand(...)` method
- finally, add the service to the `builder.Services` IOC collection in `Program.cs`.
  - of course, if the command has new dependencies, those should be added as well.
