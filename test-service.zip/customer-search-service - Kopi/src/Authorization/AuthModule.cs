﻿namespace CustomerSearchService.Authorization;

/// <summary>
/// To add authentication/authorization to application
/// </summary>
public static class AuthModule
{
    /// <summary>
    /// Add authentication and authorization using default libraries
    /// </summary>
    public static void AddAuth(this IServiceCollection services, string audience, string authority, string claimsIssuer)
    {
        services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        }).AddJwtBearer(options =>
        {
            options.Audience = audience;
            options.Authority = authority;
            options.ClaimsIssuer = claimsIssuer;
            options.RequireHttpsMetadata = false;
        });

        services.AddAuthorization(options =>
        {
            options.AddPolicy(PolicyNames.Admin, policy => policy.RequireClaim("scope", "CSS-Admin"));
            options.AddPolicy(PolicyNames.Read, policy => policy.RequireClaim("scope", "CSS-Read"));
            options.AddPolicy(PolicyNames.Write, policy => policy.RequireClaim("scope", "CSS-Write"));
        });
    }
}