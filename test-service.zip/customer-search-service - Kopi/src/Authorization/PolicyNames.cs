﻿namespace CustomerSearchService.Authorization;

/// <summary>
/// Contains the name of all policies
/// </summary>
public static class PolicyNames
{
    /// <summary>
    /// Provides read access to events-endpoints
    /// </summary>
    public const string Read = "read";

    /// <summary>
    /// Provides write access to events-endpoints
    /// </summary>
    public const string Write = "write";

    /// <summary>
    /// Provides full access to all endpoints
    /// </summary>
    public const string Admin = "admin";
}