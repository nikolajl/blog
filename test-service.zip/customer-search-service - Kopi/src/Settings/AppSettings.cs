﻿namespace CustomerSearchService.Settings;

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
public class AppSettings
{
    [UsedImplicitly] public string ApplicationName { get; init; }
    // ReSharper disable once InconsistentNaming
    [UsedImplicitly] public NetCoreEnvironment ASPNETCORE_ENVIRONMENT { get; init; }
    [UsedImplicitly] public bool IsLocal { get; init; }
    public Metrics Metrics { get; init; }
    public Auth Auth { get; init; }
    public Sso Sso { get; init; }
    public Distribution Distribution { get; init; }
    public DistributionAddress DistributionAddress { get; init; }
    public Zuora Zuora { get; init; }
    public AccountRelation AccountRelation { get; init; }
    public SubscriptionRelationService SubscriptionRelationService { get; init; }
    public Sos Sos { get; init; }
    public Aas Aas { get; init; }
    public AuthorizationScopes AuthorizationScopes { get; init; }
}


public enum NetCoreEnvironment
{
    [UsedImplicitly] Development,
    [UsedImplicitly] Staging,
    [UsedImplicitly] Production
}

public class AuthorizationScopes
{
    public string Srs { get; init; }
    public string Aas { get; init; }
}

public class Metrics
{
    public string UserName { get; init; }
    public string Password { get; init; }
}

public class Auth
{
    public string Audience { get; init; }
    public string Authority { get; init; }
    public string ClaimsIssuer { get; init; }
    public string ClientId { get; init; }
    public string ClientSecret { get; init; }
}

public class Sso
{
    public string Identity { get; init; }
    public string Key { get; init; }
    public string Endpoint { get; init; }

}

public class Distribution
{
    public string BasePath { get; init; }
}

public class DistributionAddress
{
    public string BasePath { get; init; }
}

public class Zuora
{
    public string BasePath { get; init; }
    public string ApiAccessKeyId { get; init; }
    public string ApiSecretAccessKey { get; init; }
}

public class AccountRelation
{
    public string BasePath { get; init; }
}

public class SubscriptionRelationService
{
    public string BasePath { get; init; }
}

public class Sos
{
    public string BasePath { get; init; }
    public string ApiKey { get; init; }
    public string ApiPassword { get; init; }
}

public class Aas
{
    public string BasePath { get; init; }
}
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.