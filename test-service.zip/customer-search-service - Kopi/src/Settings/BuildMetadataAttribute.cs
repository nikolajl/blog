﻿namespace CustomerSearchService.Settings;

/// <summary>
/// Holds data pertaining to the build of the code.
/// for further info.
/// </summary>
[AttributeUsage(AttributeTargets.Assembly)]
public class BuildMetadataAttribute : Attribute
{
    public string GitCommitHash { get; }
    public DateTime? CustomBuildDate { get; }

    public BuildMetadataAttribute(string gitCommitHash, string customBuildDate)
    {
        GitCommitHash = gitCommitHash;

        if (DateTime.TryParse(customBuildDate, out var date))
        {
            CustomBuildDate = date;
        }
    }
}
