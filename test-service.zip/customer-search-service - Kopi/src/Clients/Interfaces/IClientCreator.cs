﻿using DistClient.NET.Api.Interfaces;
using JpPolitikensHus.UserServiceProxyNetCore;
using UserServiceClient.Api.Interfaces;
using ZuoraClient.NET.ActionsApi.Interface;
using ZuoraClient.NET.RestApi.Interface;

namespace CustomerSearchService.Clients.Interfaces
{
    public interface IClientCreator
    {
        IUserServiceApi UserServiceApi();
        Task<IDistributionApi> DistributionClient();
        Task<IAddressApi> DistributionAddressClient();
        IActionsApi ZuoraActionsApi();
        IAccountApi ZuoraAccountsApi();
        JpRestClient.NET.JpRestClient CreateAccountRelationClient();
        Task<JpRestClient.NET.JpRestClient> CreateSubscriptionRelationServiceClient();
        JpRestClient.NET.JpRestClient CreateSosClient();
        Task<JpRestClient.NET.JpRestClient> CreateAasClient();

    }
}
