﻿using CustomerSearchService.Clients.Interfaces;
using DistClient.NET;
using DistClient.NET.Api;
using DistClient.NET.Api.Interfaces;
using JpPolAuth;
using JpPolAuth.Client;
using JpPolitikensHus.UserServiceProxyNetCore;
using JpRestClient.NET;
using UserServiceClient;
using UserServiceClient.Api;
using UserServiceClient.Api.Interfaces;
using ZuoraClient.NET;
using ZuoraClient.NET.ActionsApi;
using ZuoraClient.NET.ActionsApi.Interface;
using ZuoraClient.NET.RestApi;
using ZuoraClient.NET.RestApi.Interface;

namespace CustomerSearchService.Clients;

public class ClientCreator : IClientCreator
{
    private readonly AppSettings _appSettings;
    private readonly ILogHandler _logHandler;
    private readonly IMemBag _memBag;


    public ClientCreator(AppSettings appSettings, ILogHandler logHandler, IMemBag memBag)
    {
        _appSettings = appSettings;
        _logHandler = logHandler;
        _memBag = memBag;
    }

    public IUserServiceApi UserServiceApi()
    {
        var config = new UserServiceClientConfiguration(_appSettings.Sso.Endpoint, new Guid(_appSettings.Sso.Identity), _appSettings.Sso.Key);
        config.LoggingConfiguration.Logger = _logHandler;
        return new UserServiceApi(config);
    }

    public async Task<IDistributionApi> DistributionClient()
    {
        var jpPolAuthProxy = CreateJpPolAuthProxy();
        var token = await jpPolAuthProxy.GetBearerToken("sb:address sb:distribution");
        var config = new DistClientConfiguration(_appSettings.Distribution.BasePath, token);

        config.LoggingConfiguration.Logger = _logHandler;
        config.RequestConfiguration.CorrelationIdConfiguration.UseMemBag(_memBag);

        return new DistributionApi(config);
    }

    public async Task<IAddressApi> DistributionAddressClient()
    {
        var jpPolAuthProxy = CreateJpPolAuthProxy();
        var token = await jpPolAuthProxy.GetBearerToken("sb:address sb:distribution");
        var config = new DistClientConfiguration(_appSettings.DistributionAddress.BasePath, token);

        config.LoggingConfiguration.Logger = _logHandler;
        config.RequestConfiguration.CorrelationIdConfiguration.UseMemBag(_memBag);

        return new AddressApi(config);
    }

    private JpPolAuthProxy CreateJpPolAuthProxy()
    {
        var config = new JpPolAuthConfiguration(
            basePath: _appSettings.Auth.Authority,
            clientId: _appSettings.Auth.ClientId,
            clientSecret: _appSettings.Auth.ClientSecret,
            serviceName: "customer-search-service"
        );

        return new JpPolAuthProxy(config);
    }

    public IActionsApi ZuoraActionsApi()
    {
        var config = new ZuoraClientConfiguration(_appSettings.Zuora.BasePath);
        config.LoggingConfiguration.Logger = _logHandler;
        config.ZuoraConfiguration.UserName = _appSettings.Zuora.ApiAccessKeyId;
        config.ZuoraConfiguration.Password = _appSettings.Zuora.ApiSecretAccessKey;

        return new ActionsApi(config);
    }

    public IAccountApi ZuoraAccountsApi()
    {
        var config = new ZuoraClientConfiguration(_appSettings.Zuora.BasePath);
        config.LoggingConfiguration.Logger = _logHandler;
        config.LoggingConfiguration.Logger = _logHandler;
        config.ZuoraConfiguration.UserName = _appSettings.Zuora.ApiAccessKeyId;
        config.ZuoraConfiguration.Password = _appSettings.Zuora.ApiSecretAccessKey;

        return new AccountApi(config);
    }

    private JpRestClientConfiguration CreateJpRestClientConfiguration(string basePath, List<KeyValuePair<string, string>>? headers = null)
    {
        var config = new JpRestClientConfiguration(basePath);
        config.LoggingConfiguration.Logger = _logHandler;
        config.RequestConfiguration.CorrelationIdConfiguration.UseMemBag(_memBag);

        if (headers != null && headers.Any())
        {
            foreach (var header in headers)
            {
                config.RequestConfiguration.Headers.Add(new RequestHeader(header.Key, header.Value));
            }
        }

        return config;
    }

    public JpRestClient.NET.JpRestClient CreateAccountRelationClient()
    {
        var headers = new List<KeyValuePair<string, string>>()
        {
            new("X-API-Key", "asr480")
        };

        var configuration = CreateJpRestClientConfiguration(_appSettings.AccountRelation.BasePath, headers);

        return new JpRestClient.NET.JpRestClient(configuration);
    }

    public async Task<JpRestClient.NET.JpRestClient> CreateSubscriptionRelationServiceClient()
    {
        var configuration = CreateJpRestClientConfiguration(_appSettings.SubscriptionRelationService.BasePath);

        var jpPolAuthProxy = CreateJpPolAuthProxy();
        var token = await jpPolAuthProxy.GetBearerToken(_appSettings.AuthorizationScopes.Srs);
        configuration.DefaultRestClientConfiguration.AuthToken = token;

        return new JpRestClient.NET.JpRestClient(configuration);
    }

    public JpRestClient.NET.JpRestClient CreateSosClient()
    {
        var configuration = CreateJpRestClientConfiguration(_appSettings.Sos.BasePath);

        configuration.DefaultRestClientConfiguration.UserName = _appSettings.Sos.ApiKey;
        configuration.DefaultRestClientConfiguration.Password = _appSettings.Sos.ApiPassword;

        return new JpRestClient.NET.JpRestClient(configuration);
    }

    public async Task<JpRestClient.NET.JpRestClient> CreateAasClient()
    {
        var configuration = CreateJpRestClientConfiguration(_appSettings.Aas.BasePath);

        var jpPolAuthProxy = CreateJpPolAuthProxy();
        var token = await jpPolAuthProxy.GetBearerToken(_appSettings.AuthorizationScopes.Aas);
        configuration.DefaultRestClientConfiguration.AuthToken = token;

        return new JpRestClient.NET.JpRestClient(configuration);
    }

}
