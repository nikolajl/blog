﻿namespace CustomerSearchService.Helpers.Interfaces;

public interface INodaTimeHelper
{
    DateTimeZone GetCopenhagenTimeZone();
    DateTimeOffset GetCurrentNodaTimeWithOffset();
}