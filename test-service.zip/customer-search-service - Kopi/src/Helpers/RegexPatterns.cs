﻿namespace CustomerSearchService.Helpers;

public class RegexPatterns
{
    public const string EmailPattern = @"^[\w0-9._%+-]+@[\w0-9.-]+\.[A-Za-z]{2,4}$"; // this is the definition from the SSO system
    public const string GuidPattern = @"^\{?[a-fA-F\d]{8}-([a-fA-F\d]{4}-){3}[a-fA-F\d]{12}\}?$";
    public const string AccountNumberPattern = @"^[AK][0-9]{8}$";
    public const string PaymentNumberPattern = @"^P-[0-9]{8}$";
    public const string PhoneNumberPattern = @"^\+?[0-9 ]{8,}$";
    public const string SubscriptionNumberPattern = @"^(ABN|A-S)[0-9]{8}$";
    public const string InvoiceNumberPattern = @"^(INV|FAK)[0-9]{8}$";
    public const string CvrPattern = @"DK[0-9]{8}";
    public const string PipedriveId = @"^[0-9]{4,7}$";
    public const string EanPattern = @"^EAN[0-9]{13}$";
    public const string OrderNumberPattern = @"^(MK|WR)-[0-9]{10}$";
    public const string AddressPointIdPattern = @"^\d{1,6}";  //This is probably wrong. An address point can be up to 9 chars at least. But it goes well anyway because the regex doesn't end wtih "$".
    public const string ZipCode = @"^\d{1,4}";
    public const string DomainPattern = @"^[\w0-9.-]+\.[A-Za-z]{2,4}$"; // this is the definition from the SSO system
    public const string GiftcardReferencePattern = @"^GK-[a-zA-Z0-9_-]+$";  //The suffix is the actual giftcardrefence. Regex from GiftcardService.

    /* Unused patterns from CustomerOverview
    public const string IpPattern = @"\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b";
    public const string SubscriptionIdPattern = @"^ID[0-9]{8}$";
    public const string SubscriptionTypeNumberPattern = @"^[Tt][0-9]{9}$";
    public const string SubscriptionNumberOrSubscriptionIdPattern = @"(^[^0][0-9]{6,7}$)|(^ID[0-9]{8}$)";
    public const string GuidOrEmailPattern = @"(^[\w0-9._%+-]+@[\w0-9.-]+\.[A-Za-z]{2,4}$)|(^\{?[a-fA-F\d]{8}-([a-fA-F\d]{4}-){3}[a-fA-F\d]{12}\}?$)";
    public const string NamePattern = @"^[a-zA-ZæøåÆØÅ]+(([',. -][a-zA-ZæøåÆØÅ ])?[a-zA-ZæøåÆØÅ]*)*$";
    */
}
