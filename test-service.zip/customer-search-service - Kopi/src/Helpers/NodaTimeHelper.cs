﻿namespace CustomerSearchService.Helpers;

public class NodaTimeHelper : INodaTimeHelper
{
    public DateTimeZone GetCopenhagenTimeZone()
    {
        return DateTimeZoneProviders.Tzdb["Europe/Copenhagen"];
    }

    public DateTimeOffset GetCurrentNodaTimeWithOffset()
    {
        var now = SystemClock.Instance.GetCurrentInstant();
        return now.InZone(GetCopenhagenTimeZone()).ToDateTimeOffset();
    }
}