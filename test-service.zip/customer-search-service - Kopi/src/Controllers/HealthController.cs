﻿namespace CustomerSearchService.Controllers;

[ApiController]
[ApiVersionNeutral]
[Route("api")]
public class HealthController : BaseController
{
    public HealthController(ILogHandler logHandler) : base(logHandler)
    {
    }

    /// <summary>
    /// Endpoint to check if the service is available
    /// </summary>
    /// <returns>true</returns>
    [HttpGet]
    [Route("[action]")]
    public IActionResult Health()
    {
        try
        {
            var list = new List<string> { "I AM ALIVE" };
            return Ok(list);
        }
        catch (Exception e)
        {
            return base.HandleException(e);
        }
    }
}