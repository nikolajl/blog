﻿using System.Runtime.CompilerServices;

namespace CustomerSearchService.Controllers
{
    public class BaseController : Controller
    {
        protected readonly ILogHandler _logHandler;

        public BaseController(ILogHandler logHandler)
        {
            _logHandler = logHandler;
        }

        /// <summary>
        /// Returns the appropriate response and logs as necessary if an exception occurs.
        /// </summary>
        protected IActionResult HandleException(Exception exception, [CallerMemberName] string callingMethod = "", [CallerFilePath] string callingClass = "", Dictionary<string, string>? extraData = null)
        {
            switch (exception)
            {
                case ArgumentException:
                    return BadRequest(exception.Message);
                case InvalidOperationException:
                    return BadRequest(exception.Message);
                default:
                    _logHandler.Error($"Exception when executing controller method {callingMethod} in {callingClass}.", exception, extraData);
                    return StatusCode((int)HttpStatusCode.InternalServerError, exception.Message);
            }
        }
    }
}
