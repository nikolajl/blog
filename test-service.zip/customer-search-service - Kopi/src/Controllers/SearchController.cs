﻿using CustomerSearchService.BLL.Interfaces;
using CustomerSearchService.Controllers.Responses;
using Microsoft.AspNetCore.Authorization;

namespace CustomerSearchService.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/[controller]")]
public class SearchController : BaseController
{
    private readonly ISearchProvider _searchProvider;
    private readonly IAddressSearchProvider _addressSearchProvider;

    public SearchController(ILogHandler logHandler, ISearchProvider searchProvider, IAddressSearchProvider addressSearchProvider) : base(logHandler)
    {
        _searchProvider = searchProvider;
        _addressSearchProvider = addressSearchProvider;
    }

    /// <summary>
    /// Generic search capable of searching many datasources, combining them into a single "ranked" search result. 
    /// Searches, e.g., name, email, account, subscription, invoice, order, sso 
    /// </summary>
    [HttpGet("")]
    [Authorize(PolicyNames.Read)]
    [ProducesResponseType(typeof(List<SearchResponse>), (int)HttpStatusCode.OK)]
    public async Task<IActionResult> Search([FromQuery] string input, [FromQuery] string brands, [FromQuery] string? publicationCodes)
    {
        if (string.IsNullOrEmpty(input) || input.Trim().Length < 3)
        {
            return BadRequest("Search input too short. Search input must be at least 3 characters");
        }

        try
        {
            // Validate and Sanitize (Trim()) input
            var searchParams = new SearchParameters(input, brands, publicationCodes ?? "");

            var searchResults = await _searchProvider.ExecuteSearch(searchParams);
            var result = searchResults.Select(x => new SearchResponse
            {
                Active = x.Active,
                CompanyName = x.CompanyName,
                DataSource = x.DataSource,
                Email = x.Email,
                IdentType = x.IdentType,
                Name = x.Name,
                OrderNumber = x.OrderNumber,
                SsoId = x.SsoId,
                ZuoraAccountNumber = x.ZuoraAccountNumber,
                ZuoraSubscriptionNumber = x.ZuoraSubscriptionNumber,
                ZuoraAccountId = x.ZuoraAccountId,
                ZuoraInvoiceId = x.ZuoraInvoiceId,
                ZuoraPaymentNumber = x.ZuoraPaymentNumber,
            });

            return Ok(result);
        }
        catch (Exception e)
        {
            return base.HandleException(e, extraData: new Dictionary<string, string>()
            {
                {nameof(input), input},
                {nameof(brands), brands},
                {nameof(publicationCodes), publicationCodes}
            });
        }
    }

    /// <summary>
    /// Address search capable of searching on a masterAddressPointId or a partial / complete address, combining them into a single "ranked" search result.  
    /// If a masterAddressPointId is supplied any other address information is not used.
    /// </summary>
    [HttpGet("address")]
    [Authorize(PolicyNames.Read)]
    [ProducesResponseType(typeof(List<SearchResponse>), (int)HttpStatusCode.OK)]
    public async Task<IActionResult> SearchAddress([FromQuery] string brands, [FromQuery] string? publicationCodes, [FromQuery] string? masterAddressPointID = "", [FromQuery] string? zipCode = "", [FromQuery] string? street = "", [FromQuery] string? houseNumber = "", [FromQuery] string? houseLetter = "", [FromQuery] string? houseFloor = "", [FromQuery] string? houseSide = "")
    {
        try
        {
            var searchParams = new AddressSearchParameters(masterAddressPointID, zipCode, street, houseNumber, houseLetter, houseFloor, houseSide, brands, publicationCodes ?? "");

            var searchResults = await _addressSearchProvider.ExecuteSearch(searchParams);
            var result = searchResults.Select(x => new SearchResponse
            {
                Active = x.Active,
                CompanyName = x.CompanyName,
                DataSource = x.DataSource,
                Email = x.Email,
                IdentType = x.IdentType,
                Name = x.Name,
                OrderNumber = x.OrderNumber,
                SsoId = x.SsoId,
                ZuoraAccountNumber = x.ZuoraAccountNumber,
                ZuoraSubscriptionNumber = x.ZuoraSubscriptionNumber,
                ZuoraAccountId = x.ZuoraAccountId,
                ZuoraInvoiceId = x.ZuoraInvoiceId,
                ZuoraPaymentNumber = x.ZuoraPaymentNumber,
            });

            return Ok(result);
        }
        catch (Exception e)
        {
            return base.HandleException(e, extraData: new Dictionary<string, string>()
            {
                {nameof(masterAddressPointID), masterAddressPointID},
                {nameof(zipCode), zipCode},
                {nameof(street), street},
                {nameof(houseNumber), houseNumber},
                {nameof(houseLetter), houseLetter},
                {nameof(houseFloor), houseFloor},
                {nameof(houseSide), houseSide},
                {nameof(brands), brands},
                {nameof(publicationCodes), publicationCodes},
            });
        }
    }
}
