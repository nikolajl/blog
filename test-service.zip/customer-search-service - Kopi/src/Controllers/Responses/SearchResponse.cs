﻿namespace CustomerSearchService.Controllers.Responses
{
    public class SearchResponse
    {
        public Guid SsoId { get; set; }
        public string Name { get; set; }
        public string CompanyName { get; set; }
        public string Email { get; set; }
        public string DataSource { get; set; }
        public string IdentType { get; set; }
        public bool? Active { get; set; }
        public string ZuoraAccountNumber { get; set; }
        public string ZuoraSubscriptionNumber { get; set; }
        public string ZuoraPaymentNumber { get; set; }
        public string ZuoraInvoiceId { get; set; }
        public string ZuoraAccountId { get; set; }
        public string OrderNumber { get; set; }
    }
}
