﻿using Amazon.SecurityToken;
using Amazon.SecurityToken.Model;
using CustomerSearchService.Clients;
using CustomerSearchService.Clients.Interfaces;
using Serilog.Events;
using SubscriptionRelationService = CustomerSearchService.Services.SubscriptionRelationService;

var builder = WebApplication.CreateBuilder(args);
CreateLogger();
builder.Logging.ClearProviders();
builder.Logging.AddSerilog();

//This is the earliest point we can log program start (after initializing the logger).
var logger = new LogHandler();
var memBag = new MemBag(logger);

logger.DataFlow.Notification("Program starting.", new Dictionary<string, string>
    {
        {"args", args != null ? $"[{string.Join(',', args)}]" : null}
    });

var _appSettings = SetupSecrets(builder.Environment);

/******************************************************/
/********************** Services **********************/
/******************************************************/

// Add services to the container.
builder.Services.AddControllers();

// Add a configured instance off AppSettings as singleton
builder.Services.AddSingleton(_appSettings);

// Add other services
builder.Services.AddScoped<INodaTimeHelper, NodaTimeHelper>();
builder.Services.AddScoped<IClientCreator, ClientCreator>();
builder.Services.AddScoped<ISubscriptionRelationService, SubscriptionRelationService>();
builder.Services.AddScoped<ISubscriptionOrderService, SubscriptionOrderService>();
builder.Services.AddScoped<ISsoService, SsoService>();
builder.Services.AddScoped<IZuoraService, ZuoraService>();
builder.Services.AddScoped<IDistributionService, DistributionService>();
builder.Services.AddScoped<IAccountRelationService, AccountRelationService>();
builder.Services.AddScoped<ISearchProvider, SearchProvider>();
builder.Services.AddScoped<IAddressSearchProvider, AddressSearchProvider>();
builder.Services.AddScoped<IAccessAgreementService, AccessAgreementService>();
builder.Services.AddScoped<SearchByEmail>();
builder.Services.AddScoped<SearchByDomain>();
builder.Services.AddScoped<SearchBySsoId>();
builder.Services.AddScoped<SearchByAccountNumber>();
builder.Services.AddScoped<SearchByPaymentNumber>();
builder.Services.AddScoped<SearchByPhoneNumber>();
builder.Services.AddScoped<SearchByName>();
builder.Services.AddScoped<SearchByNameBetter>();
builder.Services.AddScoped<SearchBySubscriptionNumber>();
builder.Services.AddScoped<SearchByInvoiceNumber>();
builder.Services.AddScoped<SearchByCvr>();
builder.Services.AddScoped<SearchByPipedriveId>();
builder.Services.AddScoped<SearchByEan>();
builder.Services.AddScoped<SearchByOrderNumber>();
builder.Services.AddScoped<SearchByAddressPointId>();
builder.Services.AddScoped<SearchByAddress>();
builder.Services.AddScoped<SearchByGiftcardReference>();

// JP Logging
builder.Services.AddTransient<ILogHandler, LogHandler>();
builder.Services.AddTransient<IMemBag, MemBag>();

// Swagger
builder.Services.AddApiVersioning(c =>
{
    c.DefaultApiVersion = new ApiVersion(1, 0);
    c.AssumeDefaultVersionWhenUnspecified = true;
    c.ReportApiVersions = true;  // reporting api versions will return the headers "api-supported-versions" and "api-deprecated-versions"
});

builder.Services.AddVersionedApiExplorer(c =>
{
    // add the versioned api explorer, which also adds IApiVersionDescriptionProvider service
    // note: the specified format code will format the version as "'v'major[.minor][-status]"
    c.GroupNameFormat = "'v'VVV";

    // note: this option is only necessary when versioning by url segment. the SubstitutionFormat
    // can also be used to control the format of the API version in route templates
    c.SubstituteApiVersionInUrl = true;
});

// Add Authorization
builder.Services.AddAuth(_appSettings.Auth.Audience, _appSettings.Auth.Authority, _appSettings.Auth.ClaimsIssuer);
builder.Services.AddSwagger();


var app = builder.Build();

#region Logging middleware
app.JpUseCorrelationIdMemBagMiddleware(memBag, logger);
app.JpUseLogAuthorizationMiddleware(logger);
app.JpUseLogRemoteHostNameMiddleware(logger);
app.JpUseLogRemoteIpAddressMiddleware(logger);
app.JpUseLogRequestHttpMethodMiddleware(logger);
app.JpUseLogRequestUrlMethodMiddleware(logger);
app.JpUseLogPipelineExceptionMiddleware(logger);

app.JpUseDataFlowMiddleware(logger, new List<EndpointMatch>
    {
        new EndpointMatch
        {
            HttpMethod = "GET",
            UrlRegex = new Regex(@".+/health", RegexOptions.IgnoreCase)
        },
        new EndpointMatch
        {
            HttpMethod = "GET",
            UrlRegex = new Regex(@".+/metrics", RegexOptions.IgnoreCase)
        },
        new EndpointMatch
        {
            HttpMethod = "GET",
            UrlRegex = new Regex(@".+/index\.html", RegexOptions.IgnoreCase)  //Swagger page
        },
        new EndpointMatch
        {
            HttpMethod = "GET",
            UrlRegex = new Regex(@".*swagger.*", RegexOptions.IgnoreCase)  //Ignore everything else swagger-releated
        }
    });

#endregion

//PrometheusMetrics
//Enable metrics server, and make it expose HTTP metrics, with basic auth
var metricsUsername = _appSettings.Metrics?.UserName; // Username for logging into /metrics endpoint
var metricsPassword = _appSettings.Metrics?.Password; // Password for logging into /metrics endpoint
app.Map("/metrics", metricsApp =>
{
    metricsApp.UseMiddleware<BasicAuthMiddleware>("CustomerSearchService", metricsUsername, metricsPassword);
    metricsApp.UseMetricServer(""); //Make sure to place UseMetricServer before the call to app.UseEndPoints(...) � otherwise we may be missing some important HTTP metrics later on.
});

//Swagger middleware
app.UseSwagger(c =>
{
    c.RouteTemplate = "/swagger/{documentName}/swagger.json";
});
app.UseSwaggerUI(c =>
{
    var provider = app.Services.GetRequiredService<IApiVersionDescriptionProvider>();

    // build a swagger endpoint for each discovered API version
    foreach (var description in provider.ApiVersionDescriptions)
    {
        c.SwaggerEndpoint($"/swagger/{description.GroupName}/swagger.json", description.GroupName.ToUpperInvariant());
        c.RoutePrefix = "";
        //c.ConfigObject = new ConfigObject
        //{
        //    ShowCommonExtensions = true,
        //    ShowExtensions = true
        //};
        //c.ConfigObject.AdditionalItems.Add("showCommonExtensions", true);
        c.ShowExtensions();
        c.ShowCommonExtensions();
    }
});

app.UseHttpsRedirection();

//Central framework routing middleware. Works together with "UseEndpoints" to determine what controller
//endpoint to hit when a request enters the pipeline. All middleware after this point will be able to
//inspect what endpoint the call is going to invoke.
app.UseRouting();

app.UseHttpMetrics(); // Recommended called AFTER app.UseRouting() on ASP.NET Core 3 or newer

app.UseAuthentication();
app.UseAuthorization();

//When the pipeline reaches this middleware the chosen endpoint is invoked.
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});

app.Run();


void CreateLogger()
{
    //Read BuildVersion and BuildDate from the project attributes.
    //See https://stackoverflow.com/questions/49522751/how-to-read-get-a-propertygroup-value-from-a-csproj-file-using-c-sharp-in-a-ne
    //The flow for setting these attributes are as follows:
    //The step that builds the docker image parses values for the variables "GITCOMMITHASH" and "CUSTOMBUILDDATE" via --build-arg
    //at the "docker build" command. This sets the so named variables in the dockerfile. These are used to pass on the values when calling
    //the "dotnet publish" command. The "-p" parameter sets the custom project parameters we have defined in CustomerRententionService.csproj.
    //The "AssemblyAttribute" item in CustomerRententionService.csproj instantiates an object of our BuildMetadataAttribute
    //which is bound to the assembly for the project. We can fetch it and its data as shown below (as well as we could fetch all the other
    //assembly attributes defined and populated by the framework).
    var attr = Assembly.GetExecutingAssembly().GetCustomAttribute<BuildMetadataAttribute>();

    var loggerConfiguration = new LoggerConfiguration()
        .MinimumLevel.Debug()
        .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
        .MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Warning)
        .Enrich.JpApplicationBuildDate(attr.CustomBuildDate != null ? attr.CustomBuildDate.Value.ToString("s") : "[N/A]")
        .Enrich.JpApplicationBuildVersion(!string.IsNullOrEmpty(attr.GitCommitHash) ? attr.GitCommitHash : "[N/A]")
        .Enrich.JpApplicationKey(new Guid("B6DDF35D-8A9E-422E-AA8B-85A446D07EBA"))
        .Enrich.JpApplicationName("CustomerSearchService")
        .Enrich.JpApplicationServerMachineIp()
        .Enrich.JpApplicationServerMachineName()
        .Enrich.JpEnvironmentName(builder.Configuration.GetValue<string>("ASPNETCORE_ENVIRONMENT"))
        .Enrich.JpFrameworkRuntimeVersion()
        .Enrich.JpThreadId()
        .Enrich.FromLogContext()
        .WriteTo.JpCloudWatchSink();

    var logger = loggerConfiguration
        .CreateLogger();

    Log.Logger = logger;
    LogHandler.Configuration.SeriLogger = logger;
    LogHandler.Configuration.StackTraceLoggingMinimumLevel = Serilog.Events.LogEventLevel.Warning;
}

AppSettings SetupSecrets(IWebHostEnvironment env)
{
    //The ecs task in each environment is configured to inject the relevant environment variable
    //into the docker container. CF. the terraform script.
    var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
    if (string.IsNullOrWhiteSpace(environment))
    {
        throw new Exception("Found no value for environment variable 'ASPNETCORE_ENVIRONMENT'.");
    }

    var isLocal = Environment.GetEnvironmentVariable("IsLocal") == "true";

    //When running locally the credentials for accessing ssm secrets should be stored under a
    //profile called 'local-secrets-fetch' located in C:\\Users\\<username>\\.aws\\credentials.
    //If this profile does not exist then use the default credentials (will happen when not
    //running locally).
    //We should change this to an assumable role for all environments. That way we would not
    //need a shared user for dev/test
    AWSCredentials credentials = null;
    var chain = new CredentialProfileStoreChain();
    if (chain.TryGetProfile("local-secrets-fetch", out var profile))
    {
        if (env.EnvironmentName != "Production")
        {
            credentials = profile.GetAWSCredentials(profile.CredentialProfileStore);
        }
        else
        {
            const string roleArnToAssume = "arn:aws:iam::625420756232:role/jppol-jpprod-readonly";

            var client = new AmazonSecurityTokenServiceClient(profile.GetAWSCredentials(profile.CredentialProfileStore));

            var assumeRoleReq = new AssumeRoleRequest
            {
                DurationSeconds = 900,
                RoleSessionName = "LoadSecrets",
                RoleArn = roleArnToAssume
            };
            var assumeRoleRes = client.AssumeRoleAsync(assumeRoleReq);

            credentials = assumeRoleRes.Result.Credentials;
        }
    }

    var bldr = builder.Configuration
        .SetBasePath(env.ContentRootPath)
        .AddJsonFile("appsettings.json", optional: false)
        .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true);

    if (isLocal)
    {
        bldr.AddJsonFile($"appsettings.{environment}.Local.json", optional: true);
    }

    var configuration = bldr.AddSecretsManager(region: RegionEndpoint.EUWest1, credentials: credentials, configurator: options =>
        {
            options.AcceptedSecretArns = new List<string>()
            {
                $"customer-search-service/{env.EnvironmentName}/Metrics",
                $"customer-search-service/{env.EnvironmentName}/Auth",
                $"customer-search-service/{env.EnvironmentName}/Sso",
                $"customer-search-service/{env.EnvironmentName}/Zuora",
                $"customer-search-service/{env.EnvironmentName}/Sos"
            };
            options.KeyGenerator = (entry, key) => key.Split('/').Last();
        })
        .AddEnvironmentVariables()  //launchSettings.json loads variables into environment variables when running locally.
        .Build();

    var appSettings = new AppSettings();
    builder.Configuration.Bind(appSettings);

    return appSettings;
}
