﻿namespace CustomerSearchService.Models;

public class SubscriptionCompact
{
    public string Name { get; set; }
    public string Status { get; set; }
    public string AccountId { get; set; }
}
