﻿namespace CustomerSearchService.Models;

public class ZuoraContact
{
    public string AccountId { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string PersonalEmail { get; set; }
    public string CompanyName__c { get; set; }

    /// <summary>
    /// Returns formatted string of CompanyName__c, if exists, and Firstname + Lastname
    /// </summary>
    public string Name
    {
        get
        {
            return !string.IsNullOrEmpty(CompanyName__c) ? $"{CompanyName__c}, {FirstName} {LastName}".Trim() : $"{FirstName} {LastName}".Trim();
        }
    }

}