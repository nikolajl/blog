﻿namespace CustomerSearchService.Models;

public class ZuoraInvoice
{
    public string InvoiceNumber { get; set; }
    public string AccountId { get; set; }
    public string Status { get; set; }
    public decimal Amount { get; set; }
    public string Id { get; set; }
}
