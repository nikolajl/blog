﻿using System.Text.Json.Serialization;

namespace CustomerSearchService.Models;

public class AccessAgreement
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("accountNumber")]
    public string AccountNumber { get; set; }
}