﻿namespace CustomerSearchService.Models
{
    public class ZuoraInvoicePayment
    {
        public string Id { get; set; }
        public string PaymentId { get; set; }
        public string InvoiceId { get; set; }
    }
}
