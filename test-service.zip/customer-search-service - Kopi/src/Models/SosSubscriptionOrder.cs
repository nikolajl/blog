﻿namespace CustomerSearchService.Models;

public class SosSubscriptionOrder
{
    public Guid SsoId { get; set; }

    public string TypeEnumString { get; set; }

    public bool? IsBusiness { get; set; }

    public string StatusEnumString { get; set; }

    public string OrderNumber { get; set; }

    public string SubscriptionCustomerReference { get; set; }

    public string CustomerComment { get; set; }

    public string SubscriptionOrderBrandEnumString { get; set; }

    public string ZuoraProductRatePlanId { get; set; }

    public DateTime? SubscriptionStartDate { get; set; }

    public DateTime? AlignmentDate { get; set; }

    public string SubscriptionNumber { get; set; }

    public DateTime? UpgradeEffectiveDate { get; set; }

    public DateTime? TrialExpireDate { get; set; }

    public string SosNotes { get; set; }

    public string KcNotes { get; set; }

    public DateTime? Created { get; set; }

    public string EndUserIp { get; set; }

    public bool? RunBillingFlag { get; set; }

    // public SosSubscriptionOrderPaymentData PaymentData { get; set; }


    // public SosSubscriptionOrderContactData DebtorContactData { get; set; }

    // public SosSubscriptionOrderContactData DeliveryContactData { get; set; }

    // public SosSubscriptionOrderContactData SoldToContactData { get; set; }

    // public SosSubscriptionOrderMetaData MetaData { get; set; }

    // public SosSubscriptionOrderPriceData PriceData { get; set; }

    // public SosSubscriptionOrderSubscriptionData CreatedSubscription { get; set; }

    // public SosSubscriptionOrderCampaignData CampaignData { get; set; }

    // public List<SosRateplan> Products { get; set; }
}
