﻿namespace CustomerSearchService.Models;

public class SubscriptionRatePlanCompact
{
    public string Id { get; set; }
    public string GiftcardReference__c { get; set; }
    public string Name { get; set; }
    public string SubscriptionId { get; set; }
}
