﻿namespace CustomerSearchService.Models;

public class RealZuoraAccount
{
    public string Id { get; set; }
    public string AccountNumber { get; set; }
    public string SsoId__c { get; set; }
    public string Brand__c { get; set; }
}
