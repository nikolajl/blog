﻿namespace CustomerSearchService.Models
{
    public class ZuoraPayment
    {
        public string Id { get; set; }
        public string AccountId { get; set; }
        public string PaymentNumber { get; set; }
        public decimal Amount { get; set; }
    }
}
