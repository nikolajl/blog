﻿namespace CustomerSearchService.BLL.Interfaces;

public interface IAddressSearchCommand
{
    Task<List<SearchResult>> Execute(AddressSearchParameters searchParameters);
}
