﻿namespace CustomerSearchService.BLL.Interfaces;

public interface ISearchCommand
{
    Task<List<SearchResult>> Execute(SearchParameters searchParameters);
}
