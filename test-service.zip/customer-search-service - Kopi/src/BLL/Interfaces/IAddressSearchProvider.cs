﻿namespace CustomerSearchService.BLL.Interfaces;

public interface IAddressSearchProvider
{
    Task<List<SearchResult>> ExecuteSearch(AddressSearchParameters searchParameters);
}
