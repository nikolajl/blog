﻿namespace CustomerSearchService.BLL.Interfaces;

public interface ISearchProvider
{
    Task<List<SearchResult>> ExecuteSearch(SearchParameters searchParameters);
}
