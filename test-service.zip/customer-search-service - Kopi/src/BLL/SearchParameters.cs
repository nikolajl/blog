﻿namespace CustomerSearchService.BLL;

public class SearchParameters
{
    public string Input { get; internal set; }
    public List<string> Brands { get; internal set; }
    public List<string> PublicationCodes { get; internal set; }

    public SearchParameters(string input, string brands, string publicationCodes = "")
    {
        Input = input.Trim();
        Brands = brands.Split(',').Select(x => x.Trim()).ToList();
        PublicationCodes = publicationCodes.Split(',').Select(x => x.Trim()).ToList();
    }

    public bool IsInputEmail()
    {
        return Regex.IsMatch(Input, RegexPatterns.EmailPattern, RegexOptions.IgnoreCase);
    }
    public bool IsInputDomain()
    {
        return Regex.IsMatch(Input, RegexPatterns.DomainPattern, RegexOptions.IgnoreCase);
    }
    public bool IsInputGuid()
    {
        return Regex.IsMatch(Input, RegexPatterns.GuidPattern, RegexOptions.IgnoreCase);
    }
    public bool IsInputAccountNumber()
    {
        return Regex.IsMatch(Input, RegexPatterns.AccountNumberPattern, RegexOptions.IgnoreCase);
    }
    public bool IsInputPaymentNumber()
    {
        return Regex.IsMatch(Input, RegexPatterns.PaymentNumberPattern, RegexOptions.IgnoreCase);
    }
    public bool IsInputPhoneNumber()
    {
        return Regex.IsMatch(Input, RegexPatterns.PhoneNumberPattern, RegexOptions.IgnoreCase);
    }
    public bool IsInputSubscriptionNumber()
    {
        return Regex.IsMatch(Input, RegexPatterns.SubscriptionNumberPattern, RegexOptions.IgnoreCase);
    }
    public bool IsInputInvoiceNumber()
    {
        return Regex.IsMatch(Input, RegexPatterns.InvoiceNumberPattern, RegexOptions.IgnoreCase);
    }
    public bool IsInputCvr()
    {
        return Regex.IsMatch(Input, RegexPatterns.CvrPattern, RegexOptions.IgnoreCase);
    }
    public bool IsPipedriveId()
    {
        return Regex.IsMatch(Input, RegexPatterns.PipedriveId, RegexOptions.IgnoreCase);
    }
    public bool IsEan()
    {
        return Regex.IsMatch(Input, RegexPatterns.EanPattern, RegexOptions.IgnoreCase);
    }
    public bool IsInputOrderNumber()
    {
        return Regex.IsMatch(Input, RegexPatterns.OrderNumberPattern, RegexOptions.IgnoreCase);
    }
    public bool IsInputGiftcardReference()
    {
        return Regex.IsMatch(Input, RegexPatterns.GiftcardReferencePattern, RegexOptions.IgnoreCase);
    }
}
