﻿namespace CustomerSearchService.BLL;

public class SearchProvider : ISearchProvider
{
    private readonly IServiceProvider _serviceProvider;

    public SearchProvider(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public async Task<List<SearchResult>> ExecuteSearch(SearchParameters searchParameters)
    {
        var command = GetSearchCommand(searchParameters);
        return await command.Execute(searchParameters);
    }

    private ISearchCommand GetSearchCommand(SearchParameters searchParameters)
    {
        if (searchParameters.IsInputEmail())
        {
            return _serviceProvider.GetRequiredService<SearchByEmail>();
        }

        if (searchParameters.IsInputDomain())
        {
            return _serviceProvider.GetRequiredService<SearchByDomain>();
        }

        if (searchParameters.IsInputGuid())
        {
            return _serviceProvider.GetRequiredService<SearchBySsoId>();
        }

        if (searchParameters.IsInputAccountNumber())
        {
            return _serviceProvider.GetRequiredService<SearchByAccountNumber>();
        }

        if (searchParameters.IsInputPaymentNumber())
        {
            return _serviceProvider.GetRequiredService<SearchByPaymentNumber>();
        }

        if (searchParameters.IsInputPhoneNumber())
        {
            return _serviceProvider.GetRequiredService<SearchByPhoneNumber>();
        }

        if (searchParameters.IsInputSubscriptionNumber())
        {
            return _serviceProvider.GetRequiredService<SearchBySubscriptionNumber>();
        }

        if (searchParameters.IsInputInvoiceNumber())
        {
            return _serviceProvider.GetRequiredService<SearchByInvoiceNumber>();
        }

        if (searchParameters.IsInputCvr())
        {
            return _serviceProvider.GetRequiredService<SearchByCvr>();
        }

        if (searchParameters.IsPipedriveId())
        {
            return _serviceProvider.GetRequiredService<SearchByPipedriveId>();
        }

        if (searchParameters.IsEan())
        {
            return _serviceProvider.GetRequiredService<SearchByEan>();
        }

        if (searchParameters.IsInputOrderNumber())
        {
            return _serviceProvider.GetRequiredService<SearchByOrderNumber>();
        }

        if (searchParameters.IsInputGiftcardReference())
        {
            return _serviceProvider.GetRequiredService<SearchByGiftcardReference>();
        }

        // If nothing else, search by name
        return _serviceProvider.GetRequiredService<SearchByNameBetter>();
    }
}
