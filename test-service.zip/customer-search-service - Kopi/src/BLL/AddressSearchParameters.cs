﻿namespace CustomerSearchService.BLL;

public class AddressSearchParameters
{    
    public string MasterAddressPointId { get; internal set; }
    public string ZipCode { get; internal set; }
    public string Street { get; internal set; }
    public string HouseNumber { get; internal set; }
    public string HouseLetter { get; internal set; }
    public string HouseFloor { get; internal set; }
    public string HouseSide { get; internal set; }
    public List<string> Brands { get; internal set; }
    public List<string> PublicationCodes { get; internal set; }

    public AddressSearchParameters(string masterAddressPointId, string zipCode, string street, string houseNumber, string houseLetter, string houseFloor, string houseSide, string brands, string publicationCodes = "")
    {
        MasterAddressPointId = masterAddressPointId.Trim();
        ZipCode = zipCode.Trim();
        Street = street.Trim();
        HouseNumber = houseNumber.Trim();
        HouseLetter = houseLetter.Trim();
        HouseFloor = houseFloor.Trim();
        HouseSide = houseSide.Trim();
        Brands = brands.Split(',').Select(x => x.Trim()).ToList();
        PublicationCodes = publicationCodes.Split(',').Select(x => x.Trim()).ToList();
    }

    public bool IsMasterAddressPointId()
    {
        return Regex.IsMatch(MasterAddressPointId, RegexPatterns.AddressPointIdPattern, RegexOptions.IgnoreCase);
    }

    public bool IsAddress()
    {
        return Regex.IsMatch(ZipCode, RegexPatterns.ZipCode, RegexOptions.IgnoreCase) && Street != "";
    }
}
