﻿namespace CustomerSearchService.BLL;

public class AddressSearchProvider : IAddressSearchProvider
{
    private readonly IServiceProvider _serviceProvider;

    public AddressSearchProvider(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    public async Task<List<SearchResult>> ExecuteSearch(AddressSearchParameters searchParameters)
    {
        var command = GetSearchCommand(searchParameters);
        if (command == null) throw new ArgumentException($"Search parameters are invalid.");

        return await command.Execute(searchParameters);
    }

    private IAddressSearchCommand? GetSearchCommand(AddressSearchParameters searchParameters)
    {
        if (searchParameters.IsMasterAddressPointId())
        {
            return _serviceProvider.GetRequiredService<SearchByAddressPointId>();
        }

        if (searchParameters.IsAddress())
        {
            return _serviceProvider.GetRequiredService<SearchByAddress>();
        }

        return null;
    }
}
