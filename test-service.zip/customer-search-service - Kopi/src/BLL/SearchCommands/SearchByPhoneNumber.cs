﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByPhoneNumber : ISearchCommand
{
    private readonly ISsoService _ssoService;
    private readonly IZuoraService _zuoraService;

    public SearchByPhoneNumber(ISsoService ssoService, IZuoraService zuoraService)
    {
        _ssoService = ssoService;
        _zuoraService = zuoraService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var searchResults = await Task.WhenAll(
            SearchByPhoneNumberInSso(searchParameters.Input),
            SearchByPhoneNumberInZuora(searchParameters.Input, searchParameters.Brands)
            );

        //If all results belong to the same account then just pick the "best" result.
        //Else return all results. This is how business wants it apparently...
        //Order subscriptions by the newest ones first (by using the incremental subscriptionnumber)
        //to alleviate us picking a subscription that is actually not active (e.g. a trial that
        //has expired by itself but never been explicitly cancelled).
        var prioritizedResults = searchResults
            .SelectMany(x => x)
            .OrderBy(x => x.DataSource)  //Prioritize sso over zuora
            .ThenByDescending(x => x.Active)  //Null is always last in this ordering
            .ThenByDescending(x => x.ZuoraSubscriptionNumber)  //Null is always last in this ordering
            .ThenBy(x => x.Name)
            .ThenBy(x => x.Email)
            .ToList();

        List<SearchResult> res;
        if (prioritizedResults.Any() && prioritizedResults.All(x => x.ZuoraAccountNumber == prioritizedResults[0].ZuoraAccountNumber))  //This also takes into account if ZuoraAccountNumber is null which is the case if there is a hit from sso.
        {
            res = new List<SearchResult> { prioritizedResults[0] };
        }
        else
        {
            res = prioritizedResults;
        }

        return res;
    }

    private async Task<List<SearchResult>> SearchByPhoneNumberInSso(string phoneNumber)
    {
        // These comments were copied from the CustomerOverview solution. Maybe they are no longer valid?
        // All tenants strategy check SSO Service, which will return results from SSO
        var userIds = await _ssoService.GetMatchingUsersByPhoneNumber(phoneNumber, true); //TODO: this line seems to throw an exception upon no matches
        if (!userIds.Any()) return new List<SearchResult>();

        var users = await _ssoService.GetSsoUsers(userIds);

        return users.Select(x => new SearchResult
        {
            SsoId = x.SsoId,
            IdentType = "SsoId",
            DataSource = "SSO",
            Name = $"{x.Firstname} {x.Lastname}".Trim(),
            Email = x.Email
        }).ToList();
    }

    private async Task<List<SearchResult>> SearchByPhoneNumberInZuora(string phoneNumber, List<string> brands)
    {
        var contacts = await _zuoraService.GetContactsFromPhoneNumberAsync(phoneNumber);

        var result = new List<SearchResult>();
        foreach (var contact in contacts)
        {
            var account = await _zuoraService.GetAccount(contact.AccountId);
            if (account != null && brands.Contains(account.BasicInfo.BrandC))
            {
                var subscriptions = await _zuoraService.GetSubscriptionsByAccountId(contact.AccountId);
                if (subscriptions.Count > 0)
                {
                    foreach (var subscription in subscriptions)
                    {
                        result.Add(MapToSearchResult(contact, account, subscription));
                    }
                }
                else
                {
                    result.Add(MapToSearchResult(contact, account));
                }
            }
        }

        return result;
    }

    private static SearchResult MapToSearchResult(ZuoraContact contact, ZuoraClient.NET.RestApi.Model.AccountApi.Account account, SubscriptionCompact? subscription = null)
    {
        var res = new SearchResult
        {
            DataSource = "Zuora",
            IdentType = "Zuora kontonummer",
            SsoId = Guid.Parse(account.BasicInfo.SsoIdC),
            ZuoraAccountNumber = account.BasicInfo.AccountNumber,
            Name = $"{account.BillToContact.FirstName} {account.BillToContact.LastName}".Trim(),
            Email = account.BillToContact.PersonalEmail,
            CompanyName = contact.CompanyName__c
        };

        if(subscription != null)
        {
            res.ZuoraSubscriptionNumber = subscription.Name;
            res.Active = subscription.Status == "Active";
        }

        return res;
    }
}
