﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByCvr : ISearchCommand
{
    private readonly IZuoraService _zuoraService;

    public SearchByCvr(IZuoraService zuoraService)
    {
        _zuoraService = zuoraService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        // CVR input format is DK________, so to get the number part, we replace DK
        var cvr = Regex.Replace(searchParameters.Input, "DK", "", RegexOptions.IgnoreCase);
        var contacts = await _zuoraService.GetContactsByCvr(cvr);

        return await GetSearchResults(contacts, searchParameters.Brands);
    }

    private async Task<List<SearchResult>> GetSearchResults(List<ZuoraContact> contacts, List<string> brands)
    {
        var result = new List<SearchResult>();
        foreach (var contact in contacts)
        {
            var account = await _zuoraService.GetAccount(contact.AccountId);
            if (account != null && brands.Contains(account.BasicInfo.BrandC))
            {
                var subscriptions = await _zuoraService.GetSubscriptionsByAccountId(contact.AccountId);
                if (subscriptions.Count > 0)
                {
                    foreach (var subscription in subscriptions)
                    {
                        result.Add(MapToSearchResult(contact, account, subscription));
                    }
                }
                else
                {
                    result.Add(MapToSearchResult(contact, account));
                }
            }
        }

        return result;
    }

    private static SearchResult MapToSearchResult(ZuoraContact contact, ZuoraClient.NET.RestApi.Model.AccountApi.Account account, SubscriptionCompact? subscription = null)
    {
        var res = new SearchResult
        {
            DataSource = "Zuora",
            IdentType = "Zuora kontonummer",
            SsoId = Guid.Parse(account.BasicInfo.SsoIdC),
            ZuoraAccountNumber = account.BasicInfo.AccountNumber,
            Name = $"{account.BillToContact.FirstName} {account.BillToContact.LastName}".Trim(),
            Email = account.BillToContact.PersonalEmail,
            CompanyName = contact.CompanyName__c
        };

        if(subscription != null)
        {
            res.ZuoraSubscriptionNumber = subscription.Name;
            res.Active = subscription.Status == "Active";
        }

        return res;
    }
}
