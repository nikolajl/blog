﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByAccountNumber : ISearchCommand
{
    private readonly IZuoraService _zuoraService;

    public SearchByAccountNumber(IZuoraService zuoraService)
    {
        _zuoraService = zuoraService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        return await SearchAccountInZuora(searchParameters.Input, searchParameters.Brands);
    }

    private async Task<List<SearchResult>> SearchAccountInZuora(string accountNumber, List<string> brands)
    {
        var result = new List<SearchResult>();

        var account = await _zuoraService.GetAccount(accountNumber);
        if (account != null && brands.Contains(account.BasicInfo.BrandC))
        {
            if (brands.Contains(account.BasicInfo.BrandC))
            {
                var res = new SearchResult
                {
                    DataSource = "Zuora",
                    IdentType = "Zuora kontonummer",
                    SsoId = Guid.Parse(account.BasicInfo.SsoIdC),
                    ZuoraAccountNumber = account.BasicInfo.AccountNumber,
                    Name = $"{account.BillToContact.FirstName} {account.BillToContact.LastName}".Trim(),
                    Email = account.BillToContact.PersonalEmail
                };
                result.Add(res);
            }
        }

        return result;
    }

}
