﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByEmail : ISearchCommand
{
    private readonly ISsoService _ssoService;
    private readonly IZuoraService _zuoraService;
    private readonly ISubscriptionRelationService _subscriptionRelationService;
    private readonly IAccessAgreementService _accessAgreementService;

    public SearchByEmail(ISsoService ssoService, IZuoraService zuoraService, ISubscriptionRelationService subscriptionRelationService, IAccessAgreementService accessAgreementService)
    {
        _ssoService = ssoService;
        _zuoraService = zuoraService;
        _subscriptionRelationService = subscriptionRelationService;
        _accessAgreementService = accessAgreementService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var result = await Task.WhenAll(
            SearchByEmailInUserService(searchParameters.Input),
            SearchByEmailInZuora(searchParameters.Input, searchParameters.Brands),
            SearchByEmailInSrs(searchParameters.Input, searchParameters.Brands),
            SearchByEmailInAas(searchParameters.Input, searchParameters.Brands)
        );

        // TODO: SearchByPhoneNumber only returns results from Sso if the match does not exist in Zuora. Search for email does not. Should we correct it here?
        //.UnionBy(searchResultsSso, x => x.SsoId)
        // Would the above code would cause problems with SRS, if for instance an account has access through 2 different subscriptions, owned by the same ssoid? 
        return result
            .SelectMany(x => x)
            // TODO: Do this? .DistinctBy(x => x.ZuoraSubscriptionNumber) // Remove results with same SubscriptionNumber (only relevant for results from SRS and Zuora)
            .OrderBy(x => x.DataSource)
            .ThenByDescending(x => x.Active)
            .ThenBy(x => x.Name)
            .ThenBy(x => x.Email)
            .ToList();
    }

    private async Task<List<SearchResult>> SearchByEmailInUserService(string input)
    {
        var results = new List<SearchResult>();
        var res = await _ssoService.LookupSsoUserByEmail(input);
        if (res == null)
            return new List<SearchResult>();

        results.Add(new SearchResult
        {
            SsoId = res.SsoId,
            IdentType = "Stamoplysning",
            DataSource = "MedieLogin"
        });

        return results;
    }

    private async Task<List<SearchResult>> SearchByEmailInZuora(string email, List<string> brands)
    {
        var result = new List<SearchResult>();

        var contacts = await _zuoraService.GetContactsFromEmailAsync(email);

        foreach (var contact in contacts)
        {
            var account = await _zuoraService.GetAccount(contact.AccountId);
            if (account != null && brands.Contains(account.BasicInfo.BrandC))
            {
                var subscriptions = await _zuoraService.GetSubscriptionsByAccountId(contact.AccountId);
                if (subscriptions.Count > 0)
                {
                    foreach (var subscription in subscriptions)
                    {
                        result.Add(MapToSearchResult(contact, account, subscription));
                    }
                }
                else
                {
                    result.Add(MapToSearchResult(contact, account));
                }
            }
        }

        return result;
    }

    private async Task<List<SearchResult>> SearchByEmailInSrs(string email, List<string> brands)
    {
        if (string.IsNullOrEmpty(email)) throw new ArgumentNullException(nameof(email), "Email can not be null or empty");
        if (brands == null) throw new ArgumentNullException(nameof(brands), "Brand list can not be empty");

        var results = new List<SearchResult>();

        // First get SsoId(s) from UserService
        var ssoUser = await _ssoService.LookupSsoUserByEmail(email);
        if (ssoUser == null) return results;

        // Then call SRS with SsoId
        var subscriptionNumbers = await _subscriptionRelationService.GetSubscriptionsBySsoId(ssoUser.SsoId);

        // Get Subscription info from Zuora for each subscription
        foreach (var subscriptionNumber in subscriptionNumbers)
        {
            var zuoraSub = await _zuoraService.GetSubscriptionBySubscriptionNumber(subscriptionNumber);
            if (zuoraSub == null) continue;

            // Get Account info for each zuora subscription
            var zuoraAccount = await _zuoraService.GetAccount(zuoraSub.AccountId);

            // If the account doesn't belong to a brand relevant to the search, skip further processing
            if (zuoraAccount == null || !brands.Contains(zuoraAccount.BasicInfo.BrandC)) continue;
            // TODO: Should we return partial data, if we can't get account from Zuora? We do have SubscriptionNumber here, and could return this partial result, which could then be searched for

            // Map to List<SearchResult> and return it
            results.Add(new SearchResult
            {
                DataSource = "SubscriptionRelationService/Zuora",
                IdentType = "Zuora kontonummer",
                SsoId = Guid.Parse(zuoraAccount.BasicInfo.SsoIdC),
                ZuoraAccountNumber = zuoraAccount.BasicInfo.AccountNumber,
                Name = $"{zuoraAccount.BillToContact.FirstName} {zuoraAccount.BillToContact.LastName}",
                Email = zuoraAccount.BillToContact.PersonalEmail,
                CompanyName = zuoraAccount.BillToContact.CompanyNameC,
                ZuoraSubscriptionNumber = subscriptionNumber,
                Active = zuoraSub.Status == "Active"
            });
        }

        return results;
    }

    private async Task<List<SearchResult>> SearchByEmailInAas(string email, List<string> brands)
    {
        if (string.IsNullOrEmpty(email)) throw new ArgumentNullException(nameof(email), "Email can not be null or empty");
        if (brands == null) throw new ArgumentNullException(nameof(brands), "Brand list can not be empty");

        var results = new List<SearchResult>();
        var accessAgreements = await _accessAgreementService.GetAccessAgreementsByEmail(email);

        foreach (var accessAgreement in accessAgreements)
        {
            // Get account info from zuora, relevant to the AccessAgreement
            var zuoraAccount = await _zuoraService.GetAccount(accessAgreement.AccountNumber);

            // If the account doesn't belong to a brand relevant to the search, skip further processing
            if (zuoraAccount == null || !brands.Contains(zuoraAccount.BasicInfo.BrandC)) continue;

            results.Add(new SearchResult()
            {
                DataSource = "AccessAgreementService",
                IdentType = "Zuora kontonummer",
                SsoId = Guid.Parse(zuoraAccount.BasicInfo.SsoIdC),
                ZuoraAccountNumber = zuoraAccount.BasicInfo.AccountNumber,
                Name = $"{zuoraAccount.BillToContact.FirstName} {zuoraAccount.BillToContact.LastName}",
                Email = zuoraAccount.BillToContact.PersonalEmail,
                CompanyName = zuoraAccount.BillToContact.CompanyNameC,
            });
        }

        return results;
    }

    private static SearchResult MapToSearchResult(ZuoraContact contact, ZuoraClient.NET.RestApi.Model.AccountApi.Account account, SubscriptionCompact? subscription = null)
    {
        var res = new SearchResult
        {
            DataSource = "Zuora",
            IdentType = "Zuora kontonummer",
            SsoId = Guid.Parse(account.BasicInfo.SsoIdC),
            ZuoraAccountNumber = account.BasicInfo.AccountNumber,
            Name = $"{account.BillToContact.FirstName} {account.BillToContact.LastName}".Trim(),
            Email = account.BillToContact.PersonalEmail,
            CompanyName = contact.CompanyName__c
        };

        if (subscription != null)
        {
            res.ZuoraSubscriptionNumber = subscription.Name;
            res.Active = subscription.Status == "Active";
        }

        return res;
    }
}
