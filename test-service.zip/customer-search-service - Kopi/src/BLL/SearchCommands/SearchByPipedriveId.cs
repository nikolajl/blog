﻿
namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByPipedriveId: ISearchCommand
{
    private readonly IAccountRelationService _accountRelationService;
    private readonly IZuoraService _zuoraService;

    public SearchByPipedriveId(IAccountRelationService accountRelationService, IZuoraService zuoraService)
    {
        _accountRelationService = accountRelationService;
        _zuoraService = zuoraService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var result = new List<SearchResult>();

        foreach (var brand in searchParameters.Brands)
        {
            var searchResults = await SearchPipedriveIdInAccountRelationService(searchParameters.Input, brand);
            if (searchResults != null)
                result.AddRange(searchResults);
        }
        return result;
    }

    private async Task<List<SearchResult>> SearchPipedriveIdInAccountRelationService(string pipedriveId, string brand)
    {
        var results = new List<SearchResult>();
        var res = await _accountRelationService.SearchByPipedriveId(pipedriveId, brand);
        
        if (res == null)
            return results;
        
        foreach (var accountNumber in res)
        {
            var account = await _zuoraService.GetAccount(accountNumber);
            if (account != null && brand.Contains(account.BasicInfo.BrandC))
            {
                if (brand.Contains(account.BasicInfo.BrandC))
                {
                    var tmp = new SearchResult
                    {
                        DataSource = "Account relation service/Zuora",
                        IdentType = "Zuora kontonummer",
                        SsoId = Guid.Parse(account.BasicInfo.SsoIdC),
                        ZuoraAccountNumber = account.BasicInfo.AccountNumber,
                        Name = $"{account.BillToContact.FirstName} {account.BillToContact.LastName}".Trim(),
                        Email = account.BillToContact.PersonalEmail,
                    };
                    results.Add(tmp);
                }
            }
        }
        return results;
    }

}
