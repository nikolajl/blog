﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByName : ISearchCommand
{
    private readonly ISsoService _ssoService;
    private readonly IZuoraService _zuoraService;
    private readonly IDistributionService _distributionService;

    public SearchByName(ISsoService ssoService, IZuoraService zuoraService, IDistributionService distributionService)
    {
        _ssoService = ssoService;
        _zuoraService = zuoraService;
        _distributionService = distributionService;
    }

    // TODO: Deprecated search. Remove when renaming SearchByNameBetter => SearchByName 
    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var publicationCodes = searchParameters.PublicationCodes;
        
        var nameParts = searchParameters.Input.Split(" ").Take(5);
        var name = string.Join(' ', nameParts);

        var searchResults = await Task.WhenAll(
            SearchByNameInZuora(name, searchParameters.Brands),
            SearchByNameInDist(name, publicationCodes),
            SearchByNameInUserService(name)
        );

        return searchResults
        .SelectMany(x => x)
        .OrderByDescending(x =>
        {
            if (string.IsNullOrEmpty(x.Name) && string.IsNullOrEmpty(x.CompanyName))
            {
                return -1;
            }

            // If the name is a perfect match and consists of at least two names then sort it to the top as it's likely a better match
            if (nameParts.Count() > 1 && (
                string.Equals(name, x.Name, StringComparison.InvariantCultureIgnoreCase) ||
                string.Equals(name, x.CompanyName, StringComparison.InvariantCultureIgnoreCase)
                )
            )
            {
                return 10000;
            }

            // Sort the results that matches the most words to the top
            return nameParts.Count(y =>
                (x.Name?.Contains(y, StringComparison.InvariantCultureIgnoreCase) ?? false) ||
                (x.CompanyName?.Contains(y, StringComparison.InvariantCultureIgnoreCase) ?? false)
            );
        })
        .ToList();
    }

    public async Task<List<SearchResult>> SearchByNameInUserService(string name)
    {
        var ssoIds = await _ssoService.GetMatchingUsersByName(name);

        return ssoIds.Select(id => new SearchResult
        {
            SsoId = id,
            IdentType = "Stamoplysning",
            DataSource = "MedieLogin"
        }).ToList();
    }

    public async Task<List<SearchResult>> SearchByNameInDist(string input, List<string> publicationCodes)
    {
        var names = input.Split(' ');

        var subscribers = await Task.WhenAll(
            names.Select(namePart => _distributionService.DeprecatedSearchByName(publicationCodes, namePart))
        );

        return subscribers
            .SelectMany(x => x)
            .Select(item => new SearchResult
            {
                ZuoraSubscriptionNumber = item.SubscriptionNumber,
                Email = item.Email,
                Name = item.FirstName + " " + item.LastName,
                IdentType = "Leveringadresse",
                DataSource = "Distribution",
                CompanyName = item.CompanyName
            })
            .ToList();

    }

    public async Task<List<SearchResult>> SearchByNameInZuora(string name, List<string> brands)
    {
        var searchResults = new List<SearchResult>();

        var contacts = await _zuoraService.GetContactsForName(name);
        if (contacts.Count > 0)
        {
            var accounts = await _zuoraService.GetAccountsForContacts(contacts);

            foreach (var account in accounts)
            {
                if (brands.Contains(account.Brand__c)) //allow only brands owned by the tenant
                {
                    var relatedContact = contacts.First(x => x.AccountId == account.Id);
                    Guid.TryParse(account.SsoId__c, out var ssoId);
                    searchResults.Add(
                        new SearchResult
                        {
                            Email = relatedContact.PersonalEmail,
                            ZuoraAccountNumber = account.AccountNumber,
                            Name = $"{relatedContact.FirstName} {relatedContact.LastName}",
                            IdentType = "Betaleradresse",
                            DataSource = "Zuora",
                            CompanyName = relatedContact.CompanyName__c,
                            SsoId = ssoId
                        });
                }
            }
        }

        return searchResults;
    }

}
