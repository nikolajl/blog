﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchBySsoId : ISearchCommand
{
    private readonly ISsoService _ssoService;

    public SearchBySsoId(ISsoService ssoService)
    {
        _ssoService = ssoService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var result = new List<SearchResult>();
        var ssoUser = await _ssoService.LookupSsoUserBySsoId(searchParameters.Input);

        if (ssoUser != null)
            result.Add(new SearchResult
            {
                SsoId = ssoUser.SsoId,
                Email = ssoUser.Email,
                Name = $"{ssoUser.Firstname} {ssoUser.Lastname}".Trim(),
            });

        return result;
    }
}
