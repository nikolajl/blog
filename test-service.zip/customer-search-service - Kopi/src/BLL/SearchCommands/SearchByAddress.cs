﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByAddress : IAddressSearchCommand
{
    private readonly ISsoService _ssoService;
    private readonly IZuoraService _zuoraService;
    private readonly IDistributionService _distributionService;

    public SearchByAddress(ISsoService ssoService, IZuoraService zuoraService, IDistributionService distributionService)
    {
        _ssoService = ssoService;
        _zuoraService = zuoraService;
        _distributionService = distributionService;
    }

    public async Task<List<SearchResult>> Execute(AddressSearchParameters searchParameters)
    {
        var publicationCodes = searchParameters.PublicationCodes;
        var zipCode = searchParameters.ZipCode.Trim();
        var street = searchParameters.Street.Trim();
        var houseNumber = searchParameters.HouseNumber.Trim();
        var houseLetter = searchParameters.HouseLetter.Trim();
        var houseFloor= searchParameters.HouseFloor.Trim();
        var houseSide = searchParameters.HouseSide.Trim();

        var searchResults = await SearchByAddressInDist(zipCode, street, houseNumber, houseLetter, houseFloor, houseSide, publicationCodes);

        return searchResults
            .OrderBy(x => x.DataSource)
            .ThenByDescending(x => x.Active)
            .ThenBy(x => x.Name)
            .ThenBy(x => x.Email)
            .ToList();
    }

    public async Task<List<SearchResult>> SearchByAddressInDist(string zipCode, string street, string? houseNumber, string? houseLetter, string? houseFloor, string? houseSide, List<string> publicationCodes)
    {
        var searchResults = new List<SearchResult>();

        var subscribers = await _distributionService.SearchByAddress(publicationCodes, zipCode, street, houseNumber, houseLetter);

        foreach (var subscriber in subscribers)
        {
            //TODO - filter by houseFloor and houseSide
            if (!string.IsNullOrEmpty(houseLetter) && houseLetter != subscriber.HouseLetter)
                continue;

            if (!string.IsNullOrEmpty(houseFloor) && houseFloor != subscriber.Floor)
                continue;

            if (!string.IsNullOrEmpty(houseSide) && houseSide != subscriber.SideApartment)
                continue;

            searchResults.Add(new SearchResult
            {
                ZuoraSubscriptionNumber = subscriber.SubscriptionNumber,
                Email = subscriber.Email,
                Name = $"{subscriber.FirstName} {subscriber.LastName}",
                IdentType = "Leveringsadresse",
                DataSource = "Distribution",
                CompanyName = subscriber.CompanyName
            });
        }

        return searchResults;
    }
}
