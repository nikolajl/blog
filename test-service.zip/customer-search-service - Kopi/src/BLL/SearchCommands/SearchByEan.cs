﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByEan : ISearchCommand
{
    private readonly IZuoraService _zuoraService;

    public SearchByEan(IZuoraService zuoraService)
    {
        _zuoraService = zuoraService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var result = new List<SearchResult>();

        var ean = Regex.Replace(searchParameters.Input, "EAN", "", RegexOptions.IgnoreCase);
        var accounts = await _zuoraService.GetAccountsByEan(ean);
        var contacts = await _zuoraService.GetContactsByAccounts(accounts.Where(account => searchParameters.Brands.Contains(account.Brand__c)));

        foreach (var contact in contacts)
        {
            var account = accounts.FirstOrDefault(account => account.Id == contact.AccountId);
            if (account != null)
            {
                result.Add(new SearchResult
                {
                    DataSource = "Zuora",
                    IdentType = "Zuora kontonummer",
                    SsoId = Guid.Parse(account.SsoId__c),
                    ZuoraAccountNumber = account.AccountNumber,
                    Name = contact.Name,
                    Email = contact.PersonalEmail,
                    CompanyName = contact.CompanyName__c
                });
            }
        }

        return result;
    }
}
