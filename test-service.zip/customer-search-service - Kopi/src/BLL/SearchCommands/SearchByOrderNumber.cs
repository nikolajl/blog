﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByOrderNumber : ISearchCommand
{
    private readonly ISubscriptionOrderService _subscriptionOrderService;

    public SearchByOrderNumber(ISubscriptionOrderService subscriptionOrderService)
    {
        _subscriptionOrderService = subscriptionOrderService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var results = new List<SearchResult>();

        var order = await _subscriptionOrderService.GetOrderByOrderNumber(searchParameters.Input);
        if (order != null)
        {
            // TODO: Original search doesn't care about brand, maybe we should?
            // if (searchParameters.Brands.Contains(order.SubscriptionOrderBrandEnumString))
            results.Add(new SearchResult
            {
                SsoId = order.SsoId,
                OrderNumber = order.OrderNumber
            });
        }

        return results;
    }
}
