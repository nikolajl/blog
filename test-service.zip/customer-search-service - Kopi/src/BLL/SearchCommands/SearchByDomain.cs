﻿using UserServiceClient.Model;

namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByDomain : ISearchCommand
{
    private readonly ISsoService _ssoService;
    private readonly IZuoraService _zuoraService;
    private readonly IDistributionService _distributionService;

    public SearchByDomain(ISsoService ssoService, IZuoraService zuoraService, IDistributionService distributionService)
    {
        _ssoService = ssoService;
        _zuoraService = zuoraService;
        _distributionService = distributionService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var result = await Task.WhenAll(
            SearchByDomainInUserService(searchParameters.Input),
            SearchByDomainInZuora(searchParameters.Input, searchParameters.Brands),
            SearchByDomainInDist(searchParameters.Input, searchParameters.PublicationCodes)
        );

        return result
            .SelectMany(x => x)
            .OrderBy(x => x.DataSource)
            .ThenByDescending(x => x.Active)
            .ThenBy(x => x.Name)
            .ThenBy(x => x.Email)
            .ToList();
    }

    private async Task<List<SearchResult>> SearchByDomainInUserService(string input)
    {
        var results = new List<SearchResult>();
        var users = await _ssoService.LookupSsoUserByDomain(input);

        var FormatName = (SsoUser user) => $"{user.Firstname} {user.Lastname}".Trim();
        return users
            .Select(user => new SearchResult
            {
                SsoId = user.SsoId,
                IdentType = "Stamoplysning",
                DataSource = "MedieLogin",
                Name = FormatName(user),
                Email = user.Email,
            })
            .ToList();
    }

    private async Task<List<SearchResult>> SearchByDomainInZuora(string domain, List<string> brands)
    {
        var result = new List<SearchResult>();

        var contacts = await _zuoraService.GetContactsFromDomainAsync(domain);

        foreach (var contact in contacts)
        {
            var account = await _zuoraService.GetAccount(contact.AccountId);
            if (account != null && brands.Contains(account.BasicInfo.BrandC))
            {
                var subscriptions = await _zuoraService.GetSubscriptionsByAccountId(contact.AccountId);
                if (subscriptions.Count > 0)
                {
                    foreach (var subscription in subscriptions)
                    {
                        result.Add(MapToSearchResult(contact, account, subscription));
                    }
                }
                else
                {
                    result.Add(MapToSearchResult(contact, account));
                }
            }
        }

        return result;
    }

    private async Task<List<SearchResult>> SearchByDomainInDist(string domain, List<string> publicationCodes)
    {
        var result = new List<SearchResult>();

        var subscribers = await _distributionService.SearchByDomain(publicationCodes, domain);

        var FormatName = (DistClient.NET.Model.Distribution.Subscriber item) => $"{item.FirstName} {item.LastName}".Trim();
        return subscribers
            .Select(item => new SearchResult
            {
                ZuoraSubscriptionNumber = item.SubscriptionNumber,
                Email = item.Email,
                Name = FormatName(item),
                IdentType = "Leveringadresse",
                DataSource = "Distribution",
                CompanyName = item.CompanyName,
            })
            .ToList();
    }


    private static SearchResult MapToSearchResult(ZuoraContact contact, ZuoraClient.NET.RestApi.Model.AccountApi.Account account, SubscriptionCompact? subscription = null)
    {
        var res = new SearchResult
        {
            DataSource = "Zuora",
            IdentType = "Zuora kontonummer",
            SsoId = Guid.Parse(account.BasicInfo.SsoIdC),
            ZuoraAccountNumber = account.BasicInfo.AccountNumber,
            Name = $"{account.BillToContact.FirstName} {account.BillToContact.LastName}".Trim(),
            Email = account.BillToContact.PersonalEmail,
            CompanyName = contact.CompanyName__c
        };

        if (subscription != null)
        {
            res.ZuoraSubscriptionNumber = subscription.Name;
            res.Active = subscription.Status == "Active";
        }

        return res;
    }
}
