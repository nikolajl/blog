﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByInvoiceNumber : ISearchCommand
{
    private readonly IZuoraService _zuoraService;

    public SearchByInvoiceNumber(IZuoraService zuoraService)
    {
        _zuoraService = zuoraService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var result = new List<SearchResult>();
        var invoice = await _zuoraService.GetInvoice(searchParameters.Input);
        if (invoice != null)
        {
            var account = await _zuoraService.GetAccount(invoice.AccountId);
            if (account != null && searchParameters.Brands.Contains(account.BasicInfo.BrandC))
            {
                result.Add(new SearchResult
                {
                    SsoId = new Guid(account.BasicInfo.SsoIdC),
                    ZuoraAccountId = account.BasicInfo.Id,
                    ZuoraAccountNumber = account.BasicInfo.AccountNumber,
                    ZuoraInvoiceId = invoice.Id
                });
            }
        }

        return result;
    }
}
