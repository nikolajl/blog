﻿using UserServiceClient.Model;

namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByNameBetter : ISearchCommand
{
    private readonly ISsoService _ssoService;
    private readonly IZuoraService _zuoraService;
    private readonly IDistributionService _distributionService;

    public SearchByNameBetter(ISsoService ssoService, IZuoraService zuoraService, IDistributionService distributionService)
    {
        _ssoService = ssoService;
        _zuoraService = zuoraService;
        _distributionService = distributionService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var name = searchParameters.Input;

        var searchResults = await Task.WhenAll(
            SearchByNameInZuora(name, searchParameters.Brands, 200),
            SearchByNameInDist(name, searchParameters.PublicationCodes),
            SearchByNameInUserService(name)
        );

        return searchResults[0]
            .Union(searchResults[1])
            .Union(searchResults[2])
            //.UnionBy(searchResults[1], x => x.SsoId) // Distribution returns "ssoId": "00000000-0000-0000-0000-000000000000", so we can't use that
            //.UnionBy(searchResults[2], x => x.SsoId)
            .OrderByDescending(x => x.Score)
            .ThenBy(x => x.Name)
            .ThenBy(x => x.CompanyName)
            .ToList();
    }

    public async Task<List<SearchResult>> SearchByNameInUserService(string name)
    {
        var ssoIds = await _ssoService.GetMatchingUsersByName(name);
        var users = await _ssoService.GetSsoUsers(ssoIds);

        var FormatName = (SsoUser user) => $"{user.Firstname} {user.Lastname}".Trim();

        return users
            .Select(user => new SearchResult
            {
                SsoId = user.SsoId,
                IdentType = "Stamoplysning",
                DataSource = "MedieLogin",
                Name = FormatName(user),
                Email = user.Email,
                Score = FuzzySharp.Fuzz.WeightedRatio(name, FormatName(user))
            })
            .Where(x => x.Score > 50)
            .ToList();
    }

    public async Task<List<SearchResult>> SearchByNameInDist(string name, List<string> publicationCodes)
    {
        var subscribers = await _distributionService.SearchByName(publicationCodes, name);

        var FormatName = (DistClient.NET.Model.Distribution.Subscriber item) => $"{item.FirstName} {item.LastName}".Trim();

        return subscribers
            .Select(item => new SearchResult
            {
                ZuoraSubscriptionNumber = item.SubscriptionNumber,
                Email = item.Email,
                Name = FormatName(item),
                IdentType = "Leveringadresse",
                DataSource = "Distribution",
                CompanyName = item.CompanyName,
                Score = FuzzySharp.Fuzz.WeightedRatio(name, $"{item.CompanyName}, {FormatName(item)}")
            })
            .Where(x => x.Score > 50)
            .ToList();
    }

    public async Task<List<SearchResult>> SearchByNameInZuora(string name, List<string> brands, int limit = 20)
    {
        var contacts = await _zuoraService.GetContactsByName(name);

        var matches = contacts
            .Select(x => new { Contact = x, Score = FuzzySharp.Fuzz.WeightedRatio(name, x.Name) })
            .Where(x => x.Contact.AccountId != null)
            .Where(x => x.Score > 50)
            .OrderByDescending(x => x.Score)
            .Take(limit)
            .Select(x => x.Contact);

        var accounts = await _zuoraService.GetAccountsForContacts(matches);
        return accounts
            .Where(account => brands.Contains(account.Brand__c))
            .Select(account =>
            {
                try
                {
                    var contact = contacts.First(contact => contact.AccountId == account.Id);
                    return new SearchResult
                    {
                        Email = contact.PersonalEmail,
                        ZuoraAccountNumber = account.AccountNumber,
                        Name = $"{contact.FirstName} {contact.LastName}",
                        IdentType = "Betaleradresse",
                        DataSource = "Zuora",
                        CompanyName = contact.CompanyName__c,
                        SsoId = Guid.Parse(account.SsoId__c),
                        Score = FuzzySharp.Fuzz.WeightedRatio(name, contact.Name)
                    };
                }
                // When ssoId is not valid, don't include it in the search result.
                catch (FormatException)
                {
                    return null;
                }
            })
            .Where(x => x != null)
            .OfType<SearchResult>()
            .ToList();
    }

}
