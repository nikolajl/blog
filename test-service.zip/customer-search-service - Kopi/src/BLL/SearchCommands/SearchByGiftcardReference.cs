﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByGiftcardReference : ISearchCommand
{
    private readonly IZuoraService _zuoraService;

    public SearchByGiftcardReference(IZuoraService zuoraService)
    {
        _zuoraService = zuoraService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var results = new List<SearchResult>();

        var giftref = searchParameters.Input.Replace("GK-", "", StringComparison.InvariantCultureIgnoreCase);
        if (string.IsNullOrEmpty(giftref))
        {
            return results;
        }

        var rateplans = await _zuoraService.GetSubscriptionRatePlanByGiftcardReference(giftref);

        var subscriptionIdList = rateplans!.Select(x => x.SubscriptionId).Distinct().ToList();
        var subscriptionList = await _zuoraService.GetSubscriptionsBySubscriptionIds(subscriptionIdList);

        subscriptionList = subscriptionList!.Where(x => x.Status != "Expired").ToList();

        foreach (var sub in subscriptionList)
        {
            var account = await _zuoraService.GetAccount(sub.AccountId);
            if (account != null && searchParameters.Brands.Contains(account.BasicInfo.BrandC))
            {
                results.Add(new SearchResult
                {
                    SsoId = new Guid(account.BasicInfo.SsoIdC),
                    ZuoraAccountId = account.BasicInfo.Id,
                    ZuoraAccountNumber = account.BasicInfo.AccountNumber,
                    ZuoraSubscriptionNumber = sub.Name
                });
            }
        }

        return results;
    }

}
