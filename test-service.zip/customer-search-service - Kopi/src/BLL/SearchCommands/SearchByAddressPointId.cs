﻿using ZuoraClient.NET.RestApi.Model.AccountApi;

namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByAddressPointId : IAddressSearchCommand
{
    private readonly ISsoService _ssoService;
    private readonly IZuoraService _zuoraService;
    private readonly IDistributionService _distributionService;

    public SearchByAddressPointId(ISsoService ssoService, IZuoraService zuoraService, IDistributionService distributionService)
    {
        _ssoService = ssoService;
        _zuoraService = zuoraService;
        _distributionService = distributionService;
    }

    public async Task<List<SearchResult>> Execute(AddressSearchParameters searchParameters)
    {
        var publicationCodes = searchParameters.PublicationCodes;
        var masterAddressPointId = searchParameters.MasterAddressPointId;

        var searchResults = await Task.WhenAll(
            SearchByMasterAddressPointIdInZuora(masterAddressPointId, searchParameters.Brands),
            SearchByMasterAddressPointIdInDist(masterAddressPointId, publicationCodes, searchParameters.Brands)
        );

        return searchResults
            .SelectMany(x => x)
            .OrderBy(x => x.DataSource)
            .ThenByDescending(x => x.Active)
            .ThenBy(x => x.Name)
            .ThenBy(x => x.Email)
            .ToList();
    }

    public async Task<List<SearchResult>> SearchByMasterAddressPointIdInDist(string masterAddressPointId, List<string> publicationCodes, List<string> brands)
    {
        var searchResults = new List<SearchResult>();

        // Get subscribers from masterAddressPointId
        var subscribers = await _distributionService.SearchByMasterAddressPointId(publicationCodes, masterAddressPointId);

        foreach (var subscriber in subscribers)
        {
            var searchResult = new SearchResult
            {
                DataSource = "Distribution",
                IdentType = "Leveringsadresse",
                Name = $"{subscriber.FirstName} {subscriber.LastName}",
                Email = subscriber.Email,
                CompanyName = subscriber.CompanyName,
                ZuoraSubscriptionNumber = subscriber.SubscriptionNumber,
            };

            var subscription = await _zuoraService.GetSubscriptionBySubscriptionNumber(subscriber.SubscriptionNumber);

            if (subscription != null)
            {
                var account = await _zuoraService.GetAccount(subscription.AccountId);

                if (account != null && Guid.TryParse(account.BasicInfo.SsoIdC, out var ssoId))
                {
                    searchResult.SsoId = ssoId;
                }
            }

            searchResults.Add(searchResult);
        }

        return searchResults;
    }

    public async Task<List<SearchResult>> SearchByMasterAddressPointIdInZuora(string masterAddressPointId, List<string> brands)
    {
        var searchResults = new List<SearchResult>();

        var contacts = await _zuoraService.GetContactsByMasterAddressPointId(masterAddressPointId, brands);

        var accounts = await _zuoraService.GetAccountsForContacts(contacts);

        foreach (var account in accounts)
        {
            if (!brands.Contains(account.Brand__c)) continue; //allow only brands owned by the tenant

            //at this point the contact exists, otherwise the account would have never been found in the first place
            var relatedContact = contacts.First(x => x.AccountId == account.Id);
            Guid.TryParse(account.SsoId__c, out var ssoId);

            searchResults.Add(new SearchResult
            {
                Email = relatedContact.PersonalEmail,
                ZuoraAccountNumber = account.AccountNumber,
                Name = $"{relatedContact.FirstName} {relatedContact.LastName}",
                IdentType = "Betaleradresse",
                DataSource = "Zuora",
                CompanyName = relatedContact.CompanyName__c,
                SsoId = ssoId
            });
        }

        return searchResults;
    }
}
