﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchBySubscriptionNumber : ISearchCommand
{
    private readonly IZuoraService _zuoraService;

    public SearchBySubscriptionNumber(IZuoraService zuoraService)
    {
        _zuoraService = zuoraService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var results = new List<SearchResult>();

        var subscription = await _zuoraService.GetSubscriptionBySubscriptionNumber(searchParameters.Input);
        if (subscription != null)
        {
            var account = await _zuoraService.GetAccount(subscription.AccountId);
            if (account != null && searchParameters.Brands.Contains(account.BasicInfo.BrandC))
            {
                results.Add(new SearchResult
                {
                    SsoId = new Guid(account.BasicInfo.SsoIdC),
                    ZuoraAccountId = account.BasicInfo.Id,
                    ZuoraAccountNumber = account.BasicInfo.AccountNumber,
                    ZuoraSubscriptionNumber = subscription.Name
                });
            }
        }

        return results;
    }
}
