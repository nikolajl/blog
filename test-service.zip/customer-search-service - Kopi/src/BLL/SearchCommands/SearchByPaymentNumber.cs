﻿namespace CustomerSearchService.BLL.SearchCommands;

public class SearchByPaymentNumber : ISearchCommand
{
    private readonly IZuoraService _zuoraService;

    public SearchByPaymentNumber(IZuoraService zuoraService)
    {
        _zuoraService = zuoraService;
    }

    public async Task<List<SearchResult>> Execute(SearchParameters searchParameters)
    {
        var result = new List<SearchResult>();
        var payment = await _zuoraService.GetPaymentByPaymentNumber(searchParameters.Input);
        if (payment != null)
        {
            var invoice = await _zuoraService.GetInvoicePaymentByPaymentNumber(payment.Id);
            if (invoice != null)  //This means we return nothing for a payment that doesn't pay for an invoice, i.e. the whole amount goes to the account creditbalance
            {
                var account = await _zuoraService.GetAccount(payment.AccountId);
                if (account != null && searchParameters.Brands.Contains(account.BasicInfo.BrandC))
                {
                    result.Add(new SearchResult
                    {
                        SsoId = new Guid(account.BasicInfo.SsoIdC),
                        ZuoraAccountId = account.BasicInfo.Id,
                        ZuoraAccountNumber = account.BasicInfo.AccountNumber,
                        ZuoraPaymentNumber = payment.PaymentNumber,
                        ZuoraInvoiceId = invoice.InvoiceId
                    });
                }
            }
        }

        return result;
    }
}
