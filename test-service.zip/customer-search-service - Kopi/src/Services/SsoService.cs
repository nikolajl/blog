﻿using CustomerSearchService.Clients.Interfaces;
using UserServiceClient.Model;

namespace CustomerSearchService.Services;

public class SsoService : ISsoService
{
    private readonly IClientCreator _clientCreator;
    private readonly ILogHandler _logHandler;

    public SsoService(IClientCreator clientCreator, ILogHandler logHandler)
    {
        _clientCreator = clientCreator;
        _logHandler = logHandler;
    }

    public async Task<SsoUser?> LookupSsoUserByEmail(string email)
    {
        try
        {
            var api = _clientCreator.UserServiceApi();

            var res = await api.GetSsoUser(email);

            return res;
        }
        catch (JpPolitikensHus.UserServiceProxyNetCore.UnknownUserException)
        {
            //"User not found"
            return null;
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(email), email},
            });

            throw;
        }
    }

    public async Task<List<SsoUser>> LookupSsoUserByDomain(string domain)
    {
        try
        {
            var api = _clientCreator.UserServiceApi();
            var searchExpression = $"Username like \"%{domain}\"";
            var searchResult = await api.GetMatchingSsoUsersQueryAll(searchExpression);
            return await GetSsoUsers(searchResult);
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(domain), domain},
            });

            throw;
        }
    }

    public async Task<SsoUser?> LookupSsoUserBySsoId(string ssoId)
    {
        return await GetSsoUser(Guid.Parse(ssoId));
    }

    public async Task<SsoUser?> GetSsoUser(Guid ssoId)
    {
        try
        {
            var api = _clientCreator.UserServiceApi();
            var user = await api.GetSsoUser(ssoId);
            return user;
        }
        catch (JpPolitikensHus.UserServiceProxyNetCore.UnknownUserException)
        {
            // UserService throws UnknownUserException when not found, in that case return null
            return null;
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(ssoId), ssoId.ToString()},
            });

            throw;
        }
    }

    public async Task<List<SsoUser>> GetSsoUsers(IEnumerable<Guid> ssoGuids)
    {
        var result = new List<SsoUser>();

        foreach (var ssoId in ssoGuids)
        {
            var ssoUser = await GetSsoUser(ssoId);
            if (ssoUser != null)
            {
                result.Add(ssoUser);
            }
        }

        return result;
    }


    // TODO: Refactor to use same search strategy as in dist and zuora
    public async Task<IEnumerable<Guid>> GetMatchingUsersByName(string input)
    {
        try
        {
            var nameParts = input.Split(' ');
            var userServiceTasks = new List<Task<List<Guid>>>();
            var api = _clientCreator.UserServiceApi();
            foreach (var namePart in nameParts)
            {
                var searchExpression = $"FirstName == \"{namePart}\" || LastName == \"{namePart}\"";
                userServiceTasks.Add(api.GetMatchingSsoUsersQueryAll(searchExpression));
            }

            return (await Task.WhenAll(userServiceTasks)).SelectMany(x => x);
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(input), input},
            });

            throw;
        }
    }

    public async Task<IEnumerable<Guid>> GetMatchingUsersByPhoneNumber(string phoneNumber, bool fuzzySearch)
    {
        var phoneNumberQueryCollection = PhoneNumberQueryCollection(phoneNumber, fuzzySearch);
        var phoneDayQuery = $"PhoneDay in {phoneNumberQueryCollection}";
        var phoneEveningQuery = $"PhoneEvening in {phoneNumberQueryCollection}";
        var phoneMobileQuery = $"PhoneMobile in {phoneNumberQueryCollection}";
        var phonePrimaryQuery = $"PhonePrimary in {phoneNumberQueryCollection}";
        var searchExpression = $"{phoneDayQuery} || {phoneEveningQuery} || {phoneMobileQuery} || {phonePrimaryQuery}";

        var api = _clientCreator.UserServiceApi();

        var result = await api.GetMatchingSsoUsersQueryAll(searchExpression);

        return result; 
    }

    private static string PhoneNumberQueryCollection(string phoneNumber, bool fuzzySearch)
    {
        if (string.IsNullOrWhiteSpace(phoneNumber))
            return "[]";

        if (!fuzzySearch)
        {
            return $"[\"{phoneNumber}\"]";
        }

        string countryCode = "45";

        // Remove whitespace: 44 44 44 44 -> 44444444
        string sanitizedPhoneNumber = phoneNumber;
        sanitizedPhoneNumber = sanitizedPhoneNumber.Replace(" ", "");

        // Remove whitespace: +4544444444 -> 4544444444
        sanitizedPhoneNumber = sanitizedPhoneNumber.Replace("+", "");

        var phoneNumberLength = sanitizedPhoneNumber.Length;
        if (phoneNumberLength < 8)
        {
            // It is not a regular phonenumber, just use it as it is.
            return $"[\"{sanitizedPhoneNumber}\"]";
        }
        else
        {
            if (sanitizedPhoneNumber.Length % 2 != 0 && sanitizedPhoneNumber.StartsWith("0"))
                sanitizedPhoneNumber = sanitizedPhoneNumber.Remove(0, 1);

            var startPhoneNumberIndex = 0;
            // If it contains a country code ie: 45, +45, 0045 then use it.
            if (phoneNumberLength >= 10)
            {
                // if something like 0045
                if (sanitizedPhoneNumber.StartsWith("00"))
                {
                    countryCode = sanitizedPhoneNumber.Substring(2, 2);
                    startPhoneNumberIndex = 4;
                }
                else
                {
                    countryCode = sanitizedPhoneNumber.Substring(0, 2);
                    startPhoneNumberIndex = 2;
                }
            }
            sanitizedPhoneNumber = sanitizedPhoneNumber.Substring(startPhoneNumberIndex);
        }

        string sanitizedPhoneNumberWithSpaces = Regex.Replace(sanitizedPhoneNumber, ".{2}", "$0 "); //adds space for every 2 characters

        return $"[\"{sanitizedPhoneNumber}\", \"{sanitizedPhoneNumberWithSpaces}\", \"{countryCode}{sanitizedPhoneNumber}\", \"{countryCode} {sanitizedPhoneNumberWithSpaces}\", \"+{countryCode}{sanitizedPhoneNumber}\", \"+{countryCode} {sanitizedPhoneNumberWithSpaces}\", \"00{countryCode}{sanitizedPhoneNumber}\", \"00{countryCode} {sanitizedPhoneNumberWithSpaces}\", \"00 {countryCode} {sanitizedPhoneNumberWithSpaces}\"]";
    }
}
