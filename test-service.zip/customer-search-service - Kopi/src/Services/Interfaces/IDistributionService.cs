﻿using DistClient.NET.Model.Distribution;

namespace CustomerSearchService.Services.Interfaces;

public interface IDistributionService
{
    Task<List<Subscriber>> SearchByDomain(List<string> publicationCodeList, string domain);
    Task<List<Subscriber>> SearchByName(List<string> publicationCodeList, string name);
    Task<List<Subscriber>> DeprecatedSearchByName(List<string> publicationCodeList, string name);
    Task<List<Subscriber>> SearchByMasterAddressPointId(List<string> publicationCodeList, string masterAddressPointId);
    Task<List<Subscriber>> SearchByAddress(List<string> publicationCodeList, string zipCode, string street, string? houseNumber, string? houseLetter);
}
