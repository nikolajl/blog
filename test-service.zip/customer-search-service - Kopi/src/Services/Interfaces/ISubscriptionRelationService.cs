﻿namespace CustomerSearchService.Services.Interfaces;

public interface ISubscriptionRelationService
{
    Task<List<string>> GetSubscriptionsBySsoId(Guid ssoId);
}