﻿using ZuoraClient.NET.RestApi.Model.AccountApi;

namespace CustomerSearchService.Services.Interfaces;

public interface IZuoraService
{
    Task<List<ZuoraContact>> GetContactsByName(string name);
    Task<List<ZuoraContact>> GetContactsForName(string name);
    Task<List<RealZuoraAccount>> GetAccountsForContacts(IEnumerable<ZuoraContact> contacts);
    Task<List<ZuoraContact>> GetContactsFromEmailAsync(string email);
    Task<List<ZuoraContact>> GetContactsFromDomainAsync(string domain);
    Task<List<ZuoraContact>> GetContactsFromPhoneNumberAsync(string phoneNumber);
    Task<List<ZuoraContact>> GetContactsByCvr(string cvr);
    Task<List<ZuoraContact>> GetContactsByAccounts(IEnumerable<RealZuoraAccount> accounts);
    Task<List<SubscriptionCompact>> GetSubscriptionsByAccountId(string accountId);
    Task<SubscriptionCompact?> GetSubscriptionBySubscriptionNumber(string subscriptionNumber);
    Task<List<SubscriptionCompact>?> GetSubscriptionsBySubscriptionIds(List<string> subscriptionIdList);
    Task<List<SubscriptionRatePlanCompact>?> GetSubscriptionRatePlanByGiftcardReference(string giftcardReference);
    Task<Account?> GetAccount(string accountKey);
    Task<List<RealZuoraAccount>> GetAccountsByEan(string ean);
    Task<ZuoraPayment?> GetPaymentByPaymentNumber(string paymentNumber);
    Task<ZuoraInvoicePayment?> GetInvoicePaymentByPaymentNumber(string paymentId);
    Task<ZuoraInvoice?> GetInvoice(string invoiceNumber);
    Task<List<ZuoraContact>> GetContactsByMasterAddressPointId(string masterAddressPointId, List<string> brands);
}
