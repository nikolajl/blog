﻿using UserServiceClient.Model;

namespace CustomerSearchService.Services.Interfaces
{
    public interface ISsoService
    {
        Task<SsoUser?> LookupSsoUserByEmail(string email);
        Task<List<SsoUser>> LookupSsoUserByDomain(string domain);
        Task<SsoUser?> LookupSsoUserBySsoId(string ssoId);
        Task<SsoUser?> GetSsoUser(Guid ssoId);
        Task<List<SsoUser>> GetSsoUsers(IEnumerable<Guid> ssoGuids);
        Task<IEnumerable<Guid>> GetMatchingUsersByName(string name);
        Task<IEnumerable<Guid>> GetMatchingUsersByPhoneNumber(string phoneNumber, bool fuzzySearch);
    }
}
