﻿namespace CustomerSearchService.Services.Interfaces;

public interface IAccessAgreementService
{
    Task<List<AccessAgreement>> GetAccessAgreementsByEmail(string email);
}