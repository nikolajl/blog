﻿namespace CustomerSearchService.Services.Interfaces;

public interface ISubscriptionOrderService
{
    Task<SosSubscriptionOrder> GetOrderByOrderNumber(string orderNumber);
}
