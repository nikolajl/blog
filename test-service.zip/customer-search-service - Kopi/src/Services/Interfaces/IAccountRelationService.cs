﻿using DistClient.NET.Model.Distribution;

namespace CustomerSearchService.Services.Interfaces;

public interface IAccountRelationService
{
    Task<List<string>> SearchByPipedriveId(string pipedriveId, string brand);
}
