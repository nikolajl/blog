﻿using CustomerSearchService.Clients.Interfaces;
using DistClient.NET.Model.Address;
using DistClient.NET.Model.Distribution;

namespace CustomerSearchService.Services;

public class DistributionService : IDistributionService
{
    private readonly IClientCreator _clientCreator;
    private readonly ILogHandler _logHandler;

    public DistributionService(IClientCreator clientCreator, ILogHandler logHandler)
    {
        _clientCreator = clientCreator;
        _logHandler = logHandler;
    }

    public async Task<List<Subscriber>> SearchByDomain(List<string> publicationCodes, string domain)
    {
        try
        {
            var client = await _clientCreator.DistributionClient();
            return await client.FindSubscribers(publicationCodes, email: domain);

        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(publicationCodes), String.Join(",", publicationCodes)},
                {nameof(domain), domain},
            });

            throw;
        }
    }

    public async Task<List<Subscriber>> DeprecatedSearchByName(List<string> publicationCodeList, string name)
    {
        var client = await _clientCreator.DistributionClient();
        return await client.FindSubscribers(publicationCodeList, searchName: name);
    }

    public async Task<List<Subscriber>> SearchByName(List<string> publicationCodes, string name)
    {
        var names = name.Split(' ');
        var firstname = names.First();
        var lastname = names.Last();

        try
        {
            var client = await _clientCreator.DistributionClient();
            var results = await Task.WhenAll(
                client.FindSubscribers(publicationCodes, searchName: firstname),
                client.FindSubscribers(publicationCodes, searchName: lastname),
                client.FindSubscribers(publicationCodes, searchName: name)
            );
            return results[0]
                .UnionBy(results[1], x => x.SubscriptionNumber)
                .UnionBy(results[2], x => x.SubscriptionNumber)
                .ToList();
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(name), name},
                {nameof(firstname), firstname},
                {nameof(lastname), lastname},
                {nameof(publicationCodes), String.Join(",", publicationCodes)},
            });

            //TODO: Should we throw or just return empty result?
            //throw;
        }

        return new List<Subscriber>();
    }

    public async Task<List<Subscriber>> SearchByMasterAddressPointId(List<string> publicationCodes, string masterAddressPointId)
    {
        try
        {
            var client = await _clientCreator.DistributionClient();
            return await client.FindSubscribers(publicationCodes, masterAddressPointId: masterAddressPointId);

        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(publicationCodes), String.Join(",", publicationCodes)},
                {nameof(masterAddressPointId), masterAddressPointId},
            });

            throw;
        }
    }

    public async Task<List<Subscriber>> SearchByAddress(List<string> publicationCodes, string zipCode, string street, string? houseNumber, string? houseLetter)
    {
        try
        {

            var distClient = await _clientCreator.DistributionClient();
            var distAddressClient = await _clientCreator.DistributionAddressClient();

            List<GetAddress> addresses = new();

            foreach (var publicationCode in publicationCodes)
            {
                addresses.AddRange(await distAddressClient.GetFindAddressQuery(publicationCode: publicationCode, zipCode: zipCode, street: street, houseNo: houseNumber, houseLetter: houseLetter));
            }

            var uniqueMasterAddressPoints = addresses.Select(x => x.MasterAddressPointId).Distinct().ToList();

            List<Subscriber> subscribers = new();

            foreach (var masterAddressPoint in uniqueMasterAddressPoints)
            {
                subscribers.AddRange(await distClient.FindSubscribers(publicationCodes, masterAddressPointId: masterAddressPoint.ToString()));
            }

            return subscribers;
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(publicationCodes), String.Join(",", publicationCodes)},
                {nameof(zipCode), zipCode},
                {nameof(street), street},
                {nameof(houseNumber), houseNumber},
                {nameof(houseLetter), houseLetter},
            });

            throw;
        }
    }
}
