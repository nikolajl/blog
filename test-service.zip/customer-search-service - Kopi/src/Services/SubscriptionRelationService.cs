﻿using CustomerSearchService.Clients.Interfaces;
using JpRestClient.NET;
using JpRestClient.NET.Exceptions;
using RestSharp;

namespace CustomerSearchService.Services;

public class SubscriptionRelationService : ISubscriptionRelationService
{
    private readonly IClientCreator _clientCreator;
    private readonly ILogHandler _logHandler;

    public SubscriptionRelationService(ILogHandler logHandler, IClientCreator clientCreator)
    {
        _logHandler = logHandler;
        _clientCreator = clientCreator;
    }

    public async Task<List<string>> GetSubscriptionsBySsoId(Guid ssoId)
    {
        var requestOptions = new RequestOptions()
        {
            PathParameters = new List<UrlSegmentParameter>
            {
                new ("ssoId", ssoId.ToString())
            }
        };

        var client = await _clientCreator.CreateSubscriptionRelationServiceClient();

        try
        {
            return await client.GetAsync<List<string>>("api/v1/AccessFeature/{ssoId}/Subscriptions", requestOptions);
        }
        catch (JpRestException e)
        {
            if (e.HttpStatusCode == HttpStatusCode.NotFound) return new List<string>();

            _logHandler.Error("Exception occurred when trying to get Subscriptions associated with provided SsoId", e, new Dictionary<string, string>()
            {
                {"SsoId", ssoId.ToString()}
            });
            throw;
        }
        catch (Exception e)
        {
            _logHandler.Error("Exception occurred when trying to get Subscriptions associated with provided SsoId", e, new Dictionary<string, string>()
            {
                {"SsoId", ssoId.ToString()}
            });
            throw;
        }
    }

}