﻿using CustomerSearchService.Clients.Interfaces;
using System.Text.Json;
using ZuoraClient.NET.Exceptions;
using ZuoraClient.NET.RestApi.Model.AccountApi;

namespace CustomerSearchService.Services;

public class ZuoraService : IZuoraService
{
    private readonly IClientCreator _clientCreator;
    private readonly ILogHandler _logHandler;

    public ZuoraService(IClientCreator clientCreator, ILogHandler logHandler)
    {
        _clientCreator = clientCreator;
        _logHandler = logHandler;
    }

    public async Task<List<ZuoraContact>> GetContactsByName(string name)
    {
        var names = name.Split(' ');
        var firstname = names.First();
        var lastname = names.Last();
        try
        {
            var selectFromContact = "SELECT AccountId, FirstName, LastName, PersonalEmail, CompanyName__c FROM Contact";

            var client = _clientCreator.ZuoraActionsApi();
            var results = await Task.WhenAll(
                client.QueryAndMoreAsync<ZuoraContact>(client.SafeQuery($"{selectFromContact} WHERE FirstName LIKE '%{firstname}%'")),
                client.QueryAndMoreAsync<ZuoraContact>(client.SafeQuery($"{selectFromContact} WHERE LastName = '{lastname}'")),
                client.QueryAndMoreAsync<ZuoraContact>(client.SafeQuery($"{selectFromContact} WHERE CompanyName__c LIKE '%{name}%'"))
            );

            return results[0]
                .UnionBy(results[1], x => x.AccountId)
                .UnionBy(results[2], x => x.AccountId)
                .ToList();
        }
        catch (Exception e)
        {
            _logHandler.Error("Error: GetContactsByName", e, new Dictionary<string, string>() {
                {nameof(name), name}
            });
            throw;
        }
    }

    public async Task<List<ZuoraContact>> GetContactsForName(string name)
    {
        var names = name.Split(' ');

        var query = $@" SELECT AccountId, FirstName, LastName, PersonalEmail, CompanyName__c FROM Contact
                    WHERE FirstName LIKE '%{string.Join("%' OR FirstName LIKE '%", names)}%'
                    OR LastName LIKE '%{string.Join("%' OR LastName LIKE '%", names)}%'
                    OR CompanyName__c LIKE '%{string.Join("%' OR CompanyName__c LIKE '%", names)}%'";

        var zuoraActionsClient = _clientCreator.ZuoraActionsApi();

        return await zuoraActionsClient.QueryAndMoreAsync<ZuoraContact>(query);
    }

    public async Task<List<ZuoraContact>> GetContactsFromEmailAsync(string email)
    {
        var queryString = $"SELECT AccountId, FirstName, LastName, PersonalEmail, CompanyName__c FROM Contact WHERE PersonalEmail='{email}'";
        try
        {
            var client = _clientCreator.ZuoraActionsApi();
            return await client.QueryAndMoreAsync<ZuoraContact>(queryString);

        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(email), email},
            });

            throw;
        }
    }

    public async Task<List<ZuoraContact>> GetContactsFromDomainAsync(string domain)
    {
        var queryString = $"SELECT AccountId, FirstName, LastName, PersonalEmail, CompanyName__c FROM Contact WHERE PersonalEmail like '%{domain}'";
        try
        {
            var client = _clientCreator.ZuoraActionsApi();
            return await client.QueryAndMoreAsync<ZuoraContact>(queryString);
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(domain), domain},
            });

            throw;
        }
    }

    public async Task<List<ZuoraContact>> GetContactsFromPhoneNumberAsync(string phoneNumber)
    {
        /* Original code is very elaborate and slightly faster (however, results in false positives). Trying to solve performance with index in zuora first.
        phoneNumber = phoneNumber.SafeTrim();
        phoneNumber = phoneNumber.StripLeadingZeroForDanishPhoneNumber();
        phoneNumber = phoneNumber.CleanPhoneNumber();
        var phoneNumberWithoutSpaces = phoneNumber.Replace(" ", "");
        var phoneNumberWithoutAreaCode = phoneNumber.Split(' ');
        var queryString = $"SELECT AccountId,PhonePrimary__c,PersonalEmail,WorkEmail, CompanyName__c FROM Contact WHERE PhonePrimary__c='{phoneNumber}' OR PhoneSecondary__c == '{phoneNumber}' OR PhonePrimary__c='{phoneNumberWithoutSpaces}' OR PhoneSecondary__c == '{phoneNumberWithoutSpaces}' OR PhonePrimary__c='{phoneNumberWithoutAreaCode[1]}' OR PhoneSecondary__c == '{phoneNumberWithoutAreaCode[1]}'";
        */

        var queryString = $"SELECT AccountId, FirstName, LastName, PersonalEmail, CompanyName__c FROM Contact WHERE PhonePrimary__c LIKE '%{phoneNumber}' OR PhoneSecondary__c LIKE '%{phoneNumber}'";
        try
        {
            var client = _clientCreator.ZuoraActionsApi();
            return await client.QueryAndMoreAsync<ZuoraContact>(queryString);
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(phoneNumber), phoneNumber},
            });

            throw;
        }
    }

    public async Task<List<ZuoraContact>> GetContactsByCvr(string cvr)
    {
        var queryString = $"SELECT AccountId, FirstName, LastName, PersonalEmail, CompanyName__c FROM Contact WHERE Cvr__c = '{cvr}'";
        try
        {
            var client = _clientCreator.ZuoraActionsApi();
            return await client.QueryAndMoreAsync<ZuoraContact>(queryString);
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(cvr), cvr},
            });

            throw;
        }
    }

    public async Task<List<ZuoraContact>> GetContactsByAccounts(IEnumerable<RealZuoraAccount> accounts)
    {
        if (accounts.Count() == 0) return new List<ZuoraContact>();
        var accountIds = accounts.Select(x => x.Id).Distinct();

        try
        {
            var queryString = $"SELECT AccountId, FirstName, LastName, PersonalEmail, CompanyName__c FROM Contact WHERE AccountId = '{string.Join("' OR AccountId = '", accountIds)}'";
            var zuoraActionsClient = _clientCreator.ZuoraActionsApi();

            return await zuoraActionsClient.QueryAndMoreAsync<ZuoraContact>(queryString);
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(accounts), string.Join(", ", accountIds)},
            });

            throw;
        }
    }

    public async Task<List<SubscriptionCompact>> GetSubscriptionsByAccountId(string accountId)
    {
        var queryString = $"SELECT Name, Status, AccountId FROM Subscription WHERE accountId = '{accountId}' AND Status != 'Expired'";
        try
        {
            var client = _clientCreator.ZuoraActionsApi();
            return await client.QueryAndMoreAsync<SubscriptionCompact>(queryString);
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(accountId), accountId},
            });

            throw;
        }
    }

    public async Task<SubscriptionCompact?> GetSubscriptionBySubscriptionNumber(string subscriptionNumber)
    {
        var queryString = $"SELECT Name, Status, AccountId FROM Subscription WHERE Name = '{subscriptionNumber}' AND Status != 'Expired'";
        try
        {
            var client = _clientCreator.ZuoraActionsApi();
            var results = await client.QueryAndMoreAsync<SubscriptionCompact>(queryString);

            return results.FirstOrDefault();

        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(subscriptionNumber), subscriptionNumber},
            });

            throw;
        }
    }

    public async Task<List<SubscriptionCompact>?> GetSubscriptionsBySubscriptionIds(List<string> subscriptionIdList)
    {
        try
        {
            var result = new List<SubscriptionCompact>();

            var step = 200;  //This is the max allowed number of conditions allowed in the where-clause
            var client = _clientCreator.ZuoraActionsApi();

            for (var i = 0; i < subscriptionIdList.Count; i += step)
            {
                var subList = subscriptionIdList.Skip(i).Take(step);
                var query = $"SELECT Name, Status, AccountId FROM Subscription WHERE Id = '{string.Join("' OR Id = '", subList)}'";
                var resp = await client.QueryAndMoreAsync<SubscriptionCompact>(query);
                result.AddRange(resp);
            }

            return result;
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(subscriptionIdList), JsonSerializer.Serialize(subscriptionIdList)},
            });

            throw;
        }
    }

    public async Task<List<SubscriptionRatePlanCompact>?> GetSubscriptionRatePlanByGiftcardReference(string giftcardReference)
    {
        var queryString = $"SELECT Id, GiftcardReference__c, Name, SubscriptionId FROM RatePlan WHERE GiftcardReference__c = '{giftcardReference}'";
        try
        {
            var client = _clientCreator.ZuoraActionsApi();
            var results = await client.QueryAndMoreAsync<SubscriptionRatePlanCompact>(queryString);
            return results;
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(giftcardReference), giftcardReference},
            });

            throw;
        }
    }

    public async Task<Account?> GetAccount(string accountKey)
    {
        try
        {
            var client = _clientCreator.ZuoraAccountsApi();
            return await client.GetAccount(accountKey);
        }
        catch (ZuoraException ex)
        {
            if (ex.ZuoraErrors.FirstOrDefault()?.Reasons.FirstOrDefault()?.ErrorCategory == ErrorCategory.NOT_FOUND)
            {
                return null;
            }

            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(accountKey), accountKey},
            });

            throw;
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(accountKey), accountKey},
            });

            throw;
        }
    }

    public async Task<List<RealZuoraAccount>> GetAccountsForContacts(IEnumerable<ZuoraContact> contacts)
    {
        var accounts = new List<RealZuoraAccount>();
        var uniqueAccountIds = contacts.Select(x => x.AccountId).Distinct().ToList();

        try
        {
            var step = 200;  //This is the max allowed number of conditions allowed in the where-clause
            var client = _clientCreator.ZuoraActionsApi();
            for (var i = 0; i < uniqueAccountIds.Count; i += step)
            {
                var tempAccountIdsToQuery = uniqueAccountIds.Skip(i).Take(step);
                var query = $"SELECT Id, AccountNumber, Brand__c, SsoId__c FROM Account WHERE Id = '{string.Join("' OR Id = '", tempAccountIdsToQuery)}'";
                accounts.AddRange(
                    await client.QueryAndMoreAsync<RealZuoraAccount>(query)
                );
            }

            return accounts;
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(uniqueAccountIds), string.Join(",", uniqueAccountIds)},
            });

            throw;
        }
    }

    public async Task<List<RealZuoraAccount>> GetAccountsByEan(string ean)
    {
        var query = $"SELECT Id, AccountNumber, Brand__c, SsoId__c FROM Account WHERE Ean__c = '{ean}'";
        try
        {
            var client = _clientCreator.ZuoraActionsApi();
            return await client.QueryAndMoreAsync<RealZuoraAccount>(query);
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(ean), ean},
            });

            throw;
        }
    }


    public async Task<ZuoraPayment?> GetPaymentByPaymentNumber(string paymentNumber)
    {
        var queryString = $"SELECT AccountId, Id, PaymentNumber, Amount FROM payment WHERE PaymentNumber='{paymentNumber}'";

        try
        {
            var client = _clientCreator.ZuoraActionsApi();
            var results = await client.QueryAndMoreAsync<ZuoraPayment>(queryString);

            return results.FirstOrDefault();
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(paymentNumber), paymentNumber},
            });

            throw;
        }
    }

    public async Task<ZuoraInvoicePayment?> GetInvoicePaymentByPaymentNumber(string paymentId)
    {
        var queryString = $"SELECT Id,PaymentId,InvoiceId FROM InvoicePayment WHERE paymentId='{paymentId}'";

        try
        {
            var client = _clientCreator.ZuoraActionsApi();
            var results = await client.QueryAndMoreAsync<ZuoraInvoicePayment>(queryString);

            return results.FirstOrDefault();
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(paymentId), paymentId},
            });

            throw;
        }
    }
    public async Task<ZuoraInvoice?> GetInvoice(string invoiceNumber)
    {
        var queryString = $"SELECT Id, InvoiceNumber, AccountId, Status, Amount FROM Invoice WHERE InvoiceNumber ='{invoiceNumber}'";

        try
        {
            var client = _clientCreator.ZuoraActionsApi();
            var results = await client.QueryAndMoreAsync<ZuoraInvoice>(queryString);

            return results.FirstOrDefault();
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(invoiceNumber), invoiceNumber},
            });

            throw;
        }
    }

    public async Task<List<ZuoraContact>> GetContactsByMasterAddressPointId(string masterAddressPointId, List<string> brands)
    {
        var queryString = $@" SELECT AccountId, FirstName, LastName, PersonalEmail, CompanyName__c FROM Contact WHERE Addresspoint__c = '{masterAddressPointId}'";

        var zuoraActionsClient = _clientCreator.ZuoraActionsApi();

        return await zuoraActionsClient.QueryAndMoreAsync<ZuoraContact>(queryString);
    }
}
