﻿using CustomerSearchService.Clients.Interfaces;
using JpRestClient.NET;
using JpRestClient.NET.Exceptions;
using RestSharp;

namespace CustomerSearchService.Services;

public class AccountRelationService: IAccountRelationService
{
    private readonly IClientCreator _clientCreator;
    private readonly ILogHandler _logHandler;

    public AccountRelationService(IClientCreator clientCreator, ILogHandler logHandler)
    {
        _clientCreator = clientCreator;
        _logHandler = logHandler;
    }

    public async Task<List<string>> SearchByPipedriveId(string pipedriveId, string brand)
    {
        if (string.IsNullOrEmpty(brand)) { throw new ArgumentNullException("Brand", "Brand can not be empty"); }
        if (string.IsNullOrEmpty(pipedriveId)) { throw new ArgumentNullException("PipedriveId", "Pipedrive id can not be empty"); }

        var requestOptions = new RequestOptions
        {
            PathParameters = new List<UrlSegmentParameter>
            {
                new ("brand", brand),
                new ("pipedriveId", pipedriveId)
            }
        };

        var client = _clientCreator.CreateAccountRelationClient();

        try
        {
            //This returns a list of accountNumbers (not accountIds)
            return await client.GetAsync<List<string>>("/pipedrive/{pipedriveId}/brand/{brand}/relations/zuora", requestOptions);
        }
        catch (JpRestException ex) when (ex.HttpStatusCode == HttpStatusCode.NotFound)
        {
            throw new ArgumentException($"Could not zuora account for brand '{brand}', pipedriveId '{pipedriveId}'.", ex);
        }
        catch (Exception ex)
        {
            _logHandler.Error("Exception when getting zuora account for pipedriveId.", ex, new Dictionary<string, string>
                {
                    {$"{nameof(brand)}", brand },
                    {$"{nameof(pipedriveId)}", pipedriveId}
                });
            throw;
        }
    }
}
