﻿using CustomerSearchService.Clients.Interfaces;
using JpRestClient.NET;
using RestSharp;

namespace CustomerSearchService.Services;

public class SubscriptionOrderService : ISubscriptionOrderService
{
    private readonly IClientCreator _clientCreator;
    private readonly ILogHandler _logHandler;

    public SubscriptionOrderService(IClientCreator clientCreator, ILogHandler logHandler)
    {
        _clientCreator = clientCreator;
        _logHandler = logHandler;
    }

    public async Task<SosSubscriptionOrder> GetOrderByOrderNumber(string orderNumber)
    {
        try
        {

            var client = _clientCreator.CreateSosClient();

            var requestOptions = new RequestOptions()
            {
                PathParameters = new List<UrlSegmentParameter>
                {
                    new ("orderNumber", orderNumber)
                }
            };

            return await client.GetAsync<SosSubscriptionOrder>("/Rest/SubscriptionOrder/SubscriptionOrderByOrderNumber/{orderNumber}", requestOptions);
        }
        catch (Exception ex)
        {
            _logHandler.Error(ex.Message, ex, new Dictionary<string, string>()
            {
                {nameof(orderNumber), orderNumber},
            });

            throw;
        }
    }
}
