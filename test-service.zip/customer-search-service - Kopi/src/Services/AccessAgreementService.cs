﻿using CustomerSearchService.Clients.Interfaces;
using JpRestClient.NET;
using JpRestClient.NET.Exceptions;
using RestSharp;

namespace CustomerSearchService.Services;

public class AccessAgreementService : IAccessAgreementService
{
    private readonly IClientCreator _clientCreator;
    private readonly ILogHandler _logHandler;

    public AccessAgreementService(IClientCreator clientCreator, ILogHandler logHandler)
    {
        _clientCreator = clientCreator;
        _logHandler = logHandler;
    }

    public async Task<List<AccessAgreement>> GetAccessAgreementsByEmail(string email)
    {
        var requestOptions = new RequestOptions
        {
            PathParameters = new List<UrlSegmentParameter>
            {
                new ("email", email)
            }
        };

        try
        {
            var client = await _clientCreator.CreateAasClient();
            return await client.GetAsync<List<AccessAgreement>>("/accessagreementsbyemail/{email}", requestOptions);
        }
        catch (JpRestException e)
        {
            if (e.HttpStatusCode == HttpStatusCode.NotFound) return new List<AccessAgreement>();

            _logHandler.Error("Exception occurred when trying to get Access Agreements by specified email", e, new Dictionary<string, string>()
            {
                {"Email", email}
            });
            throw;
        }
        catch (Exception e)
        {
            _logHandler.Error("Exception occurred when trying to get Access Agreements by specified email", e, new Dictionary<string, string>()
            {
                {"Email", email}
            });
            throw;
        }
    }

}