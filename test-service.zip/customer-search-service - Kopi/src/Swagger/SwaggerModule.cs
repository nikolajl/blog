﻿using Microsoft.OpenApi.Any;
using System.Runtime.Serialization;

namespace CustomerSearchService.Swagger;

/// <summary>
/// Used to add everything swagger-related
/// </summary>
public static class SwaggerModule
{
    /// <summary>
    /// Add swagger doc and swagger auth
    /// </summary>
    /// <param name="services"></param>
    public static void AddSwagger(this IServiceCollection services)
    {
        services.AddSwaggerGen(c =>
        {
            var provider = services.BuildServiceProvider();
            var scope = provider.GetRequiredService<IApiVersionDescriptionProvider>();
            foreach (var description in scope.ApiVersionDescriptions)
            {
                c.SwaggerDoc(description.GroupName, CreateMetaInfoApiVersion(description));
            }
            c.EnableAnnotations();
            AddXml(c);
            AddSwaggerAuth(c);
            c.SchemaFilter<EnumSchemaFilter>();
        });
    }

    private static void AddXml(SwaggerGenOptions c)
    {
        // Set the comments path for the Swagger JSON and UI.
        var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
        var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
        c.IncludeXmlComments(xmlPath);
    }

    private static void AddSwaggerAuth(SwaggerGenOptions c)
    {
        c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
        {
            Description = $@"JWT Authorization header using the Bearer scheme.{Environment.NewLine} 
                      Enter your token in the text input below.",
            Name = "Authorization",
            Type = SecuritySchemeType.Http,
            BearerFormat = "JWT",
            In = ParameterLocation.Header,
            Scheme = "Bearer"
        });
        c.AddSecurityRequirement(new OpenApiSecurityRequirement()
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                    },
                    Scheme = "oauth2",
                    Name = "Bearer",
                    In = ParameterLocation.Header,
                },
                new List<string>()
            }
        });
    }

    private static OpenApiInfo CreateMetaInfoApiVersion(ApiVersionDescription apiDescription)
    {
        return new OpenApiInfo
        {
            Title = "Customer Search Service",
            Version = apiDescription.ApiVersion.ToString(),
            Description = "Provides functionality to find accounts and subscriptions via various criteria."
        };
    }

    /// <summary>
    /// Displays enums as strings instead of integers, respecting EnumMemberAttribute decorations.
    /// </summary>
    private class EnumSchemaFilter : ISchemaFilter
    {
        public void Apply(OpenApiSchema model, SchemaFilterContext context)
        {
            if (context.Type.IsEnum)
            {
                model.Enum.Clear();
                foreach (string enumName in Enum.GetNames(context.Type))
                {
                    MemberInfo? memberInfo = context.Type.GetMember(enumName).FirstOrDefault(m => m.DeclaringType == context.Type);

                    EnumMemberAttribute? enumMemberAttribute = memberInfo == null
                     ? null
                     : memberInfo.GetCustomAttributes(typeof(EnumMemberAttribute), false).OfType<EnumMemberAttribute>().FirstOrDefault();

                    string label = enumMemberAttribute == null || string.IsNullOrWhiteSpace(enumMemberAttribute.Value)
                     ? enumName
                     : enumMemberAttribute.Value;

                    model.Enum.Add(new OpenApiString(label));
                }
            }
        }
    }
}