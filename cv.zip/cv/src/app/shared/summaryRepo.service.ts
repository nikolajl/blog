import { Injectable } from '@angular/core';
import { LocalStorageService } from './localStorage.service';
import { Summary } from './models/summary';

@Injectable()
export class SummaryRepoService {
  _summary: Summary = new Summary();

  constructor(private localStorageService: LocalStorageService) {}

  init() {
    const data = this.localStorageService.get('summary') ?? {
      title: 'Nikolaj Lundsgaard',
      subtitle: 'Web developer',
      birthdate: new Date('1978-10-02'),
      courses: [
        '2005 - C# bla bla',
        '2009 - Scrum Master',
        '2018 - Scrum with Kanban',
      ],
      languages: ['Dansk', 'Engelsk'],
      available: new Date('2022-10-01'),
      description:
        'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Corrupti reiciendis, eius quidem repellendus, doloremque a, doloribus eveniet unde consequuntur aperiam ullam. Totam facilis earum libero quo minima? Qui, est consectetur.',
      education: 'Datalogi, Københavns Universitet',
    };

    if (data) {
      this._summary = data;
    }
    return this.getSummary();
  }

  getSummary() {
    return this._summary;
  }

  updateSummary(summary: Summary) {
    this._summary = summary;
    this.localStorageService.set('summary', summary);
  }
}
