import { Injectable } from '@angular/core';
import { Project } from './models/project';
import { LocalStorageService } from './localStorage.service';

@Injectable()
export class ProjectsRepoService {
  _projects: Array<Project> = [];

  constructor(private localStorageService: LocalStorageService) {}

  init() {
    const data = this.localStorageService.get('projects');
    if (data) {
      this._projects = data;
    }
    return this._projects;
  }

  getProjects() {
    return this._projects;
  }

  async addProject(project: Project) {
    this._projects.push(project);
    this.localStorageService.set('projects', this._projects);
  }

  async update(index: number, project: Project) {
    this._projects[index] = project;
    this.localStorageService.set('projects', this._projects);
  }

  async remove(index: number) {
    this._projects.splice(index, 1);
    this.localStorageService.set('projects', this._projects);
  }
}
