import { Injectable } from '@angular/core';

@Injectable()
export class LocalStorageService {
  set(key: string, value: any) {
    window.localStorage.setItem(key, JSON.stringify(value));
  }

  get(key: string) {
    const data = window.localStorage.getItem(key);

    if (data) {
      return JSON.parse(data, (key, value) => {
        // Load JSON dates as native dates
        if (
          typeof value === 'string' &&
          /^\d\d\d\d-\d\d-\d\dT\d\d:\d\d:\d\d.\d\d\dZ$/.test(value)
        ) {
          return new Date(value);
        }
        return value;
      });
    }

    return undefined;
  }
}
