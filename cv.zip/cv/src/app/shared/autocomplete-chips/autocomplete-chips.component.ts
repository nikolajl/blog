import { COMMA, ENTER } from '@angular/cdk/keycodes';
import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormControl } from '@angular/forms';
import {
  MatAutocompleteSelectedEvent,
  MatAutocomplete,
} from '@angular/material/autocomplete';
import { MatChipInputEvent } from '@angular/material/chips';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-autocomplete-chips',
  templateUrl: './autocomplete-chips.component.html',
  styleUrls: ['./autocomplete-chips.component.scss'],
})
export class AutocompleteChipsComponent implements OnInit {
  @Output('change') change = new EventEmitter<Array<string>>();
  @Input('label') label: string = '';
  @Input('values') inputValues: Array<string> = [];
  @Input('options') allOptions: Array<string> = [];

  @ViewChild('textInput') textInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  visible = true;
  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  inputControl = new FormControl();
  filteredOptions: Observable<string[]>;
  selectedValues: string[] = [];

  constructor() {}

  ngOnInit(): void {
    this.selectedValues = this.inputValues;

    this.filteredOptions = this.inputControl.valueChanges.pipe(
      startWith(null),
      map((value: string | null) => this._filter(value))
    );
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add the tag
    if ((value || '').trim()) {
      this.selectedValues.push(value.trim());
      this.change.emit(this.selectedValues);
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.inputControl.setValue(null);
  }

  remove(value: string): void {
    const index = this.selectedValues.indexOf(value);

    if (index >= 0) {
      this.selectedValues.splice(index, 1);
      this.change.emit(this.selectedValues);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.selectedValues.push(event.option.viewValue);
    this.textInput.nativeElement.value = '';
    this.inputControl.setValue(null);

    this.change.emit(this.selectedValues);
  }

  onPaste(event: ClipboardEvent) {
    event.preventDefault();
    event.clipboardData
      .getData('Text')
      .split(/;|,|\n/)
      .forEach((value) => {
        let trimValue = value.trim();
        if (trimValue) {
          const options = this._filter(trimValue);
          if (options.length === 1) {
            trimValue = options[0];
          }

          if (this.selectedValues.indexOf(trimValue) === -1) {
            this.selectedValues.push(trimValue); //Push if valid
          }
        }
      });
  }

  private _filter(value: string = ''): string[] {
    if (!value) {
      return this.allOptions.filter(
        (option) => this.selectedValues.indexOf(option) === -1
      );
    }

    const filterValue = value.toLowerCase();
    return this.allOptions
      .filter((option) => option.toLowerCase().indexOf(filterValue) === 0)
      .filter((option) => this.selectedValues.indexOf(option) === -1);
  }
}
