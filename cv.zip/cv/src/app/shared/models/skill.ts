import { Project } from './project';

export class Skill {
  title: string; // TODO: key: string; For now title equals key
  description?: string;
  version?: string;
  since?: Date;
  last?: Date;
  total?: string;
  projects: Project[];

  constructor() {
    this.projects = [];
  }
}
