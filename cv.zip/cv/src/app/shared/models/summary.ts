export class Summary {
  title: string;
  subtitle: string;
  available: Date;
  description?: string;
  education?: String;
  courses: string[];
  languages: string[];
  birthdate?: Date;
  since?: string;

  constructor() {
    this.courses = [];
    this.languages = [];
  }
}
