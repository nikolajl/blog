export class Project {
  role?: string;
  organisation?: string;
  title: string;
  description: string;
  skills?: string[];
  start: Date;
  end?: Date;

  constructor() {
    this.title = '';
    this.role = '';
    this.description = '';
    this.start = null;
    this.organisation = '';
    this.skills = [];
  }
}
