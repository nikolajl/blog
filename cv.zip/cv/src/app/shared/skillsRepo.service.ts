import { Injectable } from '@angular/core';
import { LocalStorageService } from './localStorage.service';

@Injectable()
export class SkillsRepoService {
  _skills = new Set<string>();

  constructor(private localStorageService: LocalStorageService) {}

  init() {
    const data = this.localStorageService.get('skills');
    if (data) {
      this._skills = new Set(data);
    }
    return this.getSkills();
  }

  async getSkills() {
    return [...this._skills];
  }

  async addSkills(skills: string[]) {
    skills.forEach((skill) => this._skills.add(skill));
    this.localStorageService.set('skills', [...this._skills]);
  }

  async remove(skill: string) {
    this._skills.delete(skill);
    this.localStorageService.set('projects', this._skills);
  }
}
