import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LocalStorageService } from './localStorage.service';
import { AutocompleteChipsComponent } from './autocomplete-chips/autocomplete-chips.component';
import { MatChipsModule } from '@angular/material/chips';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule } from '@angular/forms';
import { SummaryRepoService } from './summaryRepo.service';
import { ProjectsRepoService } from './projectsRepo.service';
import { SkillsRepoService } from './skillsRepo.service';

// TODO: Seems suss
import { ProjectsService } from '../projects/projects.service';
import { SkillsService } from '../skills/skills.service';

@NgModule({
  declarations: [AutocompleteChipsComponent],
  providers: [
    ProjectsService,
    SkillsService,
    LocalStorageService,
    SummaryRepoService,
    ProjectsRepoService,
    SkillsRepoService,
  ],
  imports: [
    CommonModule,
    MatChipsModule,
    DragDropModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatIconModule,
    ReactiveFormsModule,
  ],
  exports: [AutocompleteChipsComponent],
})
export class SharedModule {}
