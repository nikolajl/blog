import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DatePipe } from '@angular/common';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatCardModule } from '@angular/material/card';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core'; // TODO: Replace with date-fns
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatChipsModule } from '@angular/material/chips';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ProjectComponent } from './projects/project/project.component';
import { ProjectsPageComponent } from './projects/projects-page/projects-page.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SkillsPageComponent } from './skills/skills-page/skills-page.component';
import { SharedModule } from './shared/shared.module';
import { ProjectSkillsComponent } from './projects/project-skills/project-skills.component';
import { SkillsTableComponent } from './skills/skills-table/skills-table.component';
import { SafeHtmlPipe } from './shared/pipes/safe-html.pipe';
import { MarkdownPipe } from './shared/pipes/markdown.pipe';
import { SummaryPageComponent } from './summary/summary-page/summary-page.component';
import { SummaryComponent } from './summary/summary/summary.component';

@NgModule({
  declarations: [
    AppComponent,
    ProjectsPageComponent,
    ProjectComponent,
    ProjectSkillsComponent,
    SkillsPageComponent,
    SkillsTableComponent,
    SafeHtmlPipe,
    MarkdownPipe,
    SummaryPageComponent,
    SummaryComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatCardModule,
    MatToolbarModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatChipsModule,
    DragDropModule,
    MatAutocompleteModule,
    MatIconModule,
    MatTableModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    SharedModule,
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent],
})
export class AppModule {}
