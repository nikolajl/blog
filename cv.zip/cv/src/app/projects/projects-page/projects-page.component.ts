import { Component, OnInit } from '@angular/core';
import { Project } from 'src/app/shared/models/project';
import { ProjectsService } from '../projects.service';

@Component({
  selector: 'app-projects-page',
  templateUrl: './projects-page.component.html',
  styleUrls: ['./projects-page.component.scss'],
})
export class ProjectsPageComponent implements OnInit {
  projects = [];
  isAdding = false;

  constructor(private projectsService: ProjectsService) {}

  ngOnInit(): void {
    this.projectsService.projects.subscribe((value) => {
      value.sort((a, b) => (a.start < b.start ? 1 : -1));
      this.projects = value;
    });
    this.projectsService.init();
  }

  setIsInsertProjectDisplayed(isDisplayed: boolean) {
    this.isAdding = isDisplayed;
  }

  onInsertProject(project: Project) {
    this.projectsService.addProject(project);
    this.isAdding = false;
  }

  onUpdateProject(index: number, project: Project) {
    this.projectsService.update(index, project);
  }

  onRemoveProject(index: number) {
    this.projectsService.remove(index);
  }
}
