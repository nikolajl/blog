import { Injectable } from '@angular/core';
import { BehaviorSubject, from, Subject } from 'rxjs';
import { Project } from '../shared/models/project';
import { ProjectsRepoService } from '../shared/projectsRepo.service';
import { SkillsRepoService } from '../shared/skillsRepo.service';

@Injectable({
  providedIn: 'root',
})
export class ProjectsService {
  projects = new BehaviorSubject<Array<Project>>([]);

  constructor(
    private projectsRepo: ProjectsRepoService,
    private skillsRepo: SkillsRepoService
  ) {}

  init() {
    const projects = this.projectsRepo.init();
    this.projects.next(projects);
  }

  async addProject(project: Project) {
    await this.projectsRepo.addProject(project);
    await this.skillsRepo.addSkills(project.skills);
    this.projects.next(this.projectsRepo.getProjects());
  }

  async update(index: number, project: Project) {
    await this.projectsRepo.update(index, project);
    await this.skillsRepo.addSkills(project.skills);
    this.projects.next(this.projectsRepo.getProjects());
  }

  async remove(index: number) {
    await this.projectsRepo.remove(index);
    this.projects.next(this.projectsRepo.getProjects());
  }
}

/*
export class ProjectsService {
  _projects: Array<Project> = [];
  projects = new BehaviorSubject<Array<Project>>(this._projects);

  constructor(private localStorageService: LocalStorageService) {
    this.projects.next(this._projects);
  }

  init() {
    const data = this.localStorageService.get('projects');
    if (data) {
      this._projects = data;
      this.projects.next(this._projects);
    }
  }

  addProject(project: Project) {
    this._projects.push(project);
    this.projects.next(this._projects);
    this.localStorageService.set('projects', this._projects);
  }

  update(index: number, project: Project) {
    this._projects[index] = project;
    this.projects.next(this._projects);
    this.localStorageService.set('projects', this._projects);
  }

  remove(index: number) {
    this._projects.splice(index, 1);
    this.projects.next(this._projects);
    this.localStorageService.set('projects', this._projects);
  }
}
*/
