import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Project } from '../../shared/models/project';
@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.scss'],
})
export class ProjectComponent implements OnInit {
  @Input() project: Project;
  @Input() isEditing: boolean;
  @Output() save = new EventEmitter<Project>();
  @Output() cancel = new EventEmitter<void>();
  @Output() remove = new EventEmitter<void>();

  form: FormGroup;
  shouldTitleSync: boolean = false;

  isNew = false;
  constructor() {}

  ngOnInit(): void {
    if (!this.project) {
      // Adding a new project
      this.project = new Project();
      this.isNew = true;
      this.initForm();
    }
  }

  beginEdit() {
    this.isEditing = true;
    this.initForm();
  }

  get skills() {
    return this.form.get('skills').value;
  }

  initForm() {
    this.form = new FormGroup({
      role: new FormControl(this.project.role, {
        validators: Validators.required,
      }),
      organisation: new FormControl(
        this.project.organisation,
        Validators.required
      ),
      start: new FormControl(this.project.start, Validators.required),
      end: new FormControl(this.project.end),
      title: new FormControl(this.project.title, Validators.required),
      skills: new FormControl([...this.project.skills]),
      description: new FormControl(
        this.project.description,
        Validators.required
      ),
    });

    this.form
      .get('role')
      .valueChanges.subscribe((role) =>
        this.syncTitle(role, this.form.get('organisation').value)
      );
    this.form
      .get('organisation')
      .valueChanges.subscribe((organisation) =>
        this.syncTitle(this.form.get('role').value, organisation)
      );
    this.form.get('title').valueChanges.subscribe((title) => {
      this.shouldTitleSync =
        title ===
        this.defaultTitle(
          this.form.get('role').value,
          this.form.get('organisation').value
        );
    });

    this.shouldTitleSync =
      this.project.title + this.project.role + this.project.organisation ===
        '' ||
      this.project.title ===
        this.defaultTitle(this.project.role, this.project.organisation);
  }

  syncTitle(role = '', organisation = '') {
    if (this.shouldTitleSync) {
      this.form.patchValue(
        { title: this.defaultTitle(role, organisation) },
        { emitEvent: false }
      );
    }
  }

  setSkills(tags: Array<string>) {
    if (Array.isArray(tags)) {
      this.form.patchValue({ skills: tags });
    }
  }

  defaultTitle(role = '', organisation = '') {
    return role && organisation
      ? `${role}, ${organisation}`
      : `${role}${organisation}`;
  }

  onSave() {
    if (this.form.valid) {
      this.isEditing = false;
      this.save.emit(this.form.value);
    }
  }

  onRemove() {
    this.remove.emit();
  }

  onCancel() {
    this.isEditing = false;
    this.cancel.emit();
  }

  reorderSkill(event: CdkDragDrop<string[]>) {
    moveItemInArray(
      this.project.skills,
      event.previousIndex,
      event.currentIndex
    );
    this.save.emit(this.project);
  }
}
