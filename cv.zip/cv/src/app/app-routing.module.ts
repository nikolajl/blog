import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProjectsPageComponent } from './projects/projects-page/projects-page.component';
import { SkillsPageComponent } from './skills/skills-page/skills-page.component';
import { SummaryPageComponent } from './summary/summary-page/summary-page.component';

const routes: Routes = [
  { path: 'cv', component: SummaryPageComponent },
  { path: 'projects', component: ProjectsPageComponent },
  { path: 'skills', component: SkillsPageComponent },
  { path: '', redirectTo: '/cv', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
