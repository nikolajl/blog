import { Component, Input, OnInit } from '@angular/core';
import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { Skill } from 'src/app/shared/models/skill';

@Component({
  selector: 'app-skills-table',
  templateUrl: './skills-table.component.html',
  styleUrls: ['./skills-table.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition(
        'expanded <=> collapsed',
        animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')
      ),
    ]),
  ],
})
export class SkillsTableComponent implements OnInit {
  @Input('skills')
  dataSource: Array<Skill> = [];
  columnsToDisplay = [
    'title',
    'projects',
    'category',
    'since',
    'last',
    'total',
  ];
  expandedElement: Skill | null;

  ngOnInit(): void {}
}
