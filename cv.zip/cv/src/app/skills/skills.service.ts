import { Injectable } from '@angular/core';
import formatDuration from 'date-fns/formatDuration';
import intervalToDuration from 'date-fns/intervalToDuration';
import { BehaviorSubject } from 'rxjs';
import { SkillsRepoService } from '../shared/skillsRepo.service';
import { ProjectsRepoService } from '../shared/projectsRepo.service';
import { Project } from '../shared/models/project';
import { Skill } from '../shared/models/skill';

@Injectable({
  providedIn: 'root',
})
export class SkillsService {
  // TODO: Maybe don't use a named object for this. A table should be fine
  skills = new BehaviorSubject<Array<Skill>>([]);

  constructor(
    private skillsRepoService: SkillsRepoService,
    private projectsRepoService: ProjectsRepoService
  ) {}

  async init() {
    const skills = await this.skillsRepoService.getSkills();
    const projects = await this.projectsRepoService.getProjects();

    this.skills.next(this.getSkills(projects));
  }

  // TODO: Refactor to => function createProjectSkills(skills: string[], projects: Project[])
  getSkills(projects: Project[]) {
    const skills: Record<string, Skill> = {};

    projects.forEach((project: Project) => {
      const since = project.start;
      const last = project.end;
      const total = formatDuration(
        intervalToDuration({
          start: project.start,
          end: Date.now(),
        }),
        {
          format: ['years', 'months'],
        }
      );

      for (const title of project.skills) {
        // TODO const category = 'Kategori';

        if (title in skills) {
          const skill = skills[title];
          if (skill.since > since) {
            skill.since = since;
            skill.total = total;
          }
          if (skill.last < last) {
            skill.last = last;
          }
          skill.projects.push(project);
        } else {
          skills[title] = {
            title,
            description: '', // TODO
            projects: [project],
            since,
            last,
            total,
          };
        }
      }
    });

    return Object.values(skills).sort((a, b) => a.title.localeCompare(b.title));
  }
}
