import { Component, OnInit } from '@angular/core';
import { Skill } from 'src/app/shared/models/skill';
import { SkillsService } from '../skills.service';

@Component({
  selector: 'app-skills-page',
  templateUrl: './skills-page.component.html',
  styleUrls: ['./skills-page.component.scss'],
})
export class SkillsPageComponent implements OnInit {
  skills: Array<Skill> = [];

  constructor(private skillsService: SkillsService) {}

  ngOnInit(): void {
    this.skillsService.skills.subscribe((skills) => {
      this.skills = skills;
    });
    this.skillsService.init();
  }
}
