import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import differenceInYears from 'date-fns/differenceInYears';
import { Summary } from 'src/app/shared/models/summary';
import { SummaryService } from 'src/app/summary/summary.service';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
})
export class SummaryComponent implements OnInit {
  form: FormGroup;
  isEditing = false;
  summary = new Summary();

  constructor(private summaryService: SummaryService) {}

  ngOnInit(): void {
    this.summaryService.summary.subscribe((value) => {
      this.summary = value;
    });
    this.summaryService.init();
  }

  initForm() {
    this.form = new FormGroup({
      title: new FormControl(this.summary.title, Validators.required),
      subtitle: new FormControl(this.summary.subtitle, Validators.required),
      description: new FormControl(this.summary.description),
      available: new FormControl(this.summary.available, Validators.required),
      birthdate: new FormControl(this.summary.birthdate),
      education: new FormControl(this.summary.education, Validators.required),
      courses: new FormControl([...this.summary.courses]),
      languages: new FormControl([...this.summary.languages]),
    });
  }

  onEdit() {
    this.isEditing = true;
    this.initForm();
  }

  onSave() {
    if (this.form.valid) {
      this.isEditing = false;

      this.summaryService.update(this.form.value);
    }
  }

  onCancel() {
    this.isEditing = false;
  }

  public get isAvailableNow() {
    return !this.summary.available || this.summary.available < new Date();
  }

  public get age() {
    return this.summary.birthdate
      ? differenceInYears(new Date(), this.summary.birthdate)
      : undefined;
  }
}
