import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Summary } from '../shared/models/summary';
import { SummaryRepoService } from '../shared/summaryRepo.service';
import { ProjectsRepoService } from '../shared/projectsRepo.service';
import { SkillsRepoService } from '../shared/skillsRepo.service';

@Injectable({
  providedIn: 'root',
})
export class SummaryService {
  summary = new BehaviorSubject<Summary>(new Summary());

  constructor(
    private summaryRepoService: SummaryRepoService,
    private projectsRepoService: ProjectsRepoService,
    private skillsRepoService: SkillsRepoService
  ) {}

  init() {
    this.summaryRepoService.init();
    this.summary.next(this.summaryRepoService.getSummary());
  }

  update(value: Summary) {
    this.summaryRepoService.updateSummary(value);
    this.summary.next(this.summaryRepoService.getSummary());
  }
}
