import { updateResource, invertResource, removeResources, resourceExpires } from "./inventory"

// TODO: Move to units

export const updateUnitProduction = (state, unit) => {
  const expires = {}
  const change = {}

  // TODO: Extract into resourcesProduction(input, output)
  unit.input?.forEach((resource) => {
    change[resource.type] = change[resource.type]
      ? updateResource(change[resource.type], invertResource(resource))
      : invertResource(resource)
  })
  unit.output?.forEach((resource) => {
    change[resource.type] = change[resource.type]
      ? updateResource(change[resource.type], resource)
      : resource
  })

  const resources = removeResources(state.inventory, unit.cost)
  // TODO: Rename inventory to resources
  const inventory = resources.map((resource) => {
    if (change[resource.type]) {
      // TODO: Calculate when resource expires based on now
      const result = updateResource(resource, change[resource.type])
      if (result.rate < 0) {
        expires[result.type] = resourceExpires(result)
      }

      return result
    }
    return resource
  })

  // TODO: Determine events based on resources running out...
  const events = [] // addEvents(state.events, resourcesEvents)

  const result = {
    ...state,
    inventory,
    events,
  }

  return result
}

const processUnits = (units, inventory, now) => {
  const result = {
    units,
    inventory: units.map(addProduction),
    events: //???
  }

  return result
}

export const removeProduction = (inventory, input, output) =>
  addProduction(inventory, input.map(invertResource), output.map(invertResource))

// throws Exception if not enough resources
export const addUnit = (state, unit, now) => {
  
  const {
    units,
    events,
    inventory
  } = processUnits([...state.units, { ...unit, since: now }], state.inventory, now)

  // add events when resources run out
  // update resources

  return {
    ...state,
    units,
    events,
    inventory
  }

  //const events = addEvents(game.events, resources)
  /* TODO: add event when unit complete
  const events = unit.time
    ? addEvent(game.events, { type: 'unit:completed', time: now, unit })
    : game.events
*/
}
