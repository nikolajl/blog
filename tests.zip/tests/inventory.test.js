import { process } from './inventory'

expect.extend({
  toMatchState(received, argument) {
    const pass = this.equals(received, expect.arrayContaining([expect.objectContaining(argument)]))

    if (pass) {
      return {
        message: () =>
          `expected ${this.utils.printReceived(
            received
          )} not to contain object ${this.utils.printExpected(argument)}`,
        pass: true,
      }
    } else {
      return {
        message: () =>
          `expected ${this.utils.printReceived(
            received
          )} to contain object ${this.utils.printExpected(argument)}`,
        pass: false,
      }
    }
  },
})

describe('process resources', () => {
  it('should process resources', () => {
    const resources = [{ type: 'grain', quantity: 5, since: 0, rate: 2, max: 100 }]

    const expected = [{ type: 'grain', quantity: 25, rate: 2, max: 100 }]

    expect(process(resources, 10)).toEqual(
      expect.arrayContaining(expected.map((x) => expect.objectContaining(x)))
    )
  })

  it('should not exceed max', () => {
    const resources = [{ type: 'grain', quantity: 5, since: 0, rate: 2, max: 10 }]

    const expected = [{ type: 'grain', quantity: 10, rate: 2, max: 10 }]

    expect(process(resources, 10)).toEqual(
      expect.arrayContaining(expected.map((x) => expect.objectContaining(x)))
    )
  })

  it('should work with negative rate', () => {
    const resources = [{ type: 'money', quantity: 100, since: 0, rate: -2 }]

    const expected = [{ type: 'money', quantity: 80 }]

    expect(process(resources, 10)).toEqual(
      expect.arrayContaining(expected.map((x) => expect.objectContaining(x)))
    )
  })

  it('should work with no elapsed time', () => {
    const resources = [
      { type: 'grain', quantity: 5, since: 10, rate: 2, max: 10 },
      { type: 'money', quantity: 100, since: 10, rate: -2 },
    ]

    const expected = [
      { type: 'money', quantity: 100 },
      { type: 'grain', quantity: 5 },
    ]

    expect(process(resources, 10)).toEqual(
      expect.arrayContaining(expected.map((x) => expect.objectContaining(x)))
    )
  })

  it('should not go below min', () => {
    const resources = [{ type: 'grain', quantity: 5, since: 0, rate: -2, min: 0 }]

    const expected = [{ type: 'grain', quantity: 0 }]

    expect(process(resources, 10)).toEqual(
      expect.arrayContaining(expected.map((x) => expect.objectContaining(x)))
    )
  })
})
