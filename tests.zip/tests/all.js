export const process = (all, since, now) => {
  const { events } = all

  events.forEach((event) => {
    const { time } = event
    all = updateInventory(all, time)
    all = updateUnits(all, event, time)
  })

  return all
}
