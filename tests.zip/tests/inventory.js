import { clamp } from "./utils"

const processResource = (resource, now) => {
  const { rate, quantity, since, min, max } = resource
  const elapsed = now - since
  return {
    ...resource,
    since: now,
    quantity: clamp(rate * elapsed + quantity, min, max),
  }
}

const removeResource = (resource, quantity) => {
  // If insufficient resource, throw exception
  if (resource.quantity < quantity) {
    throw new Error({ id: "NOTENOUGHRESOURCES", value: { resource, quantity } })
  }

  // return updated resource subtracting quantity
  return {
    ...resource,
    quantity: resource.quantity - quantity,
  }
}

// throws Exception if not enough resources
export const removeResources = (inventory, cost) => {
  // Inventory must be up-to-date.
  // TODO: Consider if this should update inventory, just in case...

  return inventory.map((resource) => {
    // find resource.
    const r = cost.find((x) => x.type === resource.type)
    if (r?.quantity) {
      return removeResource(resource, r.quantity)
    }
    return resource
  })
}

export const updateResource = (resource, change) => ({
  ...resource,
  rate: resource.rate + change.rate,
  // TODO: quality
  min: resource.min + change.min,
  max: resource.max + change.max,
})

export const invertResource = (resource) => ({
  ...resource,
  rate: -resource.rate,
})

export const resourceExpires = ({ quantity, rate, since }) =>
  rate < 0 ? since - quantity / rate : undefined

export const process = (inventory, since, now) =>
  inventory.map((resource) => processResource(resource, since, now))
