function game({ inventory, events, units }) {
  const matchObject = {}
  if (inventory) {
    matchObject.inventory = expect.arrayContaining(inventory.map((x) => expect.objectContaining(x)))
  }
  if (events) {
    matchObject.events = expect.arrayContaining(events.map((x) => expect.objectContaining(x)))
  }
  if (units) {
    matchObject.units = expect.arrayContaining(units.map((x) => expect.objectContaining(x)))
  }
  return expect.objectContaining(matchObject)
}

/**
 * TODO:
 * * Make tests run
 * * Add Basic UI
 * * - Add Unit (Farm)
 * * - Add unit (Bakery)
 * * View Unit
 * * View inventory
 * * Add Unit type
 * * Add Resource type
 */

const UNIT_ADD = "unit:add"

import { addUnit } from "./units"

export const updateUnits = (game, event, now) => {
  let { inventory, units } = game
  const { type, time, unit } = event

  switch (type) {
    case UNIT_ADD:
      units = [...units, unit]
      break
    default: {
    }
  }

  // Do something
  // Add unit => subtract resources -> add unit -> update resources rate -> add event for when resources are depleted.
  // Upgrade unit => subtract resources -> find unit -> update level
  //

  return {
    ...game,
    inventory,
    units,
  }
}

// TODO: Add events sorted by time
export const addEvent = (events, event) => [...events, event]

describe("units", () => {
  const farm = {
    type: "farm",
    cost: [{ type: "money", quantity: 20 }],
    output: [{ type: "grain", rate: 1 }],
  }
  const bakery = {
    type: "bakery",
    input: [{ type: "grain", rate: 10 }],
    output: [{ type: "bread", rate: 1 }],
  }

  describe("addUnit", () => {
    it("should subtract cost from inventory, and add the unit", () => {
      const inventory = [{ type: "money", quantity: 100 }]
      const events = []
      const units = []
      const now = 0

      let state = {
        inventory,
        events,
        units,
      }
      state = addUnit(state, farm, now)

      expect(state).toEqual(
        game({
          units: [{ type: "farm" }],
          inventory: [{ type: "money", quantity: 80 }],
        })
      )

      // TODO: New test case for unit with build time
      /*
      expect(process(state, now + 10)).toEqual(
        game({
          events: [],
          inventory: [{ type: 'grain', quantity: 10 }],
          units: [{ type: 'farm' }],
        })
      )
      */
    })
  })
  it("should throw an exception, if insufficient funds", () => {
    // Arrange
    // TODO: Maybe I should check for > minimum, and not > 0
    const inventory = [{ type: "money", quantity: 0 }]
    const events = []
    const units = []
    const now = 0

    let state = {
      inventory,
      events,
      units,
    }

    // Act
    // Assert
    expect(() => {
      addUnit(state, farm, now)
    }).toThrow() // TODO: Add Error object to expect
  })

  describe("production", () => {
    it.only("should extract resources", () => {
      const money = { type: "money", quantity: 100 }
      const grain = { type: "grain", quantity: 0, rate: 0, since: 0 }
      const inventory = [money, grain]
      const units = []
      const events = []
      const now = 0
      const game = { inventory, units, events }

      expect(process(addUnit(game, farm, now), now)).toEqual(
        expect.objectContaining({
          inventory: expect.arrayContaining([
            { ...money, quantity: money.quantity - farm.cost[0].quantity },
            { ...grain, rate: farm.output[0].rate },
          ]),
        })
      )
    })

    it.todo("should recalculate production of resources based on units and available inventory")

    it.skip("should convert resources", () => {
      const events = []
      const inventory = [
        { type: "money", quantity: 100, since: 0 },
        { type: "grain", quantity: 100, rate: 2, since: 0 },
      ]

      const now = 0
      let game = { events, inventory }
      game = addUnit(game, farm, now)
      game = addUnit(game, bakery, now)
      game = process(game, now)

      expect(game.inventory).toEqual(
        expect.arrayContaining([
          { type: "money", quantity: 50 },
          { type: "grain", rate: -8 },
          { type: "bread", rate: 1 },
        ])
      )

      expect(game.units).toEqual(expect.arrayContaining([{ type: "bakery" }, { type: "farm" }]))
    })

    it.skip("should stop production when running out of resources", () => {
      const events = []
      const inventory = [
        { type: "money", quantity: 100, since: 0 },
        { type: "grain", quantity: 100, rate: 2, since: 0 },
      ]

      const now = 0
      let game = { events, inventory }
      game = addUnit(game, farm, now)
      game = addUnit(game, bakery, now)
      game = process(game, now + 10)

      expect(game.inventory).toEqual(
        expect.arrayContaining([
          { type: "money", quantity: 50 },
          { type: "grain", quantity: 0 },
          { type: "bread", rate: 3 /*?*/ },
        ])
      )
    })
  })
})
