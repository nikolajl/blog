import type { Component } from "solid-js";

const Vessels: Component = () => {
  return (
    <>
      <h1>Vessels</h1>
    </>
  );
};

export default Vessels;
