import type { Component } from "solid-js";

const Contracts: Component = () => {
  return (
    <>
      <h1>Contracts</h1>
    </>
  );
};

export default Contracts;
