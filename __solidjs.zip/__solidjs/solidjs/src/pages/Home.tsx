import { Container, Stack } from "solid-bootstrap";
import type { Component } from "solid-js";
import Vessel from "../components/Vessel";

const Home: Component = () => {
  return (
    <Container>
      <h1>HQ</h1>
      <Stack>
        <Vessel />
        <Vessel />
        <Vessel />
      </Stack>
    </Container>
  );
};

export default Home;
