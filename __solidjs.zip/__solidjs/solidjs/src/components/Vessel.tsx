import { Button, Card } from "solid-bootstrap";
import type { Component } from "solid-js";

const Vessel: Component = () => {
  return (
    <Card class="mb-3">
      <Card.Header>Random Driver</Card.Header>
      <Card.Body>
        <Card.Title>Sugar to Paris</Card.Title>
        <Card.Text>Arrival in 02:34</Card.Text>
        <Button variant="primary">Details</Button>
      </Card.Body>
    </Card>
  );
};

export default Vessel;
