import { Container, Nav, Navbar, Offcanvas } from "solid-bootstrap";
import type { Component } from "solid-js";
import { BsTruck } from "solid-icons/bs";
import { FaSolidTruckMoving } from "solid-icons/fa";
import { FaSolidTruck } from "solid-icons/fa";
import { BiSolidPackage } from "solid-icons/bi";
import { FaSolidHome } from "solid-icons/fa";
import { NavLink } from "solid-app-router";

const Header: Component = () => {
  return (
    <Navbar expand={false} bg="dark" variant="dark">
      <Container fluid>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Nav class="me-auto" fill navbar={false}>
          <Nav.Link href="/" as={NavLink} end>
            <FaSolidHome size={24} color="#fff" />
          </Nav.Link>
          <Nav.Link href="/vessels" as={NavLink}>
            <FaSolidTruck size={24} color="#fff" />
          </Nav.Link>
          <Nav.Link href="/contracts" as={NavLink}>
            <BiSolidPackage size={24} color="#fff" />
          </Nav.Link>
        </Nav>
        <Navbar.Brand href="#">$ 100,-</Navbar.Brand>
        <Navbar.Offcanvas
          id="offcanvasNavbar"
          aria-labelledby="offcanvasNavbarLabel"
          placement="start"
        >
          <Offcanvas.Header closeButton>
            <Offcanvas.Title id="offcanvasNavbarLabel">
              Offcanvas
            </Offcanvas.Title>
          </Offcanvas.Header>
          <Offcanvas.Body>
            <Nav class="justify-content-end flex-grow-1 pe-3">
              <Nav.Link href="#action1">Home</Nav.Link>
              <Nav.Link href="#action2">Link</Nav.Link>
            </Nav>
          </Offcanvas.Body>
        </Navbar.Offcanvas>
      </Container>
    </Navbar>
  );
};

export default Header;
