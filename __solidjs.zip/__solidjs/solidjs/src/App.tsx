import { Route, Routes } from "solid-app-router";
import type { Component } from "solid-js";
import Header from "./components/Header";
import Contracts from "./pages/Contracts";
import Home from "./pages/Home";
import Vessels from "./pages/Vessels";

//import logo from './logo.svg';
//import styles from './App.module.css';

const App: Component = () => {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/vessels" element={<Vessels />} />
        <Route path="/contracts" element={<Contracts />} />
        <Route path="/" element={<Home />} />
      </Routes>
    </>
  );
};

export default App;
