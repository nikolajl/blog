import type { Component } from "solid-js";
/*
import { Route, Routes } from "@solidjs/router";
        <Routes>
          <Route path="/users" component={Users} />
          <Route path="/" component={Home} />
          <Route
            path="/about"
            element={<div>This site was made with Solid</div>}
          />
        </Routes>
*/

import { IoMenu } from "solid-icons/io";
import { FaSolidTruckMoving } from "solid-icons/fa";
import styles from "./App.module.css";
import { currency } from "./utils/format";
import { Route, Routes } from "@solidjs/router";
import Page1 from "./pages/Page1";
import Page2 from "./pages/Page2";

const App: Component = () => {
  return (
    <div class={styles.body}>
      <header class={styles.header}>
        <div>Header</div>
        <div>{currency(1234)}</div>
      </header>
      <main class={styles.main}>
        Main:
        <Routes>
          <Route path="/page1" component={Page1} />
          <Route path="/page2" component={Page2} />
        </Routes>
        <ul>
          <li>List all trucks ( there will only be one) </li>
          <li>Truck details (destination, cargo, reward, eta) </li>
          <li>Contracts (available, or current)</li>
        </ul>
        <ul>
          <li>&lt;Timer from=('01:35') to=(0) /&gt; tæller ned</li> (interval,
          precision)
          <li>Funds: 10.000</li>
          <li>Trucks -/&gt; Empty -/&gt; Buy (5.000,-)</li>
          <li>Locations - coords (2,5) - (6,9) - Vector calcs the dist</li>
          <li>Contracts - (from, to, cargo/description, reward)</li>
          <li>
            Truck - (name, speed, delivery: (from, to, eta based on speed))
          </li>
        </ul>
      </main>
      <footer class={styles.footer}>
        <FaSolidTruckMoving size={32} style={{ margin: "4px" }} />
      </footer>
    </div>
  );
};

export default App;

const Home: Component = () => <h1>Home</h1>;
const Users: Component = () => <h1>Users</h1>;
