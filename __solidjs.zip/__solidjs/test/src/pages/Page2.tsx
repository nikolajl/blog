export default function Page1() {
  return <div>Page2</div>;
}
