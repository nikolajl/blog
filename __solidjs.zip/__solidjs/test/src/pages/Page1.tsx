export default function Page1() {
  return <h1>Page1</h1>;
}
