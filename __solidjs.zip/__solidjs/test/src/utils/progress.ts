/**
 * Map [x,y]
 */

const map = {
  Kbh: [[10, 3], ["Odense"]],
  Odense: [
    [5, 2],
    ["Århus", "Kbh"],
  ],
  Århus: [[3, 6], ["Odense"]],
};

const dijkstra = (a: string, b: string) => [a, b];

const producer = {
  inventory: {
    Grain: [
      {
        name: "Grain",
        quality: 0.3,
        qty: 500,
      },
    ],
  },
};

const exporter = {
  inventory: {
    Grain: [
      {
        name: "Grain", // sku
        quality: 0.3,
        qty: 500,
        price: 2.2, // Price per unit (ppu)
      },
    ],
  },
};

const importer = {
  inventory: {
    Grain: [
      {
        name: "Grain", // sku
        quality: 0.3,
        qty: 500,
        price: 2.2, // Price per unit (ppu)
      },
    ],
  },
};
