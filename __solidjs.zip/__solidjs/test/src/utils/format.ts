export const currency = (value: number) => {
  const n = new Intl.NumberFormat("dk", {
    compactDisplay: "short",
  });

  return `$ ${n.format(value)}`;
};
