/* @refresh reload */
import { render } from "solid-js/web";
import { Route, Router, Routes } from "@solidjs/router";

import "./index.css";
import App from "./App";
import Page1 from "./pages/Page1";
import Page2 from "./pages/Page2";
render(
  () => (
    <>
      <Router>
        <App />
      </Router>
    </>
  ),
  document.getElementById("root") as HTMLElement
);
