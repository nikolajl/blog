import { Component, For } from "solid-js";

import { FaSolidTruckMoving } from "solid-icons/fa";

type Cargo = "Grain" | "Sugar" | "Bread" | "Pastry";

type Location = {
  coord: [number, number];
  name: string;
};

type Contract = {
  from: Location;
  to: Location;
  cargo: Cargo;
  reward: number;
};

type Vessel = {
  type: "Truck";
  id: string;
  name: string;
  speed: number;
  contract: Contract;
};

type Props = {
  trucks: Vessel[];
};

export const TrucksList: Component<Props> = (props) => {
  const { trucks } = props;
  return <For each={trucks}>{(truck) => <li>{truck.name}</li>}</For>;
};
