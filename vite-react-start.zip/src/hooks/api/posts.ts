import { useEffect, useState } from 'react';

export const useAllPosts = (count: number) => {
  //    const [data, setData] = useState<Post[]?>();
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 1000);
  }, [count]);

  return { isLoading };
};
