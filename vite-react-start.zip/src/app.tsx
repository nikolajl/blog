import { Outlet, ReactLocation, Router } from '@tanstack/react-location';
import { ReactLocationDevtools } from '@tanstack/react-location-devtools';

const location = new ReactLocation();

export default function App() {
  return (
    <Router location={location}>
      <Outlet />
      <ReactLocationDevtools initialIsOpen={false} />
    </Router>
  );
}
