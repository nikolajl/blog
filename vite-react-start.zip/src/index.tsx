import React from 'react';
import ReactDOM from 'react-dom/client';
import './global.css';
import routes from '@/pages/routes';

import { ReactLocation, Router, Outlet } from '@tanstack/react-location';
import { ReactLocationDevtools } from '@tanstack/react-location-devtools';

const location = new ReactLocation();

const App = () => {
  return (
    <React.StrictMode>
      <Router location={location} routes={routes}>
        <Outlet />
        <ReactLocationDevtools />
      </Router>
    </React.StrictMode>
  );
};

const element = document.getElementById('root');
if (element) {
  ReactDOM.createRoot(element).render(<App />);
}
