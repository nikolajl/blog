export default function App() {
  return (
    <>
      <header>
        <h1>Home</h1>
      </header>
      <main>This is the home page of the app</main>
    </>
  );
}
