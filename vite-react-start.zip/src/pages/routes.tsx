import { Route } from '@tanstack/react-location';
import Index from './index';

const memberRoutes: Route[] = []; // TODO import memberRoutes, {MemberRoot} from 'member/routes.tsx'

const routes: Route[] = [{ path: '/', element: <Index />, children: memberRoutes }];

export default routes;
