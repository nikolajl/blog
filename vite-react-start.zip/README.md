# Create React app with Vite + Typescript + Jest

## Vite

```sh
npm create vite@latest
√ Project name: ... cra
√ Select a framework: » react
√ Select a variant: » react-ts

Scaffolding project in ./cra...

Done. Now run:

  cd cra
  npm install
  npm run dev
```

This is a pretty good start. We have React, JSX, Typescript out-of-the box. Even support for stuff we don't need like sass.

## git init

```
git init
git add .
git commit -m "Initial commit"
```

## Eslint + Prettier + Stylelint

```sh
npm init @eslint/config
```

TODO: Use standard. Airbnb and Google have opinionated rules that may or may not suit your needs. However, Standard will catch any errors you have, leave coding style up to you - and let prettier handle formatting.

Edit .eslintrc

```json
{
    "env": {
        "browser": true,
        "jest": true,
        "es2021": true
    },
    ...
    "rules": {
        "react/react-in-jsx-scope": "off"
    }
}
```

```sh
npm init @eslint/config
```

## Adding import alias

Edit `tsconfig.json`

```json
{
  "compilerOptions": {
    ...
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"]
    }
  },
  ...
}
```

Edit `vite.config.js`

```js
export default defineConfig({
  resolve: {
    alias: {
      '@': './',
    },
  },
  ...
});
```

## Testing with jest

## How to fix: VSCode Format on save not working with prettier

- Make sure you have the [Prettier](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode) extension installed
- Go to VS Code Settings `Ctrl+,`
- Find setting for `Default formatter`
- Set to `Prettier`

# TODO: Demo

- react-location
- react-query
- react-bootstrap
- react-hook-forms

/accounts <- All
/accounts/:id <- Details
/accounts/:id/Subscriptions <- Partial view, Accordion list
/accounts/:id/Subscriptions/:id <- Partial view, Accordion list, Opened, showing rateplans

- Account <- Show all accounts, create account (id, )
  - Contact
  - Subscription (Id, Name, StartDate, EndDate, Status)
    - Rateplan (Cost, Price, Period)

## Adding API proxy

Edit `vite.config.ts`

````js
export default defineConfig({
  server: {
    proxy: {
      '/api/': {
        target: 'http://jsonplaceholder.typicode.com',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
  ...
});
```


## Building a Hello world app (Blog)
### React-location

```sh
npm install @tanstack/react-location
````

- Code splitting?
