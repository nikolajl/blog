# Setup Vite project

## Scaffold vite with react

https://vitejs.dev/guide/#scaffolding-your-first-vite-project

This command will create the folder `your-project-name-goes-here`. Use with a more suitable name.

```sh
$ npm create vite@latest
Need to install the following packages:
  create-vite@latest
Ok to proceed? (y) y
√ Project name: ... your-project-name-goes-here
√ Select a framework: » React
√ Select a variant: » TypeScript
```

Create git repo to keep track of your changes.

```sh
git init
git add .
git commit -m "Initial commit"
```

After each step make sure to commit.

https://github.blog/2022-06-30-write-better-commits-build-better-projects/

```sh
git add .
git commit -m "your-message-goes-here-make-it-matter"
```

## Setup Developer Experience tools

All of these are optional, but useful to ensure consistent code formatting. These are my preferences, but tweak them to match your style if needed.

### Editorconfig

https://editorconfig.org/

`.editorconfig`

```bash
[*]
indent_style = space
indent_size = 2
charset = utf-8

# 4 space indentation
[*.yml]
indent_size = 4
```

### Prettier

https://prettier.io/

```sh
npm i -D prettier
```

`.prettierrc`

```json
{
  "tabWidth": 2,
  "printWidth": 100,
  "singleQuote": true,
  "trailingComma": "es5",
  "jsxBracketSameLine": true
}
```

### ESlint

https://eslint.org/

```sh
npm i -D eslint eslint-config-prettier eslint-plugin-react @typescript-eslint/eslint-plugin @typescript-eslint/parser
```

`.eslintrc`

```json
{
  "env": {
    "browser": true,
    "es2021": true
  },
  "extends": [
    "eslint:recommended",
    "plugin:react/recommended",
    "plugin:@typescript-eslint/recommended"
  ],
  "parser": "@typescript-eslint/parser",
  "parserOptions": {
    "ecmaFeatures": {
      "jsx": true
    },
    "ecmaVersion": "latest",
    "sourceType": "module"
  },
  "plugins": ["react", "@typescript-eslint"],
  "settings": {
    "react": {
      "version": "detect"
    }
  },
  "rules": {
    "react/react-in-jsx-scope": "off"
  }
}
```

### StyleLint

https://stylelint.io/

```sh
npm i -D stylelint stylelint-config-standard stylelint-config-prettier
```

```json
{
  "extends": ["stylelint-config-standard", "stylelint-config-prettier"]
}
```

### VS Code extensions

- EditorConfig.EditorConfig
- dbaeumer.vscode-eslint
- esbenp.prettier-vscode
- gitlenseamodio.gitlens
