import { defineConfig } from 'cypress';

export default defineConfig({
  video: false,
  screenshotOnRunFailure: false,
  viewportWidth: 1500,
  viewportHeight: 1200,
  component: {
    devServer: {
      framework: 'react',
      bundler: 'vite',
    },
  },
});
