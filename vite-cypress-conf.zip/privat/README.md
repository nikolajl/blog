# Customer Overview Client (SPA)

## Getting started

Install dependencies using `npm install`.

Check that everything is restored correctly by running the test suite, `npm test`.

Start local dev server.

```sh
npm start
```

This starts the Vite dev server. However, it needs a backend to work. Open `CustomerOverview.Web` in visual studio; build and run the solution.

It should open a browser, and load the site. You are now ready to develop.

## Code Guidelines

### Always

- Follow these guidelines unless there is a good reason. Leave a comment explaining why you break from guidelines
- Follow good programming practices
  - Make good variable names, even if they are long - avoid abbr as they mk cod hrd 2 r3d.
  - Keep code DRY, refactor often.
- Components should follow the single responsibility principle
- Test components using cypress, focus on functionality, invoke UI like a user would
- Use Css modules for component specific css, in files located close to the component using
- Global css styles should never be mixed with component specific styles.

### Use common sense

- Place files that belong together, close in the file structure.
- Favour 1 React component per file
- Favour pure functions, i.e. functions that are only dependent on their parameters.
- Place pure functions outside the component that use it, possibly in a separate file located nearby in the file structure.
- Keep components small 100-200 lines (incl. JSX)
  - When components grow to big, consider moving hooks, pure functions, types to separate files. (However, avoid too many small files, as well)

## How to create a new page

- Type url in browser. You should see a 404 page.
- Create file `src/pages/path/to/ComponentPage.tsx`
- Edit routes.tsx
- Reload browser, to check that route is setup correctly
- To use params, useMatch(), only use params in the outermost component. All nested components must get routes from

### Snippet for React component

```tsx
import NestedComponent from './component/only/used/here/NestedComponent'
import { useGetSomething } from '@/hooks/api/something'

type Props = {
  id: number,
  title: string
}

export default function Button(props: Props) {
  const {id, title} = props;

  const something = useGetSomething(id);

  if (something.isLoading) {
    // Early return, avoid using else
    return (
      <div>component is loading...</div>
    );
  }

  if (!something.data) {
    // Design for empty.
    // When developing a component most of the time is spent on when data is available.
    // However, in production it is mostly empty. E.g. a comments section, that mostly have no comments.
    return (
    <>
      <h1>{title}<h1>
      <div>No content</div>
    </>
    );
  }

  return (
    <>
      <h1>{title}<h1>
      <h2>{something?.data.header}</h2>
      <div><NestedComponent content={something?.data.content}/></div>
    </>
  )
}
```

## Frameworks used

The code heavily relies on having a good understanding of These frameworks.

## Cypress

Used for writing integration tests. Usually cypress is used for e2e tests. However, here it is used for testing components in isolation.

When adding a components, it should have at least 1 simple test.

```tsx
import Component from '@/path/to/Component/

describe('<Component>', () => {
  it('mounts', () => {
    cy.mount(<Component title="This is title" id={1}/>);
    cy.get('h1').should('have.text', 'This is title');
  });
})
```

Most components will be composed of other components. Tests should exercise some business rules like a user would use the UI. So testing each sub component is discouraged.

For more on how to test using cypress, see [https://docs.cypress.io/]

Here is some suggested reading

- [Component test tutorial](https://docs.cypress.io/guides/component-testing/quickstart-react)
- [Core concepts](https://docs.cypress.io/guides/core-concepts/introduction-to-cypress)
- [Best practices](https://docs.cypress.io/guides/references/best-practices)
- [Stub network requests](https://docs.cypress.io/guides/guides/network-requests)

### Vite

Vite is used for bundling. You might be familiar with webpack. This does essentially the same with a lot less configuration.

- [Vite configuration](https://vitejs.dev/config/)

### React Query

### React Location

### Bootstrap

- React-bootstrap Components
- Css

### React Hook Form

- yup validation
