# FormDate.tsx

## Description

The `FormDate.tsx` component renders a DatePicker using the [react-datepicker](https://www.npmjs.com/package/react-datepicker) npm package. It locks the locale to 'da'.

## Example

```jsx
return (
  <FormDate
    size="sm"
    placeholderText="Fra dato"
    selected={fromDate}
    maxDate={toDate}
    onChange={(date) => date instanceof Date && setFromDate(date)}
  />
);
```

## Where?

[`src/components/forms/FormDate.tsx`](../../src/components/forms/FormDate.tsx)
