# Button.tsx

## Description

The `Button.tsx` component is a wrapper for the React Bootstrap Button component. Besides the default [React Bootstrap Button functionality](https://react-bootstrap.github.io/components/buttons/) it integrates a [React Bootstrap Spinner](https://react-bootstrap.github.io/components/spinners/) which is triggered by an optional `loading` prop

## Example

```jsx
return (
  // Default bs variant is "primary"
  <Button>Primary</Button>
   // the is loading prop will trigger a spinner
  <Button loading={isLoading}>{isLoading? 'Submit' : 'Submitting'}</Button>
  //using more of the built in bs button props
  <Button size="sm" variant="danger" disabled={isDisabled}>Beware!</Button>
);
```

More examples on the [ui-demo page](../../src/pages/ui-demo/UIDemo.tsx)

## Where?

[`src/components/forms/Button.tsx`](../../src/components/forms/Button.tsx)
