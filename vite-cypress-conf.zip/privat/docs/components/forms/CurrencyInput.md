# CurrencyInput.tsx

## Description

The `CurrencyInput.tsx` component is an wrapper for a [React BootStrap InputGroup]() that formats the input as currency supporting dkk, nok and euro. Under the hood it uses [react-number-format] to format the input.

It is used [here](../../src/pages/customers/accounts/RefundOrder.tsx)

## Example

```jsx
return (
  <CurrencyInput
    value={value}
    onChange={(v: number | undefined) => {
      setValue(v);
    }}
    isInvalid={!valid}
    disable={!enabled}
  />
  // assuming:
  // const [value, setValue] = useState(0);
  // const [valid, setValid] = useState(true);
  // const [enabled, setEnabled] = useState(true);
);
```

## Where?

[src/components/forms/CurrencyInput.tsx](../../src/components/forms/CurrencyInput.tsx)
