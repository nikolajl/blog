import ToastProvider, { useToastProvider } from '@/components/messages/ToastProvider';

const TestComponent = () => {
  const { showError, showInfo } = useToastProvider();

  return (
    <>
      <h1>ErrorMessages</h1>
      <p>
        ErrorMessages are displayed with the hook <code>useErrorMessages </code> from{' '}
        <code>@/components/messages/ErrorProvider.tsx</code>
      </p>
      <p>3 variants of errorMessages are available.</p>
      <ul>
        <li>showInfo</li>
        <li>showError</li>
        <li>showSuccess</li>
      </ul>
      <p>
        <button
          type="button"
          className="btn btn-danger"
          data-cy="show-error"
          onClick={() => showError('This is an error message!')}>
          Error message
        </button>
      </p>
      <h2>delay</h2>
      <p>
        Error messages persist until closed by the user. This is not always the best UX, and by
        passing an optional `delay` parameter, the message will automatically be dismissed after
        `delay` ms.
      </p>
      <button
        type="button"
        className="btn btn-danger"
        data-cy="show-info-autohide"
        onClick={() =>
          showInfo('This is an info message! It will disappear after 5 seconds', '', 5000)
        }>
        Info autohide
      </button>
    </>
  );
};

const TestWrapper = () => (
  <ToastProvider>
    <TestComponent />
  </ToastProvider>
);

describe('ErrorMessages', () => {
  it('should show error message', () => {
    cy.mount(<TestWrapper />);
    cy.get('[data-cy="show-error"]').click();
    cy.get('.toast-body').should('have.text', 'This is an error message!');
  });

  it('should hide error', () => {
    cy.mount(<TestWrapper />);
    cy.get('[data-cy="show-error"]').click();
    cy.get('.btn-close').click();
    cy.get('.toast-body').should('not.exist');
  });

  it('should show message, and autohide after delay', () => {
    cy.clock();
    cy.mount(<TestWrapper />);
    cy.get('[data-cy="show-info-autohide"]').click();
    cy.get('.toast-body').should(
      'have.text',
      'This is an info message! It will disappear after 5 seconds'
    );
    cy.tick(5000);
    cy.get('.toast-body').should('not.exist');
  });
});
