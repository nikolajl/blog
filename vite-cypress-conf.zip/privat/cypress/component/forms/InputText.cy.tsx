import { InputText } from '@/components/forms/InputText';
import { Form } from 'react-bootstrap';
import { FormProvider, useForm } from 'react-hook-form';

describe('<InputText>', () => {
  it('should mount', () => {
    cy.mount(<TestComponent />);
    cy.get('input').should('have.attr', 'placeholder', 'Username');
  });
});

function TestComponent() {
  const form = useForm();
  return (
    <div style={{ width: 400, margin: 'auto' }}>
      <FormProvider {...form}>
        <Form>
          <InputText name="username" label="Username" required />
        </Form>
      </FormProvider>
    </div>
  );
}
