import React, { useState } from 'react';
import FormDate from '@/components/forms/FormDate';

describe('<FormDate>', () => {
  it('mounts', () => {
    cy.mount(<TestComponent date={new Date()} />);
  });

  it('should format date correctly', () => {
    const date = new Date('2021-12-11');
    cy.mount(<TestComponent date={date} />);
    cy.get('input').should('have.value', '11-12-2021');
  });
});

// FormDate is a controlled component that requires selected and onChange ot be set. It does not have any internal state.
type Props = {
  date: Date;
};
function TestComponent({ date }: Props) {
  const [value, setValue] = useState<Date | null>(date);
  return (
    <FormDate
      selected={value}
      onChange={(date) => {
        setValue(date);
      }}
    />
  );
}
