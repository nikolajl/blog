import React from 'react';
import Button from '@/components/forms/Button';

describe('<Button>', () => {
  it('should mount', () => {
    cy.mount(<Button>Test</Button>);
    cy.get('button').should('have.text', 'Test');
    cy.get('button').should('not.have.text', 'Tets');
  });
  it('should react on click', () => {
    const onClickSpy = cy.spy().as('onClick');
    cy.mount(<Button onClick={onClickSpy}>SPY</Button>);
    cy.get('button').click();
    cy.get('@onClick').should('have.been.called');
  });
});
