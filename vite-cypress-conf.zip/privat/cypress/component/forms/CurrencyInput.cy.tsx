import React, { useState } from 'react';
import CurrencyInput from '@/components/forms/CurrencyInput';

describe('<CurrencyInput>', () => {
  it('should mount', () => {
    cy.mount(<TestComponent value={42} />);
  });

  it('should display formatted value', () => {
    const value = 42;
    cy.mount(<TestComponent value={value} />);
    cy.get('input').should('have.value', '42');
  });

  it('should format entered value', () => {
    const value = 42;
    cy.mount(<TestComponent value={value} />);
    cy.get('input').clear().type('123');
    cy.get('input').should('have.value', '123');
  });
});

type Props = {
  value: number | undefined;
};

function TestComponent({ value: val }: Props) {
  const [value, setValue] = useState(val);
  return (
    <CurrencyInput
      value={value}
      onChange={function (v: number | undefined): void {
        setValue(v);
      }}
      isInvalid={false}
      disabled={false}
    />
  );
}
