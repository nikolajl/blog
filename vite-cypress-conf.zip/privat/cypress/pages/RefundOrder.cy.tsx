import MockApp, { fakeUser } from './MockApp';
import { addDays } from 'date-fns';
import { formatDate } from '@/utils/format';

describe('RefundOrder', () => {
  describe('when easyRefund flag is not set', () => {
    it('should not allow access to page', () => {
      const route = `/customers/-sso-/-account-/order-refund`;
      cy.mount(<MockApp route={route} />);
      cy.get('h1').should('have.text', 'Not allowed');
    });
  });

  describe('when user has access', () => {
    const sso = 'some-sso';
    const account = 'some-account';
    const route = `/customers/${sso}/${account}/order-refund`;
    const user = fakeUser({
      flags: { EasyRefund: true },
    });
    beforeEach(() => {
      cy.intercept(`/api/accounts/${account}`, {
        fixture: 'accounts/getAccount',
      });
      cy.intercept(`/api/refund/refundOrders/accounts/${account}?orderStatus=Created`, {
        fixture: 'refunds/getRefundOrders',
      });
      cy.intercept(`/api/ssoid/medielogin/${sso}`, {
        fixture: `medielogin/${sso}`,
      });
      cy.intercept('/api/refund/invoicepayments/*', {
        fixture: 'refunds/getInvoicePayments',
      });
    });

    it('should mount', () => {
      cy.mount(<MockApp route={route} user={user} />);
      cy.get('h1').should('have.text', 'Anmod om udbetaling');
      cy.contains('h2', 'Tilgodehavende').should('be.visible');
      cy.contains('h2', 'Betalinger').should('be.visible');
    });

    it('should show amounts available for refund', () => {
      cy.mount(<MockApp route={route} user={user} />);
      // should show creditbalance
      cy.contains('label', 'Tilgodehavende')
        .closest('table')
        .within(() => {
          cy.get('input[data-cy="credit-balance-input"]').should('have.value', '25');
        });

      // show invoicepayments
      cy.contains('P-01262548')
        .closest('tr')
        .within(() => {
          cy.get('input[type="text"]').should('have.value', '74');
        });
    });

    describe('when selecting creditbalance to refund', () => {
      beforeEach(() => {
        cy.mount(<MockApp route={route} user={user} />);

        cy.contains('label', 'Tilgodehavende')
          .click()
          .closest('table')
          .within(() => {
            cy.get('input[data-cy="credit-balance-input"]').as('creditBalanceInput');
          });
      });
      it('should enable input field, and entered amount should appear in form', () => {
        cy.get('@creditBalanceInput').should('be.enabled');
        cy.get('@creditBalanceInput').type('{selectAll}12');

        cy.contains('Beløb til refusion').should('have.text', 'Beløb til refusion: 12,00 kr.');
      });

      it('should create future refund and submit when selecting Fremtidig and entering a date', () => {
        cy.contains('label', 'Fremtidig').click();

        const futureDate = addDays(new Date().setHours(0, 0, 0, 0), 5);

        cy.get('[placeholder="Udbetalingsdato"]').type(formatDate(futureDate) as string);
        cy.get('@creditBalanceInput').should('be.disabled');
        cy.contains('label', 'Udbetaling til kreditkort')
          .siblings('input[type="radio"]')
          .first()
          .should('be.disabled');
        cy.get('input[name="regNr"]').type('1234');
        cy.get('input[name="kontoNr"]').type('1234567890');
        cy.contains('Beløb til refusion').should('have.text', 'Beløb til refusion: 25,00 kr.');

        cy.intercept('POST', '/api/refund/refundOrders', {
          statusCode: 201,
        }).as('createRefundRequest');

        cy.get('button[type="submit"]').click();

        cy.wait('@createRefundRequest').then((network) => {
          const refundOrders = network.request.body.refundOrders;
          expect(refundOrders)
            .to.be.an('array')
            .of.length(1)
            .that.have.deep.members([
              {
                comment: '',
                refundChannel: 'BankTransfer',
                amount: null,
                electronicPaymentMethodId: '8ad08871828227c80182824e45b85065',
                sourceType: 'CreditBalance',
                regNr: '1234',
                kontoNr: '1234567890',
                refundFullAmount: true,
                effectiveDate: futureDate.toJSON(),
              },
            ]);
        });
      });
    });

    describe('when selecting invoice payments to refund', () => {
      beforeEach(() => {
        cy.mount(<MockApp route={route} user={user} />);

        // select creditcard invoicepayment
        cy.contains('P-01262548')
          .closest('tr')
          .within(() => {
            cy.get('input[type="checkbox"]').click();
            cy.get('input[type="text"]').should('have.value', '74').as('creditCardPaymentRefund');
          });
      });

      it('should submit (adjusted) amounts', () => {
        // Adjust credit balance refund amount

        cy.get('@creditCardPaymentRefund').clear().type('{selectAll}37,5');

        cy.contains('Beløb til refusion').should('have.text', 'Beløb til refusion: 37,50 kr.');

        // Submit values
        cy.intercept('POST', '/api/refund/refundOrders', {
          statusCode: 201,
        }).as('createRefundRequest');

        cy.get('button[type="submit"]').click();

        cy.wait('@createRefundRequest').then((network) => {
          const refundOrders = network.request.body.refundOrders;
          expect(refundOrders)
            .to.be.an('array')
            .of.length(1)
            .that.have.deep.members([
              {
                comment: '',
                effectiveDate: null,
                paymentNumber: 'P-01262548',
                paymentId: '8ad092dd82c5dd4e0182c8033b5757f9',
                invoiceNumber: 'FAK06827922',
                invoiceId: '8ad08ce0827dc62c018281dfed1e4fac',
                refundChannel: 'CreditCard',
                amount: 37.5,
                electronicPaymentMethodId: null,
                sourceType: 'Payment',
              },
            ]);
        });

        // TODO: Assert that form resets on submit
      });

      describe('Validation', () => {
        describe('when only creditcard payments are selected', () => {
          it('it should enable creditcard refund option', () => {
            cy.contains('label', 'Udbetaling til kreditkort')
              .siblings('input[type="radio"]')
              .first()
              .should('not.be.disabled');

            cy.contains('label', 'Udbetaling til bankkonto')
              .siblings('input[type="radio"]')
              .first()
              .should('not.be.disabled');
          });
        });

        describe('when external payments are selected', () => {
          beforeEach(() => {
            // select external invoicepayment
            cy.contains('td', 'Alm. indbetaling')
              .closest('tr')
              .within(() => {
                cy.get('input[type="checkbox"]').click();
                cy.get('input[type="text"]').as('externalPaymentRefund');
              });
          });
          it('it should disable creditcard refund option', () => {
            cy.contains('label', 'Udbetaling til kreditkort')
              .siblings('input[type="radio"]')
              .first()
              .should('be.disabled');

            cy.contains('label', 'Udbetaling til bankkonto')
              .siblings('input[type="radio"]')
              .first()
              .should('not.be.disabled');

            // Display validation error on submit
            cy.get('button[type="submit"]').click();
            cy.contains(
              'Kreditkort kan kun vælges når alle valgte betalinger er betalt med kreditkort'
            ).should('be.visible');
          });

          describe('and bank account refund is selected', () => {
            beforeEach(() => {
              cy.contains('label', 'Udbetaling til bankkonto').click();
            });

            describe('and invalid regnr and kontonr is entered', () => {
              it('it should display validation error on submit', () => {
                cy.get('button[type="submit"]').click();
                cy.get('input[placeholder="Reg.nr."]').should('have.class', 'is-invalid');
                cy.get('input[placeholder="Konto nr."]').should('have.class', 'is-invalid');

                cy.get('input[placeholder="Reg.nr."]')
                  .type('1234')
                  .should('not.have.class', 'is-invalid');
                cy.get('input[placeholder="Konto nr."]')
                  .type('123456')
                  .should('not.have.class', 'is-invalid');
              });
            });

            describe('and not all refund amounts are valid', () => {
              it('should display validation error on submit', () => {
                // Enter valid bank account info
                cy.get('input[placeholder="Reg.nr."]').type('1234');
                cy.get('input[placeholder="Konto nr."]').type('123456');

                cy.get('@creditCardPaymentRefund').clear().type('{selectAll}-5');
                cy.get('button[type="submit"]').click();
                cy.get('@creditCardPaymentRefund').should('have.class', 'is-invalid');
                cy.contains('Valgte tilbagebetalinger er ikke alle valide').should('be.visible');
              });
            });
          });
        });
      });
    });
  });
});
