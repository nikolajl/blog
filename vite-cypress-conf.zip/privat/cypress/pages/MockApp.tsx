import { createMemoryHistory, Outlet, ReactLocation, Router } from '@tanstack/react-location';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Header from '@/components/navigation/Header';
import routes from '@/pages/routes';
import ToastProvider from '@/components/messages/ToastProvider';
import { MockAuthProvider } from '@/components/providers/AuthProvider';
import { UserInfo } from '@/api/user';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
    },
  },
});

type Props = {
  route: string;
  user?: UserInfo;
  withHeader?: boolean;
};
/**
 * Usage: <MockApp route="/path/in/route" />
 * Usage: <MockApp route="/path/in/route" withHeader/> renders the route with header. Remember to intercept network requests
 * Usage: <MockApp route="/path/in/route" user={mockUser}/> renders the route with Auth guards using mockUser
 * Usage: <MockApp route="/path/in/route" flags={mockFlags}/> renders the route with Auth guards using mockFlags
 * */
export default function MockApp({ route, user, withHeader = false }: Props) {
  // Set up a "fake" ReactLocation instance with the route url from props
  const location = new ReactLocation({
    history: createMemoryHistory({
      initialEntries: [`${route}`],
    }),
  });

  return (
    <QueryClientProvider client={queryClient}>
      <Router location={location} routes={routes}>
        <ToastProvider>
          <MockAuthProvider user={user ?? fakeUser()}>
            {withHeader ?? <Header />}
            <Outlet />
          </MockAuthProvider>
        </ToastProvider>
      </Router>
    </QueryClientProvider>
  );
}

export const allTenants = () => [
  { key: 'Jp', name: 'Jyllands-Posten' },
  { key: 'Pol', name: 'Politiken' },
  { key: 'Eb', name: 'Ekstra Bladet' },
  { key: 'Watch', name: 'Watch Medier' },
  { key: 'Monitormedier', name: 'Monitormedier' },
];

export function fakeUser(values?: Partial<UserInfo>): UserInfo {
  const tenants = values?.tenants ?? [allTenants()[0]];
  const selectedTenant = values?.selectedTenant ?? tenants[0];

  return {
    user: 'Nikolaj Lundsgaard',
    flags: {},
    claims: [],
    selectedTenant,
    tenants,
    ...values,
  };
}
