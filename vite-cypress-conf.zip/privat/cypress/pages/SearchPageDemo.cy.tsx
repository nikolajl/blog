import MockApp from './MockApp';

describe('<SearchPageDemo>', () => {
  it('should show up', () => {
    cy.mount(<MockApp route="/search-demo" />);
    cy.get('h1').should('have.text', 'Kundesøgning');
  });

  it('should show search results', () => {
    cy.mount(<MockApp route="/search-demo" />);

    cy.intercept('/api/search?input=Kreditkort', {
      fixture: 'demo-search/kreditkort',
    });

    cy.get('input[name="search"]').type('Kreditkort');
    cy.get('button').click();

    cy.get('tbody tr').should('have.length', 3);
  });
});
