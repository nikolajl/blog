import { formatDate } from '@/utils/format';
import MockApp, { fakeUser } from './MockApp';

// import chaiDeepMatch from 'chai-deep-match';

const startDate = new Date();
startDate.setHours(0, 0, 0, 0);

describe('PurchaseSubscriptionPage', () => {
  beforeEach(() => {
    cy.intercept('/api/next-valid-delivery-date', new Date());
    cy.intercept('/api/v2/catalog/products', { fixture: 'products/getProducts' });

    cy.intercept(
      {
        url: 'https://api.dataforsyningen.dk/adresser/autocomplete',
      },
      {
        fixture: 'dawa/getAddress',
      }
    );
  });

  it('should mount', () => {
    cy.mount(<MockApp route="/purchase-subscription" />);
    cy.get('h1').should('have.text', 'Opret ny kunde');
  });

  describe('when user has chosen product and startdate', () => {
    beforeEach(() => {
      chooseProductAndDate();
    });

    it('should have a startdate', () => {
      cy.get('input[placeholder="Vælg startdato"]').should('have.value', formatDate(startDate));
    });

    it('should be able to add the product to the basket', () => {
      cy.get('button').contains('Tilføj produkt til kurv').click();
      cy.get('summary').contains('JP Digital Pro inkl. Finans');
    });

    it('should be able to remove a product from the basket', () => {
      cy.get('button').contains('Tilføj produkt til kurv').click();
      cy.get('summary > button').click();
      cy.get('summary').should('not.exist');
    });

    it('should be able to fill in name an billingaddress', () => {
      fillInBillingAddress();
    });
  });

  describe('when user adds a print product to the basket', () => {
    beforeEach(() => {
      addPrintProductToBasket();
    });
    it("should show an enabled 'Køb' button", () => {
      cy.contains('Køb').should('not.be.disabled');
      cy.contains('Køb').click();
    });

    it("should show required/invalid fields in billing address when pressing 'Køb' button (default payment)", () => {
      cy.contains('Køb').click();
      cy.get('input[placeholder="Fornavn"]').should('have.class', 'is-invalid');
      cy.get('input[placeholder="Efternavn"]').should('have.class', 'is-invalid');
      cy.contains('Indtast adresse').parent().parent().parent().should('have.class', 'required');
    });

    it("should show required/invalid fields in billing address when pressing 'Køb' button (MobilePay)", () => {
      cy.get('input[value="MobilePay"]').click();
      cy.contains('Køb').click();
      cy.get('input[placeholder="Fornavn"]').should('have.class', 'is-invalid');
      cy.get('input[placeholder="Efternavn"]').should('have.class', 'is-invalid');
      cy.get('input[placeholder="Telefon"]').should('have.class', 'is-invalid');
    });

    it("should show required/invalid fields in billing address when pressing 'Køb' button (CreditCard)", () => {
      cy.get('input[value="NewPaymentMethod"]').click();
      cy.contains('Køb').click();
      cy.get('input[placeholder="Fornavn"]').should('have.class', 'is-invalid');
      cy.get('input[placeholder="Efternavn"]').should('have.class', 'is-invalid');
      cy.contains('Indtast adresse').parent().parent().parent().should('have.class', 'required');
    });

    it("should show required/invalid fields in billing address when pressing 'Køb' button (EAN)", () => {
      cy.get('input[value="EAN"]').click();
      cy.contains('Køb').click();
      cy.get('input[placeholder="EAN"]').should('have.class', 'is-invalid');
      cy.get('input[placeholder="Fornavn"]').should('have.class', 'is-invalid');
      cy.get('input[placeholder="Efternavn"]').should('have.class', 'is-invalid');
      cy.contains('Indtast adresse').parent().parent().parent().should('have.class', 'required');
    });

    it("should show required/invalid fields in billing address when pressing 'Køb' button (BankTransfer)", () => {
      cy.get('input[value="BankTransfer"]').click();
      cy.contains('Køb').click();
      cy.get('input[placeholder="Fornavn"]').should('have.class', 'is-invalid');
      cy.get('input[placeholder="Efternavn"]').should('have.class', 'is-invalid');
      cy.contains('Indtast adresse').parent().parent().parent().should('have.class', 'required');
      cy.get('input[placeholder="E-mail"]').should('have.class', 'is-invalid');
    });

    it('should show deliveryaddress checkbox', () => {
      cy.contains('Anden modtager');
    });
  });

  describe('when user chooses business (erhverv)', () => {
    beforeEach(() => {
      addDigitalProductToBasket();
      //addPrintProductToBasket();
      cy.get('input[value="Business"]').click();
    });
    it('should have companyname and address as a required field', () => {
      cy.contains('Køb').click();
      cy.get('input[placeholder="Firmanavn"').should('have.class', 'is-invalid');
      cy.contains('Indtast adresse').parent().parent().parent().should('have.class', 'required');
    });

    it('should show payment terms panel', () => {
      cy.contains('Køb').click();
      cy.get('input[name="paymentTerms"]').should('have.length', 4);
    });

    describe('when business user chooses MobilePay', () => {
      it('should hide payment terms panel', () => {
        cy.get('input[name="paymentTerms"]').should('have.length', 4);
        cy.get('input[value="MobilePay"]').click();
        cy.get('input[name="paymentTerms"]').should('have.length', 0);
      });

      it('should have phonenumber as a required field', () => {
        cy.get('input[value="MobilePay"]').click();
        cy.contains('Køb').click();
        cy.get('input[placeholder="Telefon"]').should('have.class', 'is-invalid');
      });
    });
  });

  describe.skip('when user chooses foreign address', () => {
    beforeEach(() => {
      addDigitalProductToBasket();
      cy.intercept('/Distribution/GetCountries', {
        fixture: 'distribution/getCountries',
      });
      cy.contains('Udenlandsk adresse').click();
    });

    it('should have choose firstname, lastname, country, addressline 1, addressline 2 as required fields', () => {
      cy.contains('Køb').click();
      cy.get('input[name="billingAddress.firstName"]').should('have.class', 'is-invalid');
      cy.get('input[name="billingAddress.lastName"]').should('have.class', 'is-invalid');
      fillInFirstLastName();
      cy.get('input[name="billingAddress.firstName"]').should('not.have.class', 'is-invalid');
      cy.get('input[name="billingAddress.lastName"]').should('not.have.class', 'is-invalid');

      cy.contains('Vælg land').parent().parent().parent().should('have.class', 'invalid');
      chooseCountry(); // Afghanistan
      cy.contains('Afghanistan').parent().parent().parent().should('not.have.class', 'invalid');
      cy.get('input[name="billingAddress.addressLine1"]')
        .should('have.class', 'is-invalid')
        .type('adresse 1')
        .should('not.have.class', 'is-invalid');
      cy.get('input[name="billingAddress.addressLine2"]')
        .should('have.class', 'is-invalid')
        .type('adresse 2')
        .should('not.have.class', 'is-invalid');
    });
  });

  describe('when user has both print and digital products i basket', () => {
    beforeEach(() => {
      addDigitalProductToBasket();
      addPrintProductToBasket();
      fillInFirstLastName();
    });

    it('should have EAN as reqired field when choosing EAN as payment method', () => {
      cy.get('input[value="EAN"]').click();
      cy.contains('Køb').click();
      cy.get('input[placeholder="EAN"]')
        .should('have.class', 'is-invalid')
        .type('1234567890123')
        .should('not.have.class', 'is-invalid');
    });

    it('should have email as required field when choosing Banktransfer as payment method', () => {
      cy.get('input[value="BankTransfer"]').click();
      cy.contains('Køb').click();
      cy.get('input[placeholder="E-mail"]')
        .should('have.class', 'is-invalid')
        .type('some@funnymail.com')
        .should('not.have.class', 'is-invalid');
    });

    it('should have Phonenumber as required field when choosing MobilePay as payment method', () => {
      cy.get('input[value="MobilePay"]').click();
      cy.contains('Køb').click();
      cy.get('input[placeholder="Telefon"]')
        .should('have.class', 'is-invalid') // required
        .type('12345678') // 8 digits danish number
        .should('not.have.class', 'is-invalid')
        .clear()
        .type('+4512345678') // country code + 8 digits danish number
        .should('not.have.class', 'is-invalid');
      // TODO add an actual phonenumber validation in the schema
    });
  });

  describe('when user has only trials in basket', () => {
    beforeEach(() => {
      addTrialToBasket();
    });

    it('should set paymentmethod to no payment and hide paymentmethod panel', () => {
      cy.get('input[name="paymentTerms"]').should('have.length', 0); // payment terms panel is hidden
      // todo check (if possible) if no payment is choosen
    });
  });
  describe('when user has chosen product and startdate and filled in name and billingaddress', () => {
    it('should be able to submit', () => {
      chooseProductAndDate();
      fillInBillingAddress();
      cy.intercept('POST', '/api/orders/purchase', {
        fixture: 'subscription-order-purchase/performPurchase',
      }).as('performPurchase');

      cy.intercept('GET', '/api/subscription-orders/order/*', {
        fixture: 'subscription-order-purchase/getOrder',
      }).as('getOrderStatus');

      cy.contains('Køb').click();

      cy.wait('@performPurchase').then((network) => {
        const payload = network.request.body;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        payload.basket.forEach((x: any) => {
          delete x.key;
        });
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        payload.products.forEach((x: any) => delete x.key);

        expect(payload)
          .to.be.an('object')
          .that.deep.equals({
            brand: 'JyllandsPosten',
            basket: [
              {
                type: 'product',

                billingPeriodAlignment: 'AlignToCharge',
                ratePlan: {
                  name: 'JP Digital Pro inkl. Finans IP/Domæne',
                  description: 'IP/Domæne 12 mdr.',
                  productRatePlanId: '2c92c0f8796a12c701796b2fa21477ce',
                  isTrial: false,
                  billingPeriodLength: 1,
                  billingPeriodUnitOfMeasureEnumString: 'Year',
                  duration: null,
                  durationUnitOfMeasure: null,
                  pricing: {
                    upFrontPrice: '1.00',
                    upFrontTaxAmount: '0.00',
                    recurringPrice: '1.00',
                    recurringTaxAmount: '0.00',
                    currency: 'DKK',
                  },
                  accessFeatures: [
                    { accessFeatureName: 'Finans COMPANY DATA', weekdayMask: '1234567' },
                    { accessFeatureName: 'Finans LOCKED ARTICLE', weekdayMask: '1234567' },
                    { accessFeatureName: 'Jyllands-Posten COMPANY DATA', weekdayMask: '1234567' },
                    { accessFeatureName: 'Jyllands-Posten EPAPER', weekdayMask: '1234567' },
                    { accessFeatureName: 'Jyllands-Posten EPAPER ARCHIVE', weekdayMask: '1234567' },
                    { accessFeatureName: 'Jyllands-Posten LOCKED ARTICLE', weekdayMask: '1234567' },
                  ],
                  productRatePlanCharges: [
                    {
                      name: 'Erhvervsdata Finans',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa40d77e8',
                      dimension: '2677 - JP Finans',
                    },
                    {
                      name: 'E-avis arkiv',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa2e577d5',
                      dimension: '2017 - Jyllands-Posten E-avis erhverv',
                    },
                    {
                      name: 'Erhvervsdata JP',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa4cc77f2',
                      dimension: '2017 - Jyllands-Posten E-avis erhverv',
                    },
                    {
                      name: 'Finans',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa26877d0',
                      dimension: '2677 - JP Finans',
                    },
                    {
                      name: 'E-avis',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa3af77e3',
                      dimension: '2017 - Jyllands-Posten E-avis erhverv',
                    },
                    {
                      name: 'Premium',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa47377ed',
                      dimension: '2017 - Jyllands-Posten E-avis erhverv',
                    },
                  ],
                },
                startDate: startDate.toISOString(),
              },
            ],
            hasDeliveryAddress: false,
            paymentMethod: 'PaymentSlip',
            accountType: 'Consumer',
            billingAddressType: 'DkAddress',
            billingAddress: {
              customerReference: '',
              firstName: 'John',
              lastName: 'Doe',
              coName: '',
              internalLocation: '',
              email: 'postkasse@example-mail.dk',
              phonePrimary: '',
              phoneSecondary: '',
              masterAddressPoint: 280681378,
              houseFloor: null,
              houseSide: null,
            },
            products: [
              {
                type: 'product',
                billingPeriodAlignment: 'AlignToCharge',
                ratePlan: {
                  name: 'JP Digital Pro inkl. Finans IP/Domæne',
                  description: 'IP/Domæne 12 mdr.',
                  productRatePlanId: '2c92c0f8796a12c701796b2fa21477ce',
                  isTrial: false,
                  billingPeriodLength: 1,
                  billingPeriodUnitOfMeasureEnumString: 'Year',
                  duration: null,
                  durationUnitOfMeasure: null,
                  pricing: {
                    upFrontPrice: '1.00',
                    upFrontTaxAmount: '0.00',
                    recurringPrice: '1.00',
                    recurringTaxAmount: '0.00',
                    currency: 'DKK',
                  },
                  accessFeatures: [
                    { accessFeatureName: 'Finans COMPANY DATA', weekdayMask: '1234567' },
                    { accessFeatureName: 'Finans LOCKED ARTICLE', weekdayMask: '1234567' },
                    { accessFeatureName: 'Jyllands-Posten COMPANY DATA', weekdayMask: '1234567' },
                    { accessFeatureName: 'Jyllands-Posten EPAPER', weekdayMask: '1234567' },
                    { accessFeatureName: 'Jyllands-Posten EPAPER ARCHIVE', weekdayMask: '1234567' },
                    { accessFeatureName: 'Jyllands-Posten LOCKED ARTICLE', weekdayMask: '1234567' },
                  ],
                  productRatePlanCharges: [
                    {
                      name: 'Erhvervsdata Finans',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa40d77e8',
                      dimension: '2677 - JP Finans',
                    },
                    {
                      name: 'E-avis arkiv',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa2e577d5',
                      dimension: '2017 - Jyllands-Posten E-avis erhverv',
                    },
                    {
                      name: 'Erhvervsdata JP',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa4cc77f2',
                      dimension: '2017 - Jyllands-Posten E-avis erhverv',
                    },
                    {
                      name: 'Finans',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa26877d0',
                      dimension: '2677 - JP Finans',
                    },
                    {
                      name: 'E-avis',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa3af77e3',
                      dimension: '2017 - Jyllands-Posten E-avis erhverv',
                    },
                    {
                      name: 'Premium',
                      currency: 'DKK',
                      id: '2c92c0f8796a12c701796b2fa47377ed',
                      dimension: '2017 - Jyllands-Posten E-avis erhverv',
                    },
                  ],
                },
                startDate: startDate.toISOString(),
              },
            ],
            campaigns: [],
            discounts: [],
            mobilePayRedirectLink: 'https://test-eb-kundeoverblik.jppol.dk/empty.html',
          });
      });

      cy.url().should(
        'contain',
        '/Customer/ViewCustomer/fake-sso?accountNumber=18192809280192801928098&subscriptionNumber=AB15612578290871987'
      );
    });
  });
});

function addTrialToBasket() {
  const user = fakeUser({
    flags: { MobilePayPaymentMethod: true, CreditCardPaymentMethod: true },
  });
  cy.mount(<MockApp route="/purchase-subscription" user={user} />);
  cy.get('#choose-product > button').click();
  cy.get('#choose-product a').contains('JP Komplet').click();

  cy.get('[data-cy="choose-plan"] > button').click();
  cy.get('[data-cy="choose-plan"] a').contains('Lørdagslevering').first().click();

  cy.get('input[placeholder="Vælg startdato"]').type(formatDate(startDate) as string);

  cy.get('button').contains('Tilføj produkt til kurv').click();
}

function addDigitalProductToBasket() {
  const user = fakeUser({
    flags: { MobilePayPaymentMethod: true, CreditCardPaymentMethod: true },
  });
  cy.mount(<MockApp route="/purchase-subscription" user={user} />);
  cy.get('#choose-product > button').click();
  cy.get('#choose-product a').contains('JP Digital').click();

  cy.get('[data-cy="choose-plan"] > button').click();
  cy.get('[data-cy="choose-plan"] a').contains('JP Digital').first().click();

  cy.get('input[placeholder="Vælg startdato"]').type(formatDate(startDate) as string);

  cy.get('button').contains('Tilføj produkt til kurv').click();
}

function addPrintProductToBasket() {
  const user = fakeUser({
    flags: { MobilePayPaymentMethod: true, CreditCardPaymentMethod: true },
  });
  cy.mount(<MockApp route="/purchase-subscription" user={user} />);
  cy.get('#choose-product > button').click();
  cy.get('#choose-product a').contains('JP Avis').click();

  cy.get('[data-cy="choose-plan"] > button').click();
  cy.get('[data-cy="choose-plan"] a').contains('JP Avis søndag').first().click();

  cy.get('input[placeholder="Vælg startdato"]').type(formatDate(startDate) as string);

  cy.get('button').contains('Tilføj produkt til kurv').click();
}

function chooseProductAndDate() {
  cy.mount(<MockApp route="/purchase-subscription" />);
  cy.get('#choose-product > button').click();
  cy.get('#choose-product a').contains('JP Digital Pro inkl. Finans').click();

  cy.get('[data-cy="choose-plan"] > button').click();
  cy.get('[data-cy="choose-plan"] a').contains('JP Digital').first().click();

  cy.get('input[placeholder="Vælg startdato"]').type(formatDate(startDate) as string);
}

function chooseCountry(country = 'Afghanistan') {
  cy.intercept('/Distribution/GetCountries', {
    fixture: 'distribution/getCountries',
  });
  cy.get('.countries-select').parent().find('input').click();
  cy.get('.countries-select').parent().find('input').type(country);
  cy.get('.countries-select > div').contains(country).click();
}

function fillInBillingAddress() {
  cy.intercept('/Distribution/LookUpAddress?streetName=Asmild+Ager&zipCode=8800&countryCode=DK', {
    fixture: 'distribution/getAddress',
  });
  cy.get('button').contains('Tilføj produkt til kurv').click();
  fillInFirstLastName();
  cy.get('.dawa-autocomplete').find('input').first().type('Asmild Ager 2');
  cy.get('.dawa-autocomplete > div').contains('Asmild Ager 2, 8800 Viborg').click();
  cy.get('input[name="billingAddress.email"]').type('postkasse@example-mail.dk');
}

function fillInFirstLastName() {
  cy.get('input[name="billingAddress.firstName"]').type('John');
  cy.get('input[name="billingAddress.lastName"]').type('Doe');
}
