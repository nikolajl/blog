import { defineConfig, splitVendorChunkPlugin } from 'vite';
import react from '@vitejs/plugin-react';
import * as path from 'path';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), splitVendorChunkPlugin()],
  build: {
    outDir: '../CustomerOverview.Web/wwwroot/spa',
    sourcemap: true,
    emptyOutDir: true,
  },
  base: '/spa/',
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      '~bootstrap': path.resolve(__dirname, 'node_modules/bootstrap'),
    },
  },
  // Dev server config
  server: {
    host: 'localhost',
    hmr: {
      protocol: 'ws',
    },
  },
});
