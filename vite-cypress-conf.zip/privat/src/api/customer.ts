import { axiosClient } from '@/utils/axiosClient';
import { useQuery } from '@tanstack/react-query';

type SsoUser = {
  addressFormatted?: string;
  apartment?: string;
  city?: string;
  email?: string;
  emailIsBlocked?: boolean;
  firstName?: string;
  floor?: string;
  fullName?: string;
  houseNo?: string;
  isActivated?: boolean;
  isLockedOut?: boolean;
  lastName?: string;
  loginCreated?: boolean;
  phone?: string;
  ssoId?: string;
  street?: string;
  validatedYouth?: string;
  zipCode?: string;
};
const fetchSsoUser = (ssoId: string) =>
  axiosClient.get<SsoUser>(`/api/ssoid/medielogin/${ssoId}`).then(({ data }) => data);

export const useSsoUser = (ssoId: string) =>
  useQuery(['sso-user'], () => fetchSsoUser(ssoId), { enabled: !!ssoId });
