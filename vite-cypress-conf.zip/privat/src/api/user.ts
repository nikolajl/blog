import { AxiosError } from 'axios';
import { useMutation, useQuery } from '@tanstack/react-query';
import { useToastProvider } from '@/components/messages/ToastProvider';
import { axiosClient } from '@/utils/axiosClient';

type Tenant = {
  key: string;
  name: string;
};

type Claim = 'Kundeoverblik.GodkendUdbetalinger' | 'JPS Support';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type LDFlags = Record<string, any>; // boolean | number

export type UserInfo = {
  user: string;
  flags: LDFlags;
  tenants: Tenant[];
  selectedTenant: {
    name: string;
  };
  claims: Claim[];
};

// TODO: This should really not be GET
const setTenant = (tenant: string) => axiosClient.get(`/tenant/set/${tenant}`);

const getUser = () => axiosClient.get<UserInfo>('/api/user').then(({ data }) => data);

export const useSetTenantMutation = () => {
  const { showError } = useToastProvider();

  return useMutation(['setTenant'], setTenant, {
    onSuccess() {
      window.location.reload();
    },
    onError(error: AxiosError, tenant: string) {
      if (error.code === AxiosError.ERR_BAD_REQUEST) {
        showError(`Tenant '${tenant}' findes ikke`);
      } else {
        showError(`Fejl opstod ved skift '${tenant}'`, error.message);
      }
    },
  });
};

export const useUser = () => useQuery(['user'], getUser);
