import { axiosClient } from '@/utils/axiosClient';
import { useQuery } from '@tanstack/react-query';

const fetchQuarantines = (ssoId: string) =>
  axiosClient.get<QuarantineResponse>(`/api/quarantines/${ssoId}`).then(({ data }) => data);

export const useQuarantines = (ssoId: string) =>
  useQuery(['quarantines', ssoId], async () => await fetchQuarantines(ssoId));

type Quarantine = {
  SsoId: string;
  BrandEnumString: string;
  Identifier: string;
  Description: string;
  ExpireDate: string;
};

type QuarantineResponse = {
  quarantines: Quarantine[];
  hasNextPage: boolean;
  totalCount: number;
};
