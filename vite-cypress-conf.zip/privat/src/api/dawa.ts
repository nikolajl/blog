// https://api.dataforsyningen.dk/autocomplete

import { axiosClient } from '@/utils/axiosClient';
import { useQuery } from '@tanstack/react-query';

const dawaBasePath = 'https://api.dataforsyningen.dk';

export type DawaAutoCompleteResult = {
  data: DawaAddress;
  tekst: string;
  forslagstekst: string;
  stormodtagerpostnr: boolean;
};

type DawaAddress = {
  id: string;
  status: number;
  vejnavn: string;
  husnr: string;
  etage?: string;
  dør?: string;
  postnr: string;
  postnrnavn: string;
  stormodtagerpostnr: string;
  stormodtagerpostnrnavn: string;
};

const fetchAutoCompleteAddresses = (query: string) =>
  axiosClient
    .get<DawaAutoCompleteResult[]>(
      `${dawaBasePath}/autocomplete?q=${query}&type=adresse&stormodtagerpostnumre=true&startfra=adgangsadresse&fuzzy=`
    )
    .then(({ data }) => data);

export const useAutoCompleteAddresses = (query: string) =>
  useQuery(['auto-complete-addresses', query], () => fetchAutoCompleteAddresses(query), {
    enabled: !!query,
  });
