import { useQuery } from '@tanstack/react-query';
import { axiosClient } from '@/utils/axiosClient';
import { Product, Campaign, CampaignOffer } from './types/catalog';

// TODO: Api: Align mapping so accessfeatureName => accessfeature
const fetchProductCatalog = () =>
  axiosClient.get<Array<Product>>(`/api/v2/catalog/products`).then(({ data }) => {
    return data;
  });

const fetchCampaignCatalog = () =>
  axiosClient.get<Array<Campaign>>(`/api/v2/catalog/campaigns`).then(({ data }) => data);

const fetchCampaignOfferById = (
  brand?: string,
  campaignFriendlyId?: string,
  offerFriendlyId?: string,
  startDate?: Date
) =>
  axiosClient
    .get<CampaignOffer>(
      `/api/v2/catalog/campaigns/${brand}/${campaignFriendlyId}/${offerFriendlyId}`,
      {
        params: {
          startDate,
        },
      }
    )
    .then(({ data }) => data);

export const useProductCatalog = () =>
  useQuery(['product-catalog'], () => fetchProductCatalog(), {
    cacheTime: Infinity,
    staleTime: Infinity,
  });

export const useCampaignCatalog = () =>
  useQuery(['campaign-catalog'], () => fetchCampaignCatalog(), {
    cacheTime: Infinity,
    staleTime: Infinity,
  });

export const useCampaignOfferById = (
  brand?: string,
  campaignFriendlyId?: string,
  offerFriendlyId?: string,
  startDate?: Date
) =>
  useQuery(
    ['campaign-offer-by-id', brand, campaignFriendlyId, offerFriendlyId, startDate],
    () =>
      fetchCampaignOfferById(brand, campaignFriendlyId, offerFriendlyId, startDate ?? new Date()),
    {
      enabled: !!(brand && campaignFriendlyId && offerFriendlyId),
    }
  );
