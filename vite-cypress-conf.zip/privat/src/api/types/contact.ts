export type Contact = {
  ean?: string;
  customerReference?: string;
  firstName?: string;
  brand?: string;
  lastName?: string;
  companyName?: string;
  cvr?: string;
  vatNr?: string;
  email?: string;
  phoneNumberPrimary?: string;
  phoneNumberSecondary?: string;
  coName?: string;
  birthday?: Date;
  taxCode?: string;
  dkAddress?: DkAddress;
  foreignAddress?: ForeignAddress;
  sexType?: Sex;
};

export type DkAddress = {
  addressPointId: number;
  streetName: string;
  houseNumber: number;
  houseLetter?: string;
  houseFloor?: string;
  houseSide?: string;
  zipCode: string;
  city: string;
  mailbox?: string;
  internalLocation?: string;
};

export type ForeignAddress = {
  addressLine1: string;
  addressLine2: string;
  addressLine3: string;
  addressLine4: string;
  internalLocation: string;
  countryCode: string;
};

type Sex = 'NotKnown' | 'Male' | 'Female' | 'Business' | 'NotApplicable';
