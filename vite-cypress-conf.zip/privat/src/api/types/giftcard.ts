export type GiftCardType = 'Purchase' | 'Redeem';

export type GiftCard = {
  id: string;
  status: GiftCardStatus;
  createdAt: Date;
  updatedAt: Date;
  giftCardProductRatePlanId: string;
  amount: number;
  expiresAt: Date;
  redeemGiftCardCampaignOfferId: string;
  redeemGiftCardProductRatePlanId: string;
};

type GiftCardStatus = 'Reserved' | 'Redeemed' | 'Active';
