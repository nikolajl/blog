export type AccountV2 = {
  basicInfo?: AccountBasicInfo;
  billToContact?: Contact;
  billingAndPayment?: AccountBillingAndPayment;
  metrics?: AccountMetricsResponse;
  soldToContact?: Contact;
  success?: boolean;
};

type SurchargeExemption = 'Never' | 'NextInvoice' | 'Always';
type Sex = 'NotKnown' | 'Male' | 'Female' | 'Business' | 'NotApplicable';

type AccountBasicInfo = {
  surchargeExemption?: SurchargeExemption;
  accountNumber?: string;
  batch?: string;
  communicationProfileId?: string;
  crmId?: string;
  id?: string;
  parentId?: string;
  invoiceTemplateId?: string;
  name?: string;
  notes?: string;
  status?: string;
  tags?: string;
  accountTypeC?: string;
  brandC?: string;
  ssoIdC?: string;
  billToContactLabel01C?: string;
  billToContactLabel02C?: string;
  billToContactLabel03C?: string;
  billToContactLabel04C?: string;
  billToContactLabel05C?: string;
  billToContactLabel06C?: string;
  billToContactLabel07C?: string;
  billToContactLabel08C?: string;
  gracePeriodC?: Date;
  eanC?: string;
  customerReferenceC?: string;
  invoiceSubscriptionsSeparately: boolean;
  consolidatedInvoice: boolean;
};

export type Contact = {
  address1?: string;
  address2?: string;
  city?: string;
  country?: string;
  county?: string;
  fax?: string;
  firstName?: string;
  homePhone?: string;
  lastName?: string;
  mobilePhone?: string;
  nickname?: string;
  otherPhone?: string;
  otherPhoneType?: string;
  personalEmail?: string;
  state?: string;
  taxRegion?: string;
  workEmail?: string;
  workPhone?: string;
  zipCode?: string;
  countryCodeC?: string;
  foreignAddress1C?: string;
  foreignAddress2C?: string;
  foreignAddress3C?: string;
  foreignAddress4C?: string;
  addressPointC?: string;
  floorC?: string;
  sideC?: string;
  postboxC?: string;
  companyNameC?: string;
  coNameC?: string;
  cvrC?: string;
  phonePrimaryC?: string;
  phoneSecondaryC?: string;
  sexTypeC?: Sex;
  birthdayC?: string;
  vatC?: string;
};

type AccountBillingAndPayment = {
  additionalEmailAddresses?: string[];
  billCycleDay?: string;
  currency?: string;
  invoiceDeliveryPrefsEmail?: boolean;
  invoiceDeliveryPrefsPrint?: boolean;
  paymentGateway?: string;
  paymentTerm?: string;
};

type AccountMetricsResponse = {
  balance?: number;
  contractedMrr?: number;
  creditBalance?: number;
  totalInvoiceBalance?: number;
};
