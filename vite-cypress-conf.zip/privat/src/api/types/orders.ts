type CreatedSubscription = {
  SubscriptionNumber?: string;
  AccountNumber?: string;
};

export type SubscriptionOrder = {
  StatusEnumString: 'Finished' | 'Committed' | 'Error';
  SsoId: string;
  CreatedSubscription?: CreatedSubscription;
};

export type PurchaseResponse = {
  orderNumber: string;
  redirectUrl?: string;
};
