export type BillingPeriodAlignment =
  | 'AlignToTerm'
  | 'AlignToCharge'
  | 'AlignToSubscriptionStart'
  | 'Unknown';

export type AccessFeature = {
  accessFeatureName: string;
  weekdayMask: string;
};

type DiscountType = 'Percentage' | 'FixedAmount';

// Campaign specific
export type Campaign = {
  campaignDisplayName: string;
  campaignFriendlyId: string;
  brandName: string;
  offers: Array<SimpleCampaignOffer>;
};

type SimpleCampaignOffer = {
  offerDisplayName: string;
  offerFriendlyId: string;
  hasAbsoluteDateDiscountSteps: boolean;
  periodPrice: number;
  isTrial: boolean;
};

export type CampaignOffer = {
  campaignFriendlyId: string;
  campaignDisplayName: string;
  offerFriendlyId: string;
  offerDisplayName: string;
  currency: string;
  type: CampaignType;
  orderEffectiveDate?: Date;
  startDate?: string;
  endDate?: string;
  products: Array<CampaignOfferStep>;
};

// TODO: Should we call this CampaignProduct?
export type CampaignOfferStep = {
  startDate: Date;
  endDate?: Date;
  description: string;
  type: StepType;
  name: string;
  idToPurchase: string;
  periodPrice: number;
  billingPeriodType: string;
  billingPeriodUnitAmount?: number;
  billingPeriodAlignment: BillingPeriodAlignment;
  priceOverrides?: PriceOverrideCharge[];
  discounts?: DiscountCharge[];
  group?: GroupCharge;
  chargeInfos?: ChargeInfo[];
};

type PriceOverrideCharge = {
  appliesToId: string;
  price: number;
};

type DiscountCharge = {
  id: string;
  discountType: DiscountType;
  amount: number;
};

type GroupCharge = {
  groupId: string;
  type: string;
};

export type ChargeInfo = {
  productRatePlanChargeName: string;
  productRatePlanChargeId: string;
  accessFeature: string;
  weekdayMask?: string;
};

type StepType = 'BaseProductStep' | 'PeriodDiscountStep' | 'AbsoluteDateDiscountStep';
type CampaignType = 'WithPeriodicDiscounts' | 'WithAbsoluteDateDiscounts';

// Product specific
export type Product = {
  name: string;
  brandEnumString: string;
  productId: string;
  productRatePlans: Array<ProductRatePlan>;
};

export type ProductRatePlan = {
  name: string;
  description: string;
  productRatePlanId: string;
  isTrial: boolean;
  billingPeriodLength: number;
  billingPeriodUnitOfMeasureEnumString: string;
  pricing: Pricing;
  accessFeatures: Array<AccessFeature>;
  duration: number;
  durationUnitOfMeasure: string;
  productRatePlanCharges: Array<ProductRatePlanCharge>;
};

export type ProductRatePlanCharge = {
  name: string;
  currency: string;
  id: string;
  dimension: string;
};

// Common

type Pricing = {
  upFrontPrice: string;
  upFrontTaxAmount: string;
  recurringPrice: string;
  recurringTaxAmount: string;
  currency: string;
};

type AlignmentDate = 'RatePlanStartDate' | 'SubscriptionStartDate' | 'TermStartDate';

export type SubscriptionRatePlan = {
  accessFeatures: string[];
  id: string;
  isTrial?: boolean;
  productName: string;
  ratePlanCharges: SubscriptionRatePlanChargeResponse[];
  ratePlanName: string;
  ratePlanStartDate: string;
  ratePlanEndDate: string;
  ratePlanType: string;
  status: string;
  latestChargedThroughDate: string;
  campaignReference: string;
  invoicedUntil: string;
  paymentFrequencyUnit: string;
  paymentFrequencyNumberOfUnits: number;
  accessFeaturesWithWeekdayMask?: AccessFeature[];
  alignmentDates: AlignmentDate[];
};

type SubscriptionRatePlanChargeResponse = {
  billingDay: string; // TODO check if used!
  billingPeriod: string;
  chargedThroughDate: string;
  currency: string;
  description: string;
  effectiveEndDate: string;
  effectiveStartDate: string;
  endDateCondition: string;
  id: string;
  name: string;
  price?: number;
  type: string;
  accessFeatureC: string;
  accessFeature__c: string;
  hasPrintAccessFeature: boolean;
  discountAmount?: number;
  dimensionC: string;
  originalChargeId: string;
  weekDayMaskC: string;
};
