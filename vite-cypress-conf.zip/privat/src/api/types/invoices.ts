import { PaymentMethodType, PaymentStatus } from './accounts';
import { DkAddress, ForeignAddress } from './contact';

export type InvoicePayment = {
  accountId: string;
  id: string;
  paymentNumber: string;
  paymentMethodId: string;
  invoiceId: string;
  amount: number;
  status: PaymentStatus;
  createdDate: Date;
  effectiveDate: Date;
};

export const DeliveryMethodText = {
  Unknown: 'Ukendt',
  EAN: 'EAN',
  PaymentSlip: 'Indbetalingskort',
  PBS: 'Betalingsservice',
  Email: 'PDF-faktura',
  MobilePay: 'MobilePay',
};

export const SentToEdiExText = {
  Sent: 'Sendt',
  NotSent: 'Ikke sendt',
  Skipped: 'Afsendelse annulleret',
  Error: 'Fejl',
};

export const DunningStatusText = {
  NotInDunning: 'Ikke i RVS',
  InitialPaymentReminder: '1. betalingspåmindelse',
  SecondPaymentReminder: '2. betalingspåmindelse',
  SuspensionInvoice: 'Abonnement lukket',
};

export type DeliveryMethod = keyof typeof DeliveryMethodText;
export type SentToEdiEx = keyof typeof SentToEdiExText;
export type DunningStatus = keyof typeof DunningStatusText;
export type InvoiceType =
  | 'Default'
  | 'Compensation'
  | 'Cancellation'
  | 'WriteOff'
  | 'MobilePayUpfrontCaptured'
  | 'MigrationAccountBalanceCorrection';

// TODO consider a v5 Saapi endpoint that streamlines the Invoice models so that shared fields are named consistently (id/invoiceId, amount/invoiceAmount etc.)
export type InvoiceOverviewItem = {
  id: string;
  amount: number;
  balance: number;
  currency: string;
  deliveryMethod: DeliveryMethod;
  dunningRelatedInvoiceNumber: string;
  dunningStatus: DunningStatus;
  invoiceDate: Date;
  invoiceDueDate: Date;
  invoiceNumber: string;
  invoiceType: InvoiceType;
  paymentMethod: PaymentMethodType;
  sentToEdiExStatus: SentToEdiEx;
  subscriptions: string[];
  status: { name: string };
};

export type InvoicesResponse = {
  invoices: InvoiceOverviewItem[];
  hasNextPage: boolean;
};

export type EdiExInvoice = {
  invoiceNumber: string;
  invoiceUuid: string;
  deliveredToDistributorDate: Date;
  deliveryMethod: DeliveryMethod;
  deliveryEmail: string;
};

export type InvoiceItem = {
  chargeAmount: number;
  chargeId: string;
  chargeName: string;
  chargeDescription: string;
  id: string;
  productName: string;
  quantity: string;
  serviceEndDate: Date;
  serviceStartDate: Date;
  subscriptionId: string;
  subscriptionName: string;
  taxAmount: number;
};

type BillToContact = {
  address1: string;
  address2: string;
  city: string;
  country: string;
  firstName: string;
  lastName: string;
  personalEmail: string;
  taxRegion: string;
  zipCode: string;
  CountryCode__c: string;
  Addresspoint__c: string;
  Sextype__c: string;
};

export type Invoice = {
  deliveryMethod: DeliveryMethod;
  sentToEdiExStatus: SentToEdiEx;
  dunningStatus: DunningStatus;
  dunningRelatedInvoiceNumber: string;
  invoiceId: string;
  invoiceNumber: string;
  invoiceDate: Date;
  dueDate: Date;
  invoiceBody: string;
  invoiceAmount: number;
  invoiceTaxAmount: number;
  invoiceTaxAmountWithoutTax: number;
  invoiceTaxExemptAmount: number;
  invoiceBalance: number;
  invoiceRefundAmount: number;
  invoiceTypeC: InvoiceType;
  invoiceStatus: PaymentStatus;
  invoiceItems: InvoiceItem[];
  billToContact: BillToContact;
  accountNumber: string;
  accountName: string;
  accountId: string;
  creditBalanceAdjustmentAmount: number;
  currency: string;
};

// type InvoiceResendMethod = 'EmailZuora' | 'EAN' | 'EmailPDF' | 'PaymentSlip' | 'MobilePay';
const InvoiceResendMethod = {
  EmailZuora: 'EmailZuora',
  EAN: 'EAN',
  EmailPDF: 'EmailPDF',
  PaymentSlip: 'PaymentSlip',
  MobilePay: 'MobilePay',
};

// TODO: Rename to InvoiceResendMethod / Option?
/// -> InvoiceResendMethod => InvoiceResendMethodType
export type InvoiceResendMethodResponse = {
  method: keyof typeof InvoiceResendMethod;
  EANNumber?: string;
  email?: string;
  address?: DebtorAddress;
};

export type ResendInvoiceMutation = {
  invoiceId: string;
  resendMethod: string;
};

export type ApplyCreditOnInvoiceMutation = {
  accountNumber: string;
  invoiceId: string;
  amount: number;
};

export type DunningRelatedInvoice = {
  invoiceNumber: string;
  reminderTypeEnum: string;
  invoiceDate: Date;
  id: string;
  dueDate: Date;
  amount: null;
  balance: number;
  extendedDueDaysForDisplay__c: number;
  invoiceType__c: string;
};

export type ZuoraInvoiceItemAdjustment = {
  accountId: string;
  accountingCode: string;
  adjustmentDate?: Date;
  adjustmentNumber: string;
  amount?: number;
  cancelledDate?: Date;
  comment: string;
  createdDate?: Date;
  customerName: string;
  customerNumber: string;
  id: string;
  invoiceId: string;
  reasonCode: string;
  referenceId: string;
  sourceId: string;
  sourceType: string;
  status: 'Canceled' | 'Processed';
  type: string;
};

//TODO: TODO: Codesmell... it feels wrong to define Address in invoice. Perhaps root cause is having several address formats?
export type DebtorAddress = {
  dkAddress?: DkAddress;
  foreignAddress?: ForeignAddress;
};
