export type CompensationRatePlan = {
  id: string;
  ratePlanStartDate: string;
  ratePlanCharges: CompensationRatePlanCharge[];
};

type CompensationRatePlanCharge = {
  description: string;
  price: number;
  currency: string;
};
