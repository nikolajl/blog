export type PaymentMethodCreditCard = {
  paymentMethodId?: string;
  addressLine1?: string;
  addressLine2?: string;
  zipCode?: string;
  city?: string;
  country?: string;
  phone?: string;
  email?: string;
  expirationMonth: number;
  expirationYear: number;
  creditCardHolderName: string;
  cardNumber: string;
  cardType: string;
};

export type Account = {
  ssoId: string;
  accountNumber: string;
  accountType: string;
  id: string;
  parentId?: string;
  name: string;
  email: string;
  phone1?: string;
  phone2?: string;
  paymentMethodCreatedDate?: Date;
  firstName: string;
  lastName: string;
  status: string;
  balance: number;
  paymentMethodName: string;
  paymentTermName: string;
  paymentMethodCreditCard: PaymentMethodCreditCard;
  paymentMethodMobilePay?: string;
  fullAddress: string;
  cvr?: string;
  compstringName?: string;
  coName?: string;
  gracePeriod?: string;
  eanNumber?: string;
  vatNr?: string;
  invoiceBalance: number;
  creditBalance: number;
  countryCode: string;
  consolidatedInvoice: boolean;
  surchargeExemption: SurchargeExemption;
};

export type SurchargeExemption = 'Never' | 'NextInvoice' | 'Always';

export const SurchargeExemptionText = {
  Never: 'Aldrig fritaget',
  NextInvoice: 'Fritaget på næste faktura',
  Always: 'Altid fritaget',
};

// TODO: Should this be account/payments? (AccountPaymentsApiController?)
export type PaymentsOverview = {
  payments: Payment[];
  paymentMethods: PaymentMethod[];
  hasNextPage: boolean;
};

export type Payment = {
  id: number;
  effectiveDate: Date;
  amountAsDecimal: number;
  paymentNumber: string;
  paidInvoices: PaidInvoice[];
  paymentMethodID: string;
  status: PaymentStatus;
  mpPaymentStatus?: string;
};

export type PaymentMethod = {
  id: number;
  creditCard?: CreditCard;
  paymentMethodType: PaymentMethodType;
};

type CreditCard = {
  cardType: string;
};

type PaidInvoice = {
  invoiceId: string;
  invoiceNumber: string;
};

export const PaymentStatusText = {
  Draft: 'Kladde',
  Processing: 'Gennemføres',
  Processed: 'Gennemført',
  Error: 'Fejl',
  Voided: 'Anulleret af forretningen',
  Canceled: 'Annulleret af kunden',
  Posted: 'Sendt',
};

export type PaymentStatus = keyof typeof PaymentStatusText;

export type PaymentMethodType =
  | 'CreditCard'
  | 'MobilePay'
  | 'Nothing'
  | 'PBS'
  | 'IndB'
  | 'EAN'
  | 'BankTransfer';

export type GracePeriodMutation = {
  accountId: string;
  gracePeriod?: Date;
};

export type SurchargeExemptionMutation = {
  accountId: string;
  surchargeExemption?: SurchargeExemption;
};
