export type DistributionAddress = {
  countryCode: string;
  zipCode: string;
  postalDistrict: string;
  street: string;
  houseNumber?: number;
  houseLetter: string;
  distributorCode: string;
  masterAddressPointID: number;
  masterServiceID: number;
  boxJobNumber?: number;
  label: string;
  latitude?: number;
  longitude?: number;
  popularName: string;
  distributionForm: string;
  distributorPriority?: number;
  weekdayMask: string;
  publicationCode: string;
};

export type DistributionCountry = {
  isoCodeA2: string;
  isoCodeA3: string;
  masterId: number;
  nameDk: string;
  nameEn: string;
};

export type AfloCode = {
  code: string;
  text: string;
  userFreeText: string;
  affectPayment: string;
  description: string;
};
