type RefundSourceType = 'Payment' | 'CreditBalance';
export type RefundChannelType = 'CreditCard' | 'BankTransfer';
type PaymentType = 'External' | 'Electronic';
type RefundOrderStatus = 'Created' | 'Accepted' | 'Rejected' | 'Paid';
type CreditCardType = 'Visa' | 'MasterCard' | 'AmericanExpress' | 'Discover' | 'JCB' | 'Diners';

export type InvoicePayment = {
  paymentNumber: string;
  paymentId: string;
  invoiceNumber: string;
  invoiceId: string;
  paymentType: PaymentType;
  paymentEffectiveDate: Date;
  amount: number;
  refundedAmount: number;
  refundableAmount: number;
};

export type InvoicePaymentView = InvoicePayment & {
  isSelected?: boolean;
  refunds?: RefundOrder[];
};

export type CreateRefundOrder = {
  comment?: string;
  noteToCustomer?: string;
  paymentNumber?: string;
  paymentId?: string;
  invoiceNumber?: string;
  invoiceId?: string;
  refundChannel: RefundChannelType;
  electronicPaymentMethodId?: string | null;
  regNr?: string;
  kontoNr?: string;
  amount: number | null;
  sourceType: RefundSourceType;
  refundFullAmount?: boolean;
  effectiveDate: Date | null;
};

export type CreateRefundOrders = {
  accountNumber: string;
  accountId: string;
  refundOrders: CreateRefundOrder[];
};

export type RefundOrder = {
  id: string;
  comment?: string;
  noteToCustomer?: string;
  createdBy: string;
  creationDate: Date;
  handledBy: string;
  updateDate?: Date;
  refundNumber: string;
  refundId: string;
  status: RefundOrderStatus;
  accountNumber: string;
  accountId: string;
  sourceType: RefundSourceType;
  paymentNumber: string;
  paymentId: string;
  invoiceNumber: string;
  invoiceId: string;
  refundChannel: RefundChannelType;
  electronicPaymentMethodId: string;
  regNr: string;
  kontoNr: string;
  amount: number;
  amountRefunded?: number;
  refundFullAmount?: boolean;
  effectiveDate: Date | null;
};

export type RefundOrderDetails = RefundOrder & {
  paymentMethodCreditCardType: CreditCardType;
  paymentMethodCreditCardNumberMask: string;
  paymentMethodCreditCardExpirationMonth: string;
  paymentMethodCreditCardExpirationYear: string;
  accountBillToContactLabel01: string;
  accountBillToContactLabel02: string;
  accountBillToContactLabel03: string;
  accountBillToContactLabel04: string;
  accountBillToContactLabel05: string;
  accountBillToContactLabel06: string;
  accountBillToContactLabel07: string;
  accountBillToContactLabel08: string;
};

export type RefundOrderResponse = {
  refundOrders: RefundOrder[];
  totalCount: number;
};

export type UpdateRefundOrder = {
  refundOrderId: string;
};
