export type Discount = {
  amount: number;
  fromDate: Date;
  consecutive: boolean;
  toDate?: Date;
};
