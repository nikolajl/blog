import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useToastProvider } from '@/components/messages/ToastProvider';
import { axiosClient } from '@/utils/axiosClient';
import {
  CreateRefundOrders,
  InvoicePayment,
  RefundOrder,
  RefundOrderDetails,
  RefundOrderResponse,
  UpdateRefundOrder,
} from './types/refunds';

const fetchRefundInvoicePayments = (
  accountId?: string,
  params?: { fromDate: Date | null; toDate: Date | null }
) =>
  axiosClient
    .get<InvoicePayment[]>(`/api/refund/invoicepayments/${accountId}`, { params })
    .then(({ data }) => data);

const fetchRefundOrdersByAccountNumber = (accountNumber: string, orderStatus?: string) => {
  return axiosClient
    .get<RefundOrder[]>(`/api/refund/refundOrders/accounts/${accountNumber}`, {
      params: {
        orderStatus,
      },
    })
    .then(({ data }) => data);
};

const fetchRefundOrders = (
  pageNumber: number,
  pageSize: number,
  orderStatus: string,
  fromDate?: Date,
  toDate?: Date
) => {
  return axiosClient
    .get<RefundOrderResponse>('/api/refund/refundOrders', {
      params: {
        pageNumber,
        pageSize,
        orderStatus,
        fromDate,
        toDate,
      },
    })
    .then(({ data }) => data);
};

const fetchRefundOrderDetails = (orderId: string) => {
  return axiosClient
    .get<RefundOrderDetails>(`/api/refund/refundOrders/${orderId}`)
    .then(({ data }) => data);
};

const createRefundOrders = (refund: CreateRefundOrders) =>
  axiosClient.post('/api/refund/refundOrders', refund);

const rejectRefundOrder = (rejectRefundRequest: UpdateRefundOrder) =>
  axiosClient.patch(`/api/refund/refundOrders/${rejectRefundRequest.refundOrderId}/reject`);

const acceptRefundOrder = (acceptRefundRequest: UpdateRefundOrder) =>
  axiosClient.patch(`/api/refund/refundOrders/${acceptRefundRequest.refundOrderId}/accept`);

// Exported hooks:
export const useRefundInvoicePayments = (
  accountId?: string,
  options?: { fromDate: Date | null; toDate: Date | null }
) =>
  useQuery(
    ['refund-invoice-payments', accountId, options],
    async () => await fetchRefundInvoicePayments(accountId, options),
    {
      enabled: !!accountId,
    }
  );

export const useRefundOrdersByAccount = (
  accountNumber: string,
  options?: { orderStatus: string }
) =>
  useQuery(
    ['refund-refundOrdersByAccount', accountNumber, options],
    async () => await fetchRefundOrdersByAccountNumber(accountNumber, options?.orderStatus)
  );

export const useRefundOrders = (
  pageNumber: number,
  pageSize: number,
  orderStatus: string,
  fromDate?: Date,
  toDate?: Date
) =>
  useQuery(
    ['refund-refundOrders', pageNumber, orderStatus, pageSize, fromDate, toDate],
    async () => await fetchRefundOrders(pageNumber, pageSize, orderStatus, fromDate, toDate)
  );

export const useRefundOrderDetails = (orderId: string) =>
  useQuery(
    ['refund-refundOrderDetails', orderId],
    async () => await fetchRefundOrderDetails(orderId)
  );

export const useCreateRefundOrder = () => {
  const client = useQueryClient();
  const { showSuccess } = useToastProvider();
  return useMutation(['createRefundOrder'], createRefundOrders, {
    onSuccess() {
      showSuccess('Udbetaling oprettet', '', 3000);
      client.invalidateQueries(['refund-payments']);
      client.invalidateQueries(['refund-refundOrders']);
      client.invalidateQueries(['refund-refundOrdersByAccount']);
    },
  });
};

export const useRejectRefundOrder = () => {
  const client = useQueryClient();
  const { showSuccess } = useToastProvider();
  return useMutation(['rejectRefundOrder'], rejectRefundOrder, {
    onSuccess: () => {
      showSuccess('Ordren blev afvist');
      client.invalidateQueries(['refund-payments']);
      client.invalidateQueries(['refund-refundOrders']);
    },
  });
};

export const useAcceptRefundOrder = () => {
  const { showSuccess } = useToastProvider();
  const client = useQueryClient();
  return useMutation(['acceptRefundOrder'], acceptRefundOrder, {
    onSuccess: () => {
      showSuccess('Ordren blev godkendt');
      client.invalidateQueries(['refund-payments']);
      client.invalidateQueries(['refund-refundOrders']);
    },
  });
};
