import { axiosClient } from '@/utils/axiosClient';
import { useQuery } from '@tanstack/react-query';
import { AfloCode, DistributionAddress, DistributionCountry } from './types/distribution';

// TODO: API: /api/distribution/address/search
export const fetchLookUpAddress = (streetName?: string, zipCode?: string, countryCode = 'DK') =>
  axiosClient
    .get<DistributionAddress[]>('/Distribution/LookUpAddress', {
      params: {
        streetName,
        zipCode,
        countryCode,
      },
    })
    .then(({ data }) => data);

// TODO: API: /api/distribution/countries
const fetchCountries = () =>
  axiosClient
    .get<DistributionCountry[]>('/Distribution/GetCountries')
    .then(({ data }) => data.filter((c) => c.nameDk !== 'Danmark'));

// TODO: API: /api/distribution/next-delivery-date
const fetchNextDeliveryDate = () =>
  axiosClient.get<Date>('/api/next-valid-delivery-date').then(({ data }) => new Date(data));

const fetchAfloCodes = () =>
  axiosClient.get<AfloCode[]>('/distribution/aflo-codes').then(({ data }) => data);
export const useLookupAddress = (streetName?: string, zipCode?: string, countryCode = 'DK') =>
  useQuery(['distribution-lookup-address', streetName, zipCode, countryCode], () =>
    fetchLookUpAddress(streetName, zipCode, countryCode)
  );

export const useGetCountries = () => useQuery(['distribution-get-countries'], fetchCountries);

export const useNextDeliveryDate = () =>
  useQuery(['next-delivery-address'], () => fetchNextDeliveryDate());

export const useGetAfloCodes = () =>
  useQuery(['distribution-get-aflocodes'], () => fetchAfloCodes());
