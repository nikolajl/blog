import { axiosClient } from '@/utils/axiosClient';
import { useQuery } from '@tanstack/react-query';

export type Subscription = {
  id: string;
  status: string;
};

const fetchSubscription = (subscriptionNumber: string) =>
  axiosClient
    .get<Subscription>(`/api/v2/subscriptions/${subscriptionNumber}`)
    .then(({ data }) => data);

export const useSubscription = (subscriptionNumber: string) =>
  useQuery(['subscription', subscriptionNumber], () => fetchSubscription(subscriptionNumber));
