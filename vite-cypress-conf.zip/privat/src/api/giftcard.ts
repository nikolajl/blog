import { axiosClient } from '@/utils/axiosClient';
import { useQuery } from '@tanstack/react-query';
import { GiftCard } from './types/giftcard';

const fetchGiftCard = (giftCardCode: string) =>
  axiosClient.get<GiftCard>(`/api/giftcard/${giftCardCode}`).then(({ data }) => data);

export const useGetGiftCard = (giftCardCode: string) =>
  useQuery(['giftcard', giftCardCode], () => fetchGiftCard(giftCardCode), {
    enabled: !!giftCardCode,
  });
