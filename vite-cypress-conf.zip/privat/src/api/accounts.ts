import { axiosClient } from '@/utils/axiosClient';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Account,
  GracePeriodMutation,
  PaymentsOverview,
  SurchargeExemptionMutation,
} from './types/accounts';
import { useToastProvider } from '@/components/messages/ToastProvider';
import { Contact } from './types/contact';
import { AccountV2 } from './types/accountsV2';

// TODO: Deprecate this.
const fetchAccount = (accountKey: string) =>
  axiosClient.get<Account>(`/api/accounts/${accountKey}`).then(({ data }) => data);

// TODO: Deprecate this.
export const useAccount = (accountKey: string) =>
  useQuery(['account'], () => fetchAccount(accountKey));

const fetchContactInfoV2 = (accountNumber: string, parentId?: string) => {
  const path = parentId
    ? `/api/v2/accounts/${accountNumber}/contactInfo?parentId=${parentId}`
    : `/api/v2/accounts/${accountNumber}/contactInfo`;
  return axiosClient.get(path).then(({ data }) => data);
};

export const useGetContactInfoV2 = (
  accountLoaded = false,
  accountNumber: string,
  parentId?: string
) => {
  console.log('useGetContactInfoV2', accountNumber, parentId);
  return useQuery(
    ['contactInfo', accountNumber],
    () => fetchContactInfoV2(accountNumber, parentId),
    {
      enabled: !!accountLoaded,
    }
  );
};

const fetchAccountV2 = (accountKey?: string) =>
  axiosClient.get<AccountV2>(`/api/v2/accounts/${accountKey}`).then(({ data }) => data);

export const useGetAccountV2 = (accountKey?: string) =>
  useQuery(['account', accountKey], () => fetchAccountV2(accountKey), {
    enabled: !!accountKey,
  });

const fetchAccountPayments = (accountNumber: string, pageSize: number, pageNumber: number) =>
  axiosClient
    .get<PaymentsOverview>(
      `/api/v2/accounts/${accountNumber}/paymentsoverview?pageSize=${pageSize}&pageNumber=${pageNumber}`
    )
    .then(({ data }) => data);

export const useAccountPayments = (accountNumber: string, pageSize = 20, pageNumber = 1) =>
  useQuery(['accountPayments', accountNumber, pageSize, pageNumber], () =>
    fetchAccountPayments(accountNumber, pageSize, pageNumber)
  );

const updateSurchargeExemption = ({ accountId, surchargeExemption }: SurchargeExemptionMutation) =>
  axiosClient.put(
    `/api/accounts/${accountId}/setSurchargeExemption?surchargeExemption=${surchargeExemption}`
  );

export const useUpdateSurchargeExemption = () => {
  const { showSuccess, showError } = useToastProvider();
  const client = useQueryClient();
  return useMutation(updateSurchargeExemption, {
    onSuccess() {
      client.invalidateQueries(['account']);
      showSuccess('Fritagelse gemt');
    },
    onError() {
      showError('Ændring af fritagelse fejlede');
    },
  });
};

const updateGracePeriod = ({ accountId, gracePeriod }: GracePeriodMutation) =>
  axiosClient.put(`/Customer/UpdateGracePeriod`, {
    accountId,
    gracePeriod,
  });

export const useUpdateGracePeriod = () => {
  const { showSuccess, showError } = useToastProvider();
  const client = useQueryClient();

  return useMutation(updateGracePeriod, {
    onSuccess() {
      // TODO: We could refine the account cache by using accountKey/id.
      client.invalidateQueries(['account']);
      showSuccess('Ændring af aftalt betalingsperiode fuldført!');
    },
    onError() {
      showError('Der må max vælges 35 dage ud i fremtiden og tidligst dagsdato');
    },
  });
};

// TODO: Update API controller
// TODO: What's the deal with parentId?
const fetchBillingAddress = (accountNumber: string) =>
  axiosClient
    .get<Contact>(`/api/accounts/contactInfo/${accountNumber}?parentId=`)
    .then(({ data }) => data);

export const useGetBillingAddress = (accountNumber: string) =>
  useQuery(['billing-address', accountNumber], () => fetchBillingAddress(accountNumber));
