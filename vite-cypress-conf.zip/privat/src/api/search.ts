import { axiosClient } from '@/utils/axiosClient';
import { useQuery } from '@tanstack/react-query';

type Recent = {
  displayName: string;
  email: string;
  loadedAt: string;
  name: string;
  ssoId: string;
};

const fetchRecent = () => axiosClient.get<Recent[]>('/api/search/recent').then(({ data }) => data);

export const useRecent = () => useQuery(['search-recent'], fetchRecent);

type SearchResult = {
  companyName: string;
  dataSource: string;
  email: string;
  identType: string;
  name: string;
  ssoId: string;
  zuoraAccountNumber: string;
  zuoraSubscriptionNumber: string;
};

const fetchSearch = (input: string) =>
  axiosClient
    .get<SearchResult[]>('/api/search', {
      params: {
        input,
      },
    })
    .then(({ data }) => data);

export const useSearch = (input: string) =>
  useQuery(['search', input], async () => await fetchSearch(input));
