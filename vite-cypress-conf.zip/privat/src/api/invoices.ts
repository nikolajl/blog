import { axiosClient } from '@/utils/axiosClient';
import { useInfiniteQuery, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useToastProvider } from '@/components/messages/ToastProvider';
import {
  ApplyCreditOnInvoiceMutation,
  DunningRelatedInvoice,
  EdiExInvoice,
  Invoice,
  InvoicePayment,
  InvoiceResendMethodResponse,
  InvoicesResponse,
  ResendInvoiceMutation,
  ZuoraInvoiceItemAdjustment,
} from './types/invoices';

// TODO: Move to accounts api ?
const getInvoices = (accountNumber: string, page = '1') =>
  axiosClient.get<InvoicesResponse>(`/api/invoices/${accountNumber}/${page}`).then(({ data }) => {
    return {
      nextPage: (parseInt(page) + 1).toString(),
      invoices: data.invoices,
      hasNext: data.hasNextPage,
    };
  });

export const useGetInvoices = (accountNumber: string) =>
  useInfiniteQuery({
    queryKey: ['invoices', accountNumber],
    queryFn: ({ pageParam }) => {
      return getInvoices(accountNumber, pageParam?.nextPage);
    },
    getNextPageParam: (lastPage) => {
      return lastPage.hasNext ? lastPage : undefined;
    },
  });

const getEdiExInvoices = (invoiceId: string) =>
  axiosClient.get<EdiExInvoice[]>(`/api/v2/invoices/${invoiceId}/ediex`).then(({ data }) => data);

export const useGetEdiExInvoices = (invoiceId: string) =>
  useQuery(['ediexinvoices', invoiceId], () => getEdiExInvoices(invoiceId));

export const getInvoice = (invoiceId: string) =>
  axiosClient.get<Invoice>(`/api/v2/invoices/${invoiceId}`).then(({ data }) => data);

export const useGetInvoice = (invoiceId: string) =>
  useQuery(['invoice', invoiceId], () => getInvoice(invoiceId));

export const getInvoicePayments = (invoiceId: string) =>
  axiosClient
    .get<InvoicePayment[]>(`/api/v2/invoices/${invoiceId}/payments`)
    .then(({ data }) => data);

export const useGetInvoicePayments = (invoiceId: string) =>
  useQuery(['invoice-payments', invoiceId], () => getInvoicePayments(invoiceId));

// TODO: Move to accounts api ?
const fetchResendMethods = (accountNumber: string) =>
  axiosClient
    .get<InvoiceResendMethodResponse[]>(`/api/invoices/${accountNumber}/resendMethods`)
    .then(({ data }) => data);

export const useGetResendMethods = (accountNumber: string) =>
  useQuery(['resend-methods', accountNumber], () => fetchResendMethods(accountNumber), {
    enabled: !!accountNumber,
  });

const postResendInvoice = ({ invoiceId, resendMethod }: ResendInvoiceMutation) =>
  axiosClient.post(`/api/v2/invoices/${invoiceId}/resend`, null, {
    params: {
      resendMethod,
    },
  });

export const usePostResendInvoice = () => {
  const { showSuccess } = useToastProvider();

  return useMutation(postResendInvoice, {
    onSuccess() {
      showSuccess('Fakturaen blev sat til genudsendelse!');
    },
  });
};

const applyCreditOnInvoice = ({ invoiceId, amount }: ApplyCreditOnInvoiceMutation) =>
  axiosClient.post(`/api/v2/invoices/${invoiceId}/applycreditbalance`, {
    amount,
  });

export const useApplyCreditOnInvoice = () => {
  const { showSuccess, showError } = useToastProvider();
  const client = useQueryClient();

  return useMutation(applyCreditOnInvoice, {
    onSuccess(_, { invoiceId }) {
      client.invalidateQueries(['invoice', invoiceId]);
      showSuccess('Tilgodehavende er blevet påført faktura!');
    },
    onError() {
      showError(
        'Noget gik galt med påførsel af tilgodehavende. - Kontakt Team.KOT igennem din leder ved kritiske situationer.'
      );
    },
  });
};

const fetchDunningRelatedInvoices = (dunningRelatedInvoiceNumber: string) =>
  axiosClient
    .get<DunningRelatedInvoice[]>('/api/v2/invoices/rvs', {
      params: {
        dunningRelatedInvoiceNumber,
      },
    })
    .then(({ data }) => data);

export const useDunningRelatedInvoices = (dunningRelatedInvoiceNumber: string) =>
  useQuery(['invoice', 'rvs', dunningRelatedInvoiceNumber], () =>
    fetchDunningRelatedInvoices(dunningRelatedInvoiceNumber)
  );

const fetchInvoiceItemAdjustments = (invoiceId: string) =>
  axiosClient
    .get<ZuoraInvoiceItemAdjustment[]>(`/api/v2/invoices/${invoiceId}/adjustments`)
    .then(({ data }) => data);

export const useInvoiceItemAdjustments = (invoiceId: string) =>
  useQuery(['invoice', 'adjustments', invoiceId], () => fetchInvoiceItemAdjustments(invoiceId), {
    enabled: !!invoiceId,
  });
