import { axiosClient } from '@/utils/axiosClient';
import { useQuery } from '@tanstack/react-query';

export type SubscriptionGroup = {
  id: string;
  name: string;
  description: string;
  brand: string;
  createdBy: string;
};

const fetchSubscriptionGroupsByBrand = (brand: string) =>
  axiosClient
    .get<SubscriptionGroup[]>(`/api/subscription-group/brand/${brand}`)
    .then(({ data }) => data);

export const useSubscriptionGroupsByBrand = (brand: string) =>
  useQuery(['subscription-groups-by-brand', brand], () => fetchSubscriptionGroupsByBrand(brand));
