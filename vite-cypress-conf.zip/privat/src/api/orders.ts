import { AxiosError } from 'axios';
import { useMutation, useQuery } from '@tanstack/react-query';
import { useToastProvider } from '@/components/messages/ToastProvider';
import { axiosClient } from '@/utils/axiosClient';
import { PurchaseResponse, SubscriptionOrder } from './types/orders';
import { NewCustomerExportSchemaType } from '@/pages/purchase-subscription/new-customer.schema';

const subscriptionOrderPurchase = (purchase: NewCustomerExportSchemaType) =>
  axiosClient.post<PurchaseResponse>('/api/orders/purchase', purchase);

const fetchSubscriptionOrder = (orderNumber: string) =>
  axiosClient
    .get<SubscriptionOrder>(`/api/subscription-orders/order/${orderNumber}`)
    .then(({ data }) => data);

type PurchaseErrorResponse = {
  Message: string;
  ActivityId: string;
  ErrorCode: number;
};
export const useSubscriptionOrderPurchase = () => {
  const { showError } = useToastProvider();

  return useMutation(subscriptionOrderPurchase, {
    onError(error: AxiosError) {
      showError((error.response?.data as PurchaseErrorResponse)?.Message, error.message); // TODO find a more elegant way to handle this - in backend preferably!
    },
  });
};

export const usePollSubscriptionOrder = (orderNumber: string) =>
  useQuery(['subscription-order'], () => fetchSubscriptionOrder(orderNumber), {
    refetchInterval: (data) => (!data || data.StatusEnumString === 'Committed' ? 2500 : false),
  });
