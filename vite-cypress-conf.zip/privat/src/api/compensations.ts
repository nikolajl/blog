import { useToastProvider } from '@/components/messages/ToastProvider';
import { CompensationSchemaType } from '@/pages/customers/accounts/invoices/components/compensation.schema';
import { axiosClient } from '@/utils/axiosClient';
import { useMutation, useQuery } from '@tanstack/react-query';
import { CompensationRatePlan } from './types/compensations';

const fetchCompensationHistory = (subscriptionNumber: string, accountNumber: string) =>
  axiosClient
    .get<CompensationRatePlan[]>(
      `/api/compensation/history/${subscriptionNumber}?accountNumber=${accountNumber}`
    )
    .then(({ data }) => data);

export const useCompensationHistory = (subscriptionNumber: string, accountNumber: string) =>
  useQuery(['compensation-history', subscriptionNumber, accountNumber], () =>
    fetchCompensationHistory(subscriptionNumber, accountNumber)
  );

const createCompensation = (createCompensationRequest: CompensationSchemaType) =>
  axiosClient.post(`/api/compensation`, createCompensationRequest);

export const useCreateCompensation = () => {
  const { showSuccess } = useToastProvider();

  return useMutation(['createCompensation'], createCompensation, {
    onSuccess() {
      showSuccess('Godtgørelsen blev oprettet');
    },
  });
};
