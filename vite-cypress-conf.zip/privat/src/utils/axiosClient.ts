import axios, { AxiosError } from 'axios';

export const axiosClient = axios.create({
  headers: { 'X-Requested-With': 'Axios' },
});

axiosClient.interceptors.response.use(
  (x) => x,
  (error: AxiosError) => {
    if (401 === error.response?.status) {
      window.location.assign('/login?from=' + window.location.toString());
    }
    return Promise.reject(error);
  }
);
