import { Contact } from '@/api/types/accountsV2';
import { BillingPeriodAlignment } from '@/api/types/catalog';
import format from 'date-fns/format';

export function formatDate(date?: string | Date, formatString = 'dd-MM-yyyy') {
  if (typeof date === 'string') {
    return format(new Date(date), formatString);
  }
  if (date instanceof Date) {
    return format(date, formatString);
  }
  return date;
}

export function formatSosDate(date?: string | Date, formatString = 'yyyy-MM-dd') {
  if (typeof date === 'string') {
    return format(new Date(date), formatString);
  }
  if (date instanceof Date) {
    return format(date, formatString);
  }
  return date;
}

export type FormatCurrencyOptions = {
  currency: string;
};

export function formatCurrency(amount?: number | string, options?: FormatCurrencyOptions) {
  const { currency } = {
    currency: 'kr.',
    ...options,
  };
  if (typeof amount === 'string') {
    return (
      parseFloat(amount)
        .toFixed(2)
        .replace('.', ',')
        .replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ` ${currency}`
    );
  }
  if (typeof amount === 'number') {
    return (
      amount
        ?.toFixed(2)
        .replace('.', ',')
        .replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ` ${currency}`
    );
  }
}

export function formatAlignment(alignment: BillingPeriodAlignment) {
  switch (alignment) {
    case 'AlignToTerm': {
      return 'Abonnement';
    }
    case 'AlignToCharge': {
      return 'Startdato';
    }
    case 'AlignToSubscriptionStart': {
      return 'Abonnement start';
    }
    default: {
      return 'Not Supported';
    }
  }
}

export function formatPaymentFrequency(unit: string, amount = 0) {
  // Day, Week, Month
  if (amount > 1) {
    switch (unit) {
      case 'Specific_Days':
      case 'Day':
        switch (amount) {
          case 7:
            return 'Ugentlig';

          default:
            return `Hver ${amount}. dag`;
        }

      case 'Specific_Weeks':
      case 'Week':
        return `Hver ${amount}. uge`;

      case 'Specific_Months':
      case 'Month':
        switch (amount) {
          case 3:
            return 'Kvartalsvis';

          case 6:
            return 'Halvårlig';

          default:
            return `Hver ${amount}. måned`;
        }

      case 'Quarter':
        switch (amount) {
          case 2:
            return 'Halvårlig';

          case 4:
            return 'Årlig';

          default:
            return `Hver ${amount}. kvartal`;
        }

      case 'Semi_Annual':
        switch (amount) {
          case 2:
            return 'Årlig';

          default:
            return `Hver ${amount}. halve år`;
        }

      case 'Annual':
      case 'Year':
        return `Hver ${amount}. år`;

      default:
        return 'Periode';
    }
  } else {
    switch (unit) {
      case 'Specific_Days':
      case 'Day':
        return 'Daglig';

      case 'Specific_Weeks':
      case 'Week':
        return 'Ugentlig';

      case 'Specific_Months':
      case 'Month':
        return 'Månedlig';

      case 'Quarter':
        return 'Kvartalsvis';

      case 'Semi_Annual':
        return 'Halvårlig';

      case 'Annual':
      case 'Year':
        return 'Årlig';

      case 'Eighteen_Months':
        return 'Hver 18. måned';

      case 'Two_Years':
        return 'Hvert 2. år';

      case 'Three_Years':
        return 'Hvert 3. år';

      case 'Five_Years':
        return 'Hvert 5. år';

      default:
        return 'Ukendt';
    }
  }
}

export function formatPeriodPrice(amount: number, currency: string, unit: string, count = 0) {
  return `${formatCurrency(amount, { currency })} / ${formatPaymentFrequency(unit, count)}`;
}

export function formatFullAddressFromBillToContactV2(billToContact: Contact) {
  const {
    address1,
    address2,
    floorC,
    sideC,
    foreignAddress1C,
    foreignAddress2C,
    foreignAddress3C,
    foreignAddress4C,
    postboxC,
  } = billToContact;
  if (foreignAddress1C) {
    let foreignAddress = foreignAddress1C;
    foreignAddress += `, ${foreignAddress2C}`;
    foreignAddress += `, ${foreignAddress3C}`;
    foreignAddress += `, ${foreignAddress4C}`;
    return foreignAddress;
  }

  if (postboxC) {
    return `Postboks ${postboxC}`;
  }

  let dkAddress = address1 ?? '';
  dkAddress += address2 ? `, ${address2}` : '';
  dkAddress += floorC ? `, ${floorC}.` : '';
  dkAddress += sideC ? ` ${sideC}` : '';
  return dkAddress;
}
