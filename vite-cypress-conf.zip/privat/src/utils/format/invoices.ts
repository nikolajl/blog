import {
  DunningStatusText,
  DunningStatus,
  DeliveryMethod,
  DeliveryMethodText,
  SentToEdiEx,
  SentToEdiExText,
  InvoiceResendMethodResponse,
} from '@/api/types/invoices';
import { formatAddressLine } from './address';

export function formatDunning(dunningStatus: DunningStatus) {
  return DunningStatusText[dunningStatus];
}

// TODO: Maybe this enum type can just be DunningStatus?
export function formatReminderType(reminderType: string) {
  return formatDunning(reminderType as DunningStatus);
}

export function formatDeliveryMethod(deliveryMethod: DeliveryMethod) {
  return DeliveryMethodText[deliveryMethod];
}

export function formatDeliveryStatus(deliveryMethod: DeliveryMethod, sentToEdiEx: SentToEdiEx) {
  if (sentToEdiEx === 'NotSent') {
    return '-';
  }
  if (sentToEdiEx === 'Error' || sentToEdiEx === 'Skipped') {
    return SentToEdiExText[sentToEdiEx];
  }

  if (deliveryMethod !== 'Unknown') {
    return `Sendt via ${DeliveryMethodText[deliveryMethod]}`;
  }

  return 'Sendt (Ukendt metode)';
}

export function formatResendMethod(resendMethod: InvoiceResendMethodResponse) {
  switch (resendMethod.method) {
    case 'EmailZuora':
      return `Faktura: ${resendMethod.email}`;
    case 'EmailPDF':
      return `Indbetalingskort: ${resendMethod.email}`;
    case 'EAN':
      return `EAN: ${resendMethod.EANNumber}`;
    case 'PaymentSlip':
      if (resendMethod.address) {
        return `Indbetalingskort: ${formatAddressLine(resendMethod.address)}`;
      }
      break;
    case 'MobilePay':
      return `MobilePay: Balance opkræves hos kunden senest 3 dage efter genudsendelse`;
  }
  return 'Ukendt';
}
