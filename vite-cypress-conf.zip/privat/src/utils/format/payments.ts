// TODO: Rename this file to account, or make api/payments.ts ?
// TODO: Cleanup displayPaymentStatus in PaymentsOverview.tsx ?
import { PaymentStatus, PaymentStatusText } from '@/api/types/accounts';

export function formatPaymentStatus(paymentStatus: PaymentStatus) {
  return PaymentStatusText[paymentStatus];
}
