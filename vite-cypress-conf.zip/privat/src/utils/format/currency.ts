export type FormatCurrencyOptions = {
  currency?: string;
};

export function formatAmount(amount?: number | string, options?: FormatCurrencyOptions) {
  if (typeof amount === 'string') {
    return (
      parseFloat(amount)
        .toFixed(2)
        .replace('.', ',')
        .replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ` ${formatCurrency(options?.currency)}`
    );
  }
  if (typeof amount === 'number') {
    return (
      amount
        ?.toFixed(2)
        .replace('.', ',')
        .replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ` ${formatCurrency(options?.currency)}`
    );
  }
}

const currencyMap: Record<string, string> = {
  DKK: 'kr.',
  NOK: 'nok.',
  EUR: '€',
};

export function formatCurrency(currency = 'DKK') {
  if (currency in currencyMap) {
    return currencyMap[currency];
  }

  return currency;
}
