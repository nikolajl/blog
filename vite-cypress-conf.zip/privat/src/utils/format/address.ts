import { Contact } from '@/api/types/contact';
import { DebtorAddress } from '@/api/types/invoices';

export function formatAddressLine(address: DebtorAddress) {
  if (address.dkAddress) {
    if (address.dkAddress.mailbox) {
      return `Postboks ${address.dkAddress.mailbox}, ${address.dkAddress.zipCode} ${address.dkAddress.city}`;
    }

    let streetAddress = `${address.dkAddress.streetName} ${address.dkAddress.houseNumber}${
      address.dkAddress.houseLetter ? address.dkAddress.houseLetter : ''
    }`;

    const floorSide = [address.dkAddress.houseFloor, address.dkAddress.houseSide]
      .filter((x) => x)
      .join('. ');
    if (floorSide) {
      streetAddress += `, ${floorSide}`;
    }

    return (
      `${streetAddress}, ${address.dkAddress.zipCode} ${address.dkAddress.city}` +
      (address.dkAddress.internalLocation ? ` (${address.dkAddress.internalLocation})` : '')
    );
  }

  if (address.foreignAddress) {
    const streetAddress = [
      address.foreignAddress.addressLine1 ?? '',
      address.foreignAddress.addressLine2 ?? '',
      address.foreignAddress.addressLine3 ?? '',
      address.foreignAddress.addressLine4 ?? '',
    ]
      .filter((x) => x)
      .join(' ');
    return (
      `${streetAddress}` +
      (address.foreignAddress.internalLocation
        ? ` (${address.foreignAddress.internalLocation})`
        : '')
    );
  }
}

export function formatDkStreetAddress(address: Contact) {
  if (address.dkAddress) {
    if (address.dkAddress.mailbox) {
      return `Postboks ${address.dkAddress.mailbox}, ${address.dkAddress.zipCode} ${address.dkAddress.city}`;
    }

    let streetAddress = `${address.dkAddress.streetName} ${address.dkAddress.houseNumber}${
      address.dkAddress.houseLetter ? address.dkAddress.houseLetter : ''
    }`;

    const floorSide = [address.dkAddress.houseFloor, address.dkAddress.houseSide]
      .filter((x) => x)
      .join('. ');
    if (floorSide) {
      streetAddress += `, ${floorSide}`;
    }

    return streetAddress;
  }
}
