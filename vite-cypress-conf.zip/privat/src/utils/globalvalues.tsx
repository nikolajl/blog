export const paymentMethods = [
  { value: 'EANConsolidated', label: 'Samlefaktura (EAN)' },
  { value: 'BankTransferConsolidated', label: 'Samlefaktura (Bankoverførsel)' },
  { value: 'PaymentSlipConsolidated', label: 'Samlefaktura (Indbetalingskort)' },
  { value: 'MobilePay', label: 'MobilePay' },
  { value: 'EAN', label: 'EAN' },
  { value: 'BankTransfer', label: 'Bankoverførsel' },
  { value: 'PaymentSlip', label: 'Indbetalingskort (standard)' },
  { value: 'NoPayment', label: 'Ingen betalingsmetode', disabled: true, hidden: true },
  { value: 'Betalingsservice', label: 'Betalingsservice', disabled: true },
  { value: 'NewPaymentMethod', label: 'Kreditkort' },
];
