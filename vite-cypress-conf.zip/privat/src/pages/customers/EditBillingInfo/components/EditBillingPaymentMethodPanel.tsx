import InputRadioGroup from '@/components/forms/InputRadioGroup';
import Panel from '@/components/ui/Panel';
import { paymentMethods } from '@/utils/globalvalues';

export default function EditBillingPaymentMethodPanel() {
  const options = paymentMethods.map((x) => ({
    ...x,
    hidden: false,
    disabled: x.value === 'NewPaymentMethod' ? true : x.disabled,
  }));

  return (
    <Panel title="Betalingsmetode">
      <InputRadioGroup name="paymentMethodType" options={options} />
    </Panel>
  );
}
