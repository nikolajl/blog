import Panel from '@/components/ui/Panel';
import { Form } from 'react-bootstrap';
import { useFormContext } from 'react-hook-form';

export default function SeparateInvoicingCheckbox() {
  const form = useFormContext();
  const [invoiceSubscriptionsSeparately] = form.watch(['invoiceSubscriptionsSeparately']);

  return (
    <Panel title="Fakturering">
      <Form.Check
        type="checkbox"
        checked={invoiceSubscriptionsSeparately}
        id="separately-invoice"
        label="Tving selvstændig fakturering"
        {...form.register('invoiceSubscriptionsSeparately')}
      />
    </Panel>
  );
}
