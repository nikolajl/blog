import { useGetAccountV2, useGetContactInfoV2 } from '@/api/accounts';
import PageLayout from '@/components/layouts/PageLayout';
import { MakeGenerics, useMatch } from '@tanstack/react-location';

type RouteProps = MakeGenerics<{
  Params: {
    accountNumber: string;
    ssoId: string;
  };
}>;

export default function EditSoldToPage() {
  const { params } = useMatch<RouteProps>();

  const { data: accountData } = useGetAccountV2(params.accountNumber);
  const { data, isLoading } = useGetContactInfoV2(
    !!accountData,
    params.accountNumber,
    accountData?.basicInfo?.id
  );
  console.log('params:', params);
  console.log('contact info', data);
  return (
    <PageLayout title="Ret Modtageroplysninger">
      <div>{isLoading ? 'Loading' : 'Done'}</div>
    </PageLayout>
  );
}
