import * as yup from 'yup';
import { setLocale } from 'yup';

setLocale({
  mixed: {
    required: '',
  },
});

export const EditContactInfoSchema = yup.object({
  paymentMethodType: yup.string(),
  invoiceSubscriptionsSeparately: yup.boolean(),
});
export type EditContactInfoSchemaType = yup.InferType<typeof EditContactInfoSchema>;
