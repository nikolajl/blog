import { useGetAccountV2, useGetContactInfoV2 } from '@/api/accounts';
import PageLayout from '@/components/layouts/PageLayout';
import Panel from '@/components/ui/Panel';
import { yupResolver } from '@hookform/resolvers/yup';
import { MakeGenerics, useMatch } from '@tanstack/react-location';
import { Col, Form, Row } from 'react-bootstrap';
import { FormProvider, useForm } from 'react-hook-form';
import PaymentMethodPanel from './components/EditBillingPaymentMethodPanel';
import SeparateInvoicingCheckbox from './components/SeparateInvoicingCheckbox';
import { EditContactInfoSchema, EditContactInfoSchemaType } from './editcontactinfo.schema';

type RouteProps = MakeGenerics<{
  Params: {
    accountNumber: string;
    ssoId: string;
  };
}>;
export default function EditSoldToPage() {
  const { params } = useMatch<RouteProps>();
  const form = useForm<EditContactInfoSchemaType>({
    resolver: yupResolver(EditContactInfoSchema),
    mode: 'onChange',
    defaultValues: {
      invoiceSubscriptionsSeparately: false,
      paymentMethodType: 'EAN', // TODO: Replace with account paymentMethod to show as selected, probably cant use defaultValues for this. (so just set value after fetching data, and remove default)
    },
  });

  const { data: accountData } = useGetAccountV2(params.accountNumber);
  const { data, isLoading } = useGetContactInfoV2(!!accountData, params.accountNumber);

  console.log('billTo', data, isLoading);

  const onSubmit = () => console.log('submitted');

  console.log('Form::', form.getValues());
  return (
    <PageLayout title="Ret betalingsoplysninger">
      <FormProvider {...form}>
        <Form onSubmit={form.handleSubmit(onSubmit, (e) => console.log('form invalid', e))}>
          <Row>
            <Col className="col-7">
              <Panel title="Betaleradresse"></Panel>
            </Col>
            <Col className="col-5">
              <PaymentMethodPanel />
              <SeparateInvoicingCheckbox />
            </Col>
          </Row>
        </Form>
      </FormProvider>
    </PageLayout>
  );
}
