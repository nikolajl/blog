import Guard from '@/components/navigation/Guard';
import InvoiceDetailsPage from './accounts/invoices/InvoiceDetailsPage';
import InvoiceOverviewPage from './accounts/invoices/InvoiceOverviewPage';
import AccountRefundsPage from './accounts/order-refund/AccountRefundsPage';
import PaymentsOverview from './accounts/PaymentsOverview';
import EditBillToPage from './EditBillingInfo/EditBillToPage';
import EditSoldToPage from './EditBillingInfo/EditSoldToPage';

const customerRoutes = {
  path: 'customers/:ssoId/:accountNumber',
  children: [
    {
      path: 'order-refund',
      element: (
        <Guard allow={({ user }) => user.flags.EasyRefund}>
          <AccountRefundsPage />
        </Guard>
      ),
    },
    {
      path: 'payments',
      element: <PaymentsOverview />,
    },
    {
      path: 'invoices',
      children: [
        {
          path: '/',
          element: <InvoiceOverviewPage />,
        },
        {
          path: ':invoiceId',
          element: <InvoiceDetailsPage />,
        },
      ],
    },
    {
      path: 'editsoldto',
      element: <EditSoldToPage />,
    },
    {
      path: 'editbillto',
      element: <EditBillToPage />,
    },
  ],
};
export default customerRoutes;
