import PageLayout from '@/components/layouts/PageLayout';
import { PaymentsTable } from '@/components/PaymentsTable';
import { MakeGenerics, useMatch } from '@tanstack/react-location';
import { GlobalHotKeys } from 'react-hotkeys';

type RouteProps = MakeGenerics<{
  Params: {
    accountNumber: string;
    ssoId: string;
  };
}>;

const keyMap = {
  CUSTOMER_OVERVIEW: 'Alt+j',
};
export default function PaymentsOverview() {
  const { params } = useMatch<RouteProps>();

  const hotkeyHandlers = {
    CUSTOMER_OVERVIEW: () =>
      window.location.assign(
        `/Customer/ViewCustomer/${params.ssoId}?accountNumber=${params.accountNumber}`
      ),
  };
  return (
    <PageLayout title={`Betalingshistorik for ${params.accountNumber}`}>
      <GlobalHotKeys keyMap={keyMap} handlers={hotkeyHandlers} />
      <PaymentsTable />
    </PageLayout>
  );
}
