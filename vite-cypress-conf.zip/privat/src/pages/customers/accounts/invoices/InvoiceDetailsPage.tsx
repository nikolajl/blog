import { useAccount } from '@/api/accounts';
import { useGetInvoice } from '@/api/invoices';
import Button from '@/components/forms/Button';
import PageLayout from '@/components/layouts/PageLayout';
import { useModal } from '@/components/providers/ModalProvider';
import { formatDate } from '@/utils/format';
import { MakeGenerics, useMatch } from '@tanstack/react-location';
import { Col, Row, Stack } from 'react-bootstrap';
import { HotKeys } from 'react-hotkeys';
import { FaPen } from 'react-icons/fa';
import ApplyCreditBalance from './components/ApplyCreditBalance';
import DownloadInvoiceButton from './components/DownloadInvoiceButton';
import EdiExDropdown from './components/EdiExDropdown';
import EditGracePeriod from './components/EditGracePeriod';
import InvoiceItemsTable from './components/InvoiceItemsTable';
import { InvoicePaymentsTable } from './components/InvoicePaymentsTable';
import InvoiceSummary from './components/InvoiceSummary';
import ResendInvoice from './components/ResendInvoiceModal';

type RouteProps = MakeGenerics<{
  Params: {
    ssoId: string;
    accountNumber: string;
    invoiceId: string;
  };
}>;

export default function InvoiceDetailsPage() {
  const { params } = useMatch<RouteProps>();
  const account = useAccount(params.accountNumber);
  const invoice = useGetInvoice(params.invoiceId);

  const { showModal } = useModal();

  const hotkeyHandlers = {
    CUSTOMER_OVERVIEW: () => {
      window.location.assign(
        `/Customer/ViewCustomer/${params.ssoId}?accountNumber=${params.accountNumber}`
      );
    },
  };

  return (
    <HotKeys handlers={hotkeyHandlers}>
      <PageLayout
        title={`Faktura ${invoice.data?.invoiceNumber ?? '...'}`}
        crumbs={[{ href: '../invoices', title: 'Fakturaer' }]}
        isLoading={!invoice.data || !account.data}
        error={invoice.error || account.error}>
        {invoice.data && account.data && (
          <>
            <Row>
              <Col>
                <InvoiceSummary invoice={invoice.data} />
              </Col>
              <Col md={2}>
                Fakturaforsendelser: <EdiExDropdown invoiceNumber={invoice.data.invoiceNumber} />
              </Col>
              <Col>
                <Stack gap={1}>
                  <DownloadInvoiceButton
                    className="ms-auto"
                    variant="outline-success"
                    invoiceNumber={invoice.data.invoiceNumber}>
                    Download faktura som PDF
                  </DownloadInvoiceButton>
                  <Button
                    onClick={() =>
                      showModal(
                        'Genudsend Faktura',
                        <ResendInvoice
                          invoice={invoice.data}
                          accountNumber={account.data.accountNumber}
                        />
                      )
                    }
                    className="ms-auto"
                    variant="outline-success">
                    Genudsend faktura til kunden
                  </Button>
                  <Button
                    disabled={account.data.creditBalance <= 0}
                    onClick={() =>
                      showModal(
                        'Påfør tilgodehavende',
                        <ApplyCreditBalance
                          invoiceId={invoice.data.invoiceId}
                          accountNumber={account.data.accountNumber}
                          creditBalance={account.data.creditBalance}
                        />
                      )
                    }
                    className="ms-auto"
                    variant="outline-success">
                    Påfør tilgodehavende
                  </Button>

                  <Button
                    title="Rediger aftalt betalingsdato"
                    onClick={() =>
                      showModal(
                        'Rediger aftalt betalingsdato',
                        <EditGracePeriod
                          accountId={account.data.accountNumber}
                          gracePeriod={
                            account.data.gracePeriod
                              ? new Date(account.data.gracePeriod)
                              : undefined
                          }
                        />
                      )
                    }
                    variant="outline"
                    className="ms-auto">
                    {account.data.gracePeriod
                      ? `Aftalt betalingsdato: ${formatDate(account.data.gracePeriod)}`
                      : 'Aftal betalingsdato'}
                    <FaPen className="ms-2 align-middle" />
                  </Button>
                </Stack>
              </Col>
            </Row>
            <InvoiceItemsTable ssoId={params.ssoId} invoice={invoice.data} account={account.data} />
            <InvoicePaymentsTable account={account.data} />
          </>
        )}
      </PageLayout>
    </HotKeys>
  );
}
