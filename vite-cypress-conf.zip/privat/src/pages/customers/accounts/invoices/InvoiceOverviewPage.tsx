import { useAccount } from '@/api/accounts';
import {
  DeliveryMethod,
  InvoiceType,
  InvoiceOverviewItem,
  SentToEdiEx,
  Invoice,
} from '@/api/types/invoices';
import { useGetInvoices } from '@/api/invoices';
import Button from '@/components/forms/Button';
import PageLayout from '@/components/layouts/PageLayout';
import Tooltip from '@/components/ui/Tooltip';
import { formatCurrency, formatDate } from '@/utils/format';
import { formatDeliveryMethod, formatDunning } from '@/utils/format/invoices';
import { Link, MakeGenerics, useMatch } from '@tanstack/react-location';
import { FaMoneyBill, FaBan, FaEnvelope, FaCheck, FaPen, FaDownload } from 'react-icons/fa';
import { Col, Container, Row, Spinner, Stack, Table } from 'react-bootstrap';
import cx from 'classnames';
import {
  PaymentMethodType,
  SurchargeExemption,
  SurchargeExemptionText,
} from '@/api/types/accounts';
import { useModal } from '@/components/providers/ModalProvider';
import ResendInvoice from './components/ResendInvoiceModal';
import EditGracePeriod from './components/EditGracePeriod';
import EditSurchargeExemption from './components/EditSurchargeExemption';
import EdiExDropdown from './components/EdiExDropdown';
import DownloadInvoiceButton from './components/DownloadInvoiceButton';
import { useState } from 'react';
import { GlobalHotKeys } from 'react-hotkeys';

const TODAY = new Date();
TODAY.setHours(0, 0, 0, 0);
const PAGES_SIZE = 5;

const keyMap = {
  CUSTOMER_OVERVIEW: 'Alt+j',
};

type RouteProps = MakeGenerics<{
  Params: {
    ssoId: string;
    accountNumber: string;
  };
}>;
export default function InvoiceOverviewPage() {
  const { params } = useMatch<RouteProps>();
  const { data: account } = useAccount(params.accountNumber);
  const { data, error, fetchNextPage, hasNextPage, isLoading, isFetchingNextPage } = useGetInvoices(
    params.accountNumber
  );
  const { showModal } = useModal();
  const [maxPages, setMaxPages] = useState(PAGES_SIZE);

  const hotkeyHandlers = {
    CUSTOMER_OVERVIEW: () =>
      window.location.assign(
        `/Customer/ViewCustomer/${params.ssoId}?accountNumber=${params.accountNumber}`
      ),
  };

  if (hasNextPage) {
    data && data?.pages?.length < maxPages && fetchNextPage();
  }

  const getDeliveryMethod = (data: {
    deliveryMethod: DeliveryMethod;
    sentToEdiExStatus: SentToEdiEx;
  }) => {
    const { deliveryMethod, sentToEdiExStatus } = data;
    if (account?.paymentMethodName === 'CreditCard') return <span>{' - '}</span>;
    if (sentToEdiExStatus === 'NotSent') return <span>Udsendes snarest</span>;
    if (sentToEdiExStatus === 'Sent')
      return (
        <span>
          Sendt med {formatDeliveryMethod(deliveryMethod)}
          {deliveryMethod === 'Unknown' && ' metode'}
        </span>
      );
    return <span>ukendt metode</span>; // TODO check if this is needed
  };

  const handleResendInvoiceClick = (
    accountNumber: string,
    invoice: { invoiceId: string; invoiceAmount: number }
  ) => {
    showModal(
      'Genudsend faktura',
      <ResendInvoice accountNumber={accountNumber} invoice={invoice as Invoice} />
    );
  };

  const getPaymentStatus = (
    invoiceType: InvoiceType,
    amount: number,
    balance: number,
    paymentMethod: PaymentMethodType
  ) => {
    if (invoiceType !== 'Compensation') {
      if (balance === 0 && invoiceType === 'WriteOff')
        return <span className="fw-bold text-warning">Beløb afskrevet (RVS-flow)</span>;
      if (amount < 0) return <span className="text-weight-bold">Kreditnota</span>;
      if (balance > 0) {
        return (
          <span className="fw-bold text-warning">
            Ikke betalt
            {paymentMethod === 'MobilePay' ?? (
              <Tooltip>Der kan gå op til 24 timer før en betaling via MobilePay kan vises.</Tooltip>
            )}
          </span>
        );
      }
      if (balance === 0)
        return (
          <span className="fw-bold text-success">
            <FaCheck /> Betalt
          </span>
        );
    }
    return null;
  };

  const flattenPages = (
    pages: { invoices: InvoiceOverviewItem[]; hasNext: boolean }[] | undefined
  ) => {
    if (!pages) return [];
    return pages.map((p) => p.invoices).flat();
  };

  const sortInvoices = (invoices: InvoiceOverviewItem[]) => {
    return [...invoices].sort(
      (a, b) => new Date(b.invoiceDate).getTime() - new Date(a.invoiceDate).getTime()
    );
  };

  const getIsOverDue = (invoiceDueDate: Date, balance: number) => {
    return new Date(invoiceDueDate) < TODAY && balance > 0;
  };

  const onEditGracePeriodClick = () =>
    account &&
    showModal(
      'Rediger aftalt betalingsdato',
      <EditGracePeriod
        // invoiceId={invoice.data.invoiceNumber}
        accountId={account.accountNumber}
        gracePeriod={account.gracePeriod ? new Date(account.gracePeriod) : undefined}
      />
    );

  const onEditExemptionClick = () =>
    account &&
    showModal(
      'Rediger gebyr',
      <EditSurchargeExemption
        accountId={account.id}
        surchargeExemption={account.surchargeExemption}
      />
    );

  return (
    <PageLayout title={`Fakturaer for ${params.accountNumber}`} isLoading={!data} error={error}>
      <GlobalHotKeys keyMap={keyMap} handlers={hotkeyHandlers} />
      <Container>
        <Row>
          <Col>
            {data && hasNextPage && (
              <>
                <div className="text-muted">{`${data?.pages?.length} sider hentet...`}</div>
                <div className="text-muted">{`${
                  flattenPages(data?.pages).length
                } fakturaer hentet...`}</div>
                <Button
                  disabled={isFetchingNextPage}
                  loading={isFetchingNextPage}
                  variant="outline-secondary"
                  size="sm"
                  onClick={() => {
                    setMaxPages(maxPages + 5);
                  }}>
                  {isFetchingNextPage
                    ? 'Henter flere...'
                    : `Hent op til ${PAGES_SIZE * 40} flere fakturaer (${PAGES_SIZE} sider)`}
                </Button>
              </>
            )}
          </Col>
          <Col>
            <Stack className="text-end" gap={1}>
              <Button
                title="Rediger aftalt betalingsdato"
                onClick={onEditGracePeriodClick}
                variant="outline"
                className="ms-auto">
                {account?.gracePeriod
                  ? `Aftalt betalingsdato: ${formatDate(account.gracePeriod)}`
                  : 'Aftal betalingsdato'}
                <FaPen className="ms-2 align-middle" />
              </Button>
              <Button
                title="Rediger aftalt betalingsdato"
                onClick={onEditExemptionClick}
                variant="outline"
                className="ms-auto">
                Gebyr:{' '}
                {account && (
                  <em className="text-muted">
                    {`(${
                      SurchargeExemptionText[account.surchargeExemption as SurchargeExemption]
                    })`}
                  </em>
                )}
                <FaPen className="ms-2 align-middle" />
              </Button>
            </Stack>
          </Col>
        </Row>
      </Container>
      <Container className="float-start"></Container>
      <Table striped hover variant="light">
        <thead>
          <tr>
            <th>Dato</th>
            <th>Faktura</th>
            <th>Type</th>
            <th>{'Abonnement(er)'}</th>
            <th className="text-end">Beløb</th>
            <th className="text-end">Fakturabalance</th>
            <th>Forfaldsdato</th>
            <th style={{ width: 200 }}>Forsendelsesmetode</th>
            <th>Betalingsstatus</th>
            <th>Betalingsmetode</th>
            <th>Handlinger</th>
          </tr>
        </thead>
        <tbody>
          {!isLoading &&
            data?.pages &&
            sortInvoices(flattenPages(data.pages)).map(
              (
                {
                  id,
                  invoiceDate,
                  invoiceNumber,
                  invoiceType,
                  subscriptions,
                  amount,
                  currency,
                  balance,
                  invoiceDueDate,
                  deliveryMethod,
                  sentToEdiExStatus,
                  paymentMethod,
                  dunningStatus,
                  dunningRelatedInvoiceNumber,
                },
                index
              ) => (
                <tr key={id + index}>
                  <td>{formatDate(invoiceDate, 'dd-MM-yy')}</td>
                  <td>
                    <span style={{ display: 'block' }}>
                      <Link to={id}>{invoiceNumber}</Link>
                    </span>
                  </td>
                  <td>
                    {{
                      Default: <span>Standard</span>,
                      Compensation: (
                        <span>
                          <FaMoneyBill size={20} className="text-muted" /> Godtgørelse{' '}
                          <em className="text-muted">(Kreditnota)</em>
                        </span>
                      ),
                      Cancellation: (
                        <span>
                          <FaBan size={16} className="text-muted" /> Opsigelse
                        </span>
                      ),
                      WriteOff: (
                        <span>
                          Standard <em className="text-muted">(Afskrevet)</em>
                        </span>
                      ),
                      MobilePayUpfrontCaptured: <span>MobilePay Køb</span>,
                      MigrationAccountBalanceCorrection: <span>Overført saldo fra migrering</span>,
                    }[invoiceType] || invoiceType}
                    {dunningStatus !== 'NotInDunning' &&
                      (dunningRelatedInvoiceNumber ? (
                        <div>
                          <strong>
                            (RVS:{' '}
                            <span className="text-danger">{formatDunning(dunningStatus)}</span>)
                          </strong>
                        </div>
                      ) : (
                        <div>
                          <strong>
                            (RVS:{' '}
                            <span className="text-danger">{formatDunning(dunningStatus)}</span>)
                          </strong>
                        </div>
                      ))}
                  </td>
                  <td>
                    {subscriptions?.map((sub) => (
                      <div key={sub}>
                        <a href={`/Customer/Results?input=${sub}`}>{sub}</a>
                      </div>
                    ))}
                  </td>
                  <td className="text-end">{formatCurrency(amount, { currency })}</td>
                  <td className="text-end">{formatCurrency(balance, { currency })}</td>
                  <td>
                    {
                      <span
                        className={cx({
                          'fw-bold text-danger': getIsOverDue(invoiceDueDate, balance),
                        })}>
                        {formatDate(invoiceDueDate)}
                      </span>
                    }
                  </td>
                  <td>
                    {getDeliveryMethod({ deliveryMethod, sentToEdiExStatus })}
                    <EdiExDropdown invoiceNumber={invoiceNumber} />
                  </td>
                  <td>{getPaymentStatus(invoiceType, amount, balance, paymentMethod)}</td>
                  <td>
                    {amount > 0 && paymentMethod === 'CreditCard' ? (
                      <span>Kreditkort</span>
                    ) : (
                      <span> - </span>
                    )}
                  </td>
                  <td>
                    <span>
                      <DownloadInvoiceButton
                        size="sm"
                        variant="outline-success"
                        invoiceNumber={invoiceNumber}>
                        <FaDownload size={15} />
                      </DownloadInvoiceButton>
                      <Button
                        variant="outline-success"
                        size="sm"
                        onClick={() => {
                          account !== undefined &&
                            handleResendInvoiceClick(account.accountNumber, {
                              invoiceId: id,
                              invoiceAmount: amount,
                            });
                        }}>
                        <FaEnvelope size={15} />
                      </Button>
                    </span>
                  </td>
                </tr>
              )
            )}
        </tbody>
      </Table>
      <Container className="mx-auto text-center">
        {data && hasNextPage && (
          <>
            <div className="text-muted">{`${data?.pages?.length} sider hentet...`}</div>
            <div className="text-muted">{`${
              flattenPages(data?.pages).length
            } fakturaer hentet...`}</div>
            <Button
              disabled={isFetchingNextPage}
              loading={isFetchingNextPage}
              variant="outline-secondary"
              size="sm"
              onClick={() => {
                setMaxPages(maxPages + 5);
              }}>
              {isFetchingNextPage
                ? 'Henter flere...'
                : `Hent op til ${PAGES_SIZE * 40} flere fakturaer (${PAGES_SIZE} sider)`}
            </Button>
          </>
        )}
      </Container>

      {isLoading && (
        <Container className="mx-auto text-center">
          <Spinner size="sm" animation="border" variant="primary" />
          Henter data...
        </Container>
      )}
    </PageLayout>
  );
}
