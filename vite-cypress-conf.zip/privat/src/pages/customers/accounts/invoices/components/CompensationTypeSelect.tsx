import Select from 'react-select';
import cx from 'classnames';
import { useState } from 'react';
import { get, useFormContext } from 'react-hook-form';
import { FormText } from 'react-bootstrap';

type Props = {
  onChange: (compensation: CompensationType) => void;
};

export default function CompensationCodeSelect({ onChange }: Props) {
  const [compensationType, setCompensationType] = useState<CompensationType | null>();
  const [compensationTypeQuery, setCompensationTypeQuery] = useState('');

  const form = useFormContext();
  const [code] = form.watch(['compensationType']);
  const error = get(form.formState.errors, 'compensationType');

  return (
    <>
      <Select
        name="compensationType"
        className={cx('react-select', 'mb-2')}
        isClearable
        placeholder="Vælg godtgørelseskode"
        options={CompensationCodes}
        onChange={(value) => onChange(value as CompensationType)}
        onInputChange={(value, event) => {
          if (event.action === 'input-change') !value && form.resetField('code');
          setCompensationTypeQuery(value);
        }}
        onBlur={() => !compensationType && setCompensationType(null)}
        noOptionsMessage={() => 'Ingen resultater'}
        filterOption={(option) =>
          option.value.toLowerCase().includes(compensationTypeQuery.toLowerCase())
        }
        onMenuOpen={() => compensationType && setCompensationTypeQuery(compensationType.name)}
        inputValue={compensationTypeQuery ?? ''}
        value={code ?? undefined}
        getOptionLabel={(compensation) => compensation?.name ?? ''}
        getOptionValue={(compensation) => compensation?.name ?? ''}
      />
      {error?.message && <FormText>{error.message.toString()}</FormText>}
    </>
  );
}

type AccountingCode =
  | 'Administration'
  | 'Rykkergebyr'
  | 'GodskrivningAbonnement'
  | 'AlleTyperRabat';

export type CompensationType = {
  name: string;
  accountingCode: AccountingCode;
};

const CompensationCodes: CompensationType[] = [
  { name: 'Administrationsgebyr', accountingCode: 'Administration' },
  { name: 'Rykkergebyr', accountingCode: 'Rykkergebyr' },
  { name: 'Misforstået salg', accountingCode: 'GodskrivningAbonnement' },
  { name: 'Fakturakorrektion', accountingCode: 'GodskrivningAbonnement' },
  { name: 'Ekstraordinær rabat', accountingCode: 'AlleTyperRabat' },
  { name: 'Manglende levering', accountingCode: 'GodskrivningAbonnement' },
  { name: 'Rabat ved BS tilmelding', accountingCode: 'AlleTyperRabat' },
  { name: 'Godtgørelse af periode', accountingCode: 'GodskrivningAbonnement' },
];
