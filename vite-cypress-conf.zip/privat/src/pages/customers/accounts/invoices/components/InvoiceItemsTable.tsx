import { Invoice } from '@/api/types/invoices';
import { Account } from '@/api/types/accounts';
import { Table } from 'react-bootstrap';
import { formatCurrency, formatDate } from '@/utils/format';
import { FaClock, FaRegMoneyBillAlt } from 'react-icons/fa';
import Button from '@/components/forms/Button';
import CompensationModal from './CompensationModal';
import { useModal } from '@/components/providers/ModalProvider';

type Props = {
  ssoId: string;
  invoice: Invoice;
  account: Account;
};

export default function InvoiceItemsTable({ ssoId, invoice, account }: Props) {
  const { showModal } = useModal();

  return (
    <Table striped hover variant="light">
      <thead>
        <tr>
          <th style={{ width: 175 }}>Abonnement</th>
          <th>Produkt</th>
          <th style={{ width: 200 }}>Periode</th>
          <th style={{ width: 115, textAlign: 'right' }}>Beløb</th>
          <th style={{ width: 115, textAlign: 'right' }}>Moms</th>
          <th style={{ width: 115, textAlign: 'right' }}>Total</th>
          <th style={{ width: 75, textAlign: 'right' }}></th>
        </tr>
      </thead>
      <tbody>
        {invoice.invoiceItems.map((charge, i) => {
          const fullChargeAmount = charge.chargeAmount + charge.taxAmount;
          const invoiceTypeIsCreditNota = invoice.invoiceAmount < 0;
          const isPureCompensation = charge.productName === 'Godtgørelseskoder';

          // Causes the button to be disabled
          const isCompensationDisabled =
            charge.productName !== 'Rykkergebyr' &&
            ((isPureCompensation && invoiceTypeIsCreditNota) ||
              new Date(charge.serviceEndDate) < new Date() ||
              fullChargeAmount <= 0 ||
              invoice.invoiceTypeC === 'WriteOff' ||
              account.consolidatedInvoice);
          return (
            <tr key={i}>
              <td>
                <a
                  href={`/Customer/ViewCustomer/${ssoId}?subscriptionNumber=${charge.subscriptionName}&accountNumber=${invoice.accountNumber}`}>
                  {charge.subscriptionName}
                </a>
                <Button
                  variant="outline-primary"
                  size="sm"
                  className="ms-2"
                  title="Abonnementshistorik"
                  href={`/subscriptions/overview?ssoId=${ssoId}&subscriptionNumber=${charge.subscriptionName}`}>
                  <FaClock className="align-baseline" />
                </Button>
              </td>
              <td>
                {invoice.invoiceTypeC == 'Compensation' && invoice.invoiceAmount < 0 ? (
                  <>
                    <em>Godtgørelseskode:</em> {charge.chargeDescription}
                  </>
                ) : (
                  <>
                    {charge.productName}
                    <br />
                    {charge.chargeName}
                  </>
                )}
              </td>
              <td>
                {formatDate(charge.serviceStartDate)} - {formatDate(charge.serviceEndDate)}
              </td>
              <td style={{ textAlign: 'right' }}>
                {formatCurrency(charge.chargeAmount, { currency: invoice.currency })}
              </td>
              <td style={{ textAlign: 'right' }}>
                {formatCurrency(charge.taxAmount, { currency: invoice.currency })}
              </td>
              <td style={{ textAlign: 'right' }}>
                {formatCurrency(fullChargeAmount, {
                  currency: invoice.currency,
                })}
              </td>
              <td style={{ textAlign: 'right' }}>
                {!isCompensationDisabled && (
                  <Button
                    variant="outline-success"
                    size="sm"
                    title="Tilføj godtgørelse"
                    onClick={() => {
                      showModal(
                        'Opret Godtgørelse',
                        <CompensationModal
                          subscriptionNumber={invoice.invoiceItems[0].subscriptionName}
                          accountNumber={account.accountNumber}
                          invoice={invoice}
                          currentInvoiceItem={charge}
                        />,
                        true,
                        { size: 'xl' }
                      );
                    }}>
                    <FaRegMoneyBillAlt size={28} />
                  </Button>
                )}
              </td>
            </tr>
          );
        })}
      </tbody>
    </Table>
  );
}
