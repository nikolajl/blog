import Panel from '@/components/ui/Panel';
import { Col, Container, Form, ListGroup, Modal, Row, Spinner } from 'react-bootstrap';
import { InputText } from '@/components/forms/InputText';
import { FormProvider, useForm } from 'react-hook-form';
import { compensationSchema, CompensationSchemaType } from './compensation.schema';
import { yupResolver } from '@hookform/resolvers/yup';
import Button from '@/components/forms/Button';
import { useCompensationHistory, useCreateCompensation } from '@/api/compensations';
import { formatCurrency, formatDate } from '@/utils/format';
import CompensationTypeSelect, { CompensationType } from './CompensationTypeSelect';
import { useModal } from '@/components/providers/ModalProvider';
import { Invoice, InvoiceItem } from '@/api/types/invoices';
import { useAccount } from '@/api/accounts';
import { useToastProvider } from '@/components/messages/ToastProvider';
import FormCurrency from '@/components/ui/forms/FormCurrency';
import { useSubscription } from '@/api/subscriptions';

type Props = {
  currency?: 'DKK' | 'NOK' | 'EUR';
  subscriptionNumber: string;
  accountNumber: string;
  invoice: Invoice;
  currentInvoiceItem: InvoiceItem;
};

export default function CompensationModal({
  currency = 'DKK',
  subscriptionNumber,
  accountNumber,
  currentInvoiceItem,
  invoice,
}: Props) {
  const form = useForm<CompensationSchemaType>({
    resolver: yupResolver(compensationSchema),
    mode: 'onChange',
    defaultValues: {
      effectiveDate: new Date(),
      amount: 0,
      accountNumber,
      ratePlanChargeId: currentInvoiceItem.chargeId,
      invoiceId: invoice.invoiceId,
      isTaxed: currentInvoiceItem.taxAmount > 0,
      subscriptionNumber,
      isInvoicePaymentProcessed: invoice.invoiceBalance == 0,
    },
  });

  const { closeModal } = useModal();
  const account = useAccount(accountNumber);
  const { data } = useCompensationHistory(subscriptionNumber, accountNumber);
  const { mutate } = useCreateCompensation();
  const { showInfo } = useToastProvider();
  const subscription = useSubscription(subscriptionNumber);

  const onSubmit = (values: CompensationSchemaType) => {
    mutate({
      ...values,
    });

    showInfo('Oprettelse af godtgørelse sat i gang', '', 2000);
    closeModal();
  };

  const onCompensationTypeChange = (compensation: CompensationType) => {
    form.setValue('compensationType', compensation);
  };

  let paymentStatus = null;
  if (invoice.invoiceAmount < 0) {
    paymentStatus = <span className="text-weight-bold">Kreditnota</span>;
  } else if (invoice.invoiceBalance === 0) {
    paymentStatus = (
      <span className="text-weight-bold text-success">
        <i className="fas fa-check"></i> Betalt
      </span>
    );
  } else if (invoice.invoiceBalance > 0) {
    paymentStatus = <span className="text-weight-bold text-warning">Ikke betalt</span>;
  }

  if (subscription.isLoading)
    return (
      <Container>
        <div className="mb-2" style={{ textAlign: 'center' }}>
          <Spinner size="sm" animation="border" /> Henter oplysninger...
        </div>
        <Modal.Footer>
          <Button
            variant={'outline-primary'}
            onClick={() => {
              closeModal(), form.reset();
            }}>
            Luk
          </Button>
        </Modal.Footer>
      </Container>
    );

  if (subscription.data?.status === 'Cancelled') {
    return (
      <Container className="mb-2">
        <Col style={{ textAlign: 'center' }}>
          <b>Valgte abonnement er ikke aktivt</b>
          <p>Godtgørelse kan derfor ikke udføres</p>
        </Col>
        <Modal.Footer>
          <Button
            variant={'outline-primary'}
            onClick={() => {
              closeModal(), form.reset();
            }}>
            Luk
          </Button>
        </Modal.Footer>
      </Container>
    );
  }

  return (
    <>
      <Container className="mb-2">
        <Col>
          <b>Godtgøres med moms?</b> {currentInvoiceItem.taxAmount > 0 ? 'Ja' : 'Nej'}
        </Col>
        <b>Godtgøres på:</b> {invoice.invoiceBalance == 0 ? 'kommende' : 'denne'} faktura
        <Col>
          <b>Fakturastatus:</b> {paymentStatus}
        </Col>
        <Col>
          <b>Kontonummer:</b> {invoice.accountNumber}
        </Col>
        <Col>
          <b>Abonnementsnummer:</b> {subscriptionNumber}
        </Col>
        <Col>
          <b>Kundens navn:</b> {account.data?.firstName} {account.data?.lastName}
        </Col>
      </Container>
      <Container>
        <FormProvider {...form}>
          <Form onSubmit={form.handleSubmit(onSubmit)}>
            <Row>
              <Col>
                <Panel title="Indstillinger for godtgørelse">
                  <Form.Control
                    className="required mb-2"
                    placeholder="Vælg startdato"
                    value={formatDate(new Date())}
                    disabled={true}
                    readOnly={true}
                  />
                  <CompensationTypeSelect onChange={onCompensationTypeChange} />
                  <InputText
                    className="mb-2"
                    name="reason"
                    placeholder="Begrundelse for godtgørelse"
                  />
                  <FormCurrency name="amount" currency={currency} />
                </Panel>
              </Col>
              <Col>
                <Panel title="Godtgørelseshistorik">
                  {data && data.length > 0 ? (
                    <>
                      <small>Seneste 10 godtgørelser</small>
                      <ListGroup>
                        {data
                          ?.sort(
                            (a, b) =>
                              new Date(a.ratePlanStartDate).getTime() -
                              new Date(b.ratePlanStartDate).getTime()
                          )
                          .slice(0, 10)
                          .map((rp) => (
                            <ListGroup.Item key={rp.id}>
                              <Row>
                                <Col>
                                  <strong>{formatDate(rp.ratePlanStartDate)}</strong>
                                </Col>
                                <Col>{rp.ratePlanCharges[0].description}</Col>
                                <Col>
                                  {formatCurrency(rp.ratePlanCharges[0].price, {
                                    currency: rp.ratePlanCharges[0].currency,
                                  })}
                                </Col>
                              </Row>
                            </ListGroup.Item>
                          ))}
                      </ListGroup>
                    </>
                  ) : (
                    <small className="gray">Ingen godtgørelser på abonnementet</small>
                  )}
                </Panel>
              </Col>
            </Row>
            <Modal.Footer>
              <Button variant={'success'} type="submit">
                Opret godtgørelse
              </Button>
              <Button
                variant={'outline-danger'}
                onClick={() => {
                  closeModal(), form.reset();
                }}>
                Afbryd
              </Button>
            </Modal.Footer>
          </Form>
        </FormProvider>
      </Container>
    </>
  );
}
