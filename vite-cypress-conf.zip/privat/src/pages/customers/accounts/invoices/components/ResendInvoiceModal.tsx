import { Col, Form, Row, Stack } from 'react-bootstrap';
import { useForm } from 'react-hook-form';
import Select from 'react-select';
import cx from 'classnames';
import * as yup from 'yup';
import { Invoice } from '@/api/types/invoices';
import { useGetResendMethods, usePostResendInvoice } from '@/api/invoices';
import Button from '@/components/forms/Button';
import { useModal } from '@/components/providers/ModalProvider';
import { formatResendMethod } from '@/utils/format/invoices';
import { yupResolver } from '@hookform/resolvers/yup';

type Props = {
  accountNumber: string;
  invoice: Invoice;
};

const schema = yup.object({
  resendMethod: yup.string().required(),
});

type FormValues = yup.InferType<typeof schema>;

export default function ResendInvoice({ accountNumber, invoice }: Props) {
  const form = useForm<FormValues>({
    resolver: yupResolver(schema),
  });

  const resendInvoice = usePostResendInvoice();
  const getResendMethods = useGetResendMethods(accountNumber);
  const { closeModal } = useModal();

  const onSubmit = ({ resendMethod }: FormValues) => {
    resendInvoice.mutate({ invoiceId: invoice.invoiceId, resendMethod });
    closeModal();
  };

  const resendMethods =
    invoice.invoiceAmount < 0
      ? getResendMethods.data?.filter((x) => x.method !== 'EAN')
      : getResendMethods.data;

  return (
    <Form onSubmit={form.handleSubmit(onSubmit)}>
      <Row>
        <Col>
          <Select
            className={cx('react-select', {
              required: true,
              invalid: !!form.formState.errors.resendMethod,
            })}
            defaultValue={resendMethods?.at(0)}
            options={resendMethods}
            getOptionLabel={(x) => formatResendMethod(x)}
            getOptionValue={(x) => x.method}
            onChange={(x) => form.setValue('resendMethod', x?.method ?? '')}
          />
        </Col>
      </Row>
      <Row className="mt-2">
        <Col className="align-right">
          <Stack direction="horizontal" gap={1}>
            <Button variant="outline-primary" className="ms-auto" onClick={() => closeModal()}>
              Luk
            </Button>
            <Button
              type="submit"
              variant="success"
              loading={resendInvoice.isLoading}
              disabled={resendInvoice.isLoading}>
              Genudsend
            </Button>
          </Stack>
        </Col>
      </Row>
    </Form>
  );
}
