import { useUpdateGracePeriod } from '@/api/accounts';
import Button from '@/components/forms/Button';
import FormDate from '@/components/ui/forms/FormDate';
import { useModal } from '@/components/providers/ModalProvider';
import { yupResolver } from '@hookform/resolvers/yup';
import { Col, Form, Row, Stack } from 'react-bootstrap';
import { FormProvider, useForm } from 'react-hook-form';
import * as yup from 'yup';
import { addDays } from 'date-fns';

type Props = {
  accountId: string;
  gracePeriod?: Date;
};

const schema = yup.object({
  gracePeriod: yup.date().required(),
});

type FormValues = yup.InferType<typeof schema>;

export default function EditGracePeriod({ accountId, gracePeriod }: Props) {
  const updateGracePeriod = useUpdateGracePeriod();
  const form = useForm<FormValues>({
    resolver: yupResolver(schema),
    defaultValues: { gracePeriod },
  });

  const { closeModal } = useModal();

  const onSubmit = ({ gracePeriod }: FormValues) => {
    updateGracePeriod.mutate({
      accountId,
      gracePeriod,
    });
    closeModal();
  };

  return (
    <FormProvider {...form}>
      <Form onSubmit={form.handleSubmit(onSubmit)}>
        <Row>
          <Col>
            <FormDate
              name="gracePeriod"
              minDate={new Date()}
              maxDate={addDays(new Date(), 35)}
              placeholderText="Aftalt betalingsdato"
            />
          </Col>
        </Row>
        <Row className="mt-2">
          <Col className="align-right">
            <Stack direction="horizontal" gap={1}>
              <Button variant="outline-primary" className="ms-auto" onClick={() => closeModal()}>
                Fortryd
              </Button>
              <Button type="submit" variant="success">
                Gem
              </Button>
            </Stack>
          </Col>
        </Row>
      </Form>
    </FormProvider>
  );
}
