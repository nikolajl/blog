import { useUpdateSurchargeExemption } from '@/api/accounts';
import { SurchargeExemption, SurchargeExemptionText } from '@/api/types/accounts';
import Button from '@/components/forms/Button';
import { useModal } from '@/components/providers/ModalProvider';
import { yupResolver } from '@hookform/resolvers/yup';
import { useState } from 'react';
import { Form, Row, Col, Stack } from 'react-bootstrap';
import { useForm } from 'react-hook-form';
import Select from 'react-select';
import * as yup from 'yup';
type Props = {
  accountId: string;
  surchargeExemption: string;
};

const schema = yup.object({
  surchargeExemption: yup.string().nullable(),
});

type FormValues = yup.InferType<typeof schema>;

export default function EditSurchargeExemption({ accountId, surchargeExemption }: Props) {
  const updateSurchargeExemption = useUpdateSurchargeExemption();
  const form = useForm<FormValues>({
    resolver: yupResolver(schema),
    defaultValues: { surchargeExemption },
  });
  const [selected, setSelected] = useState<string | null>(surchargeExemption);

  const options = [
    { value: 'Never', label: SurchargeExemptionText['Never'] },
    { value: 'NextInvoice', label: SurchargeExemptionText['NextInvoice'] },
    { value: 'Always', label: SurchargeExemptionText['Always'] },
  ];

  const { closeModal } = useModal();
  const onSubmit = ({ surchargeExemption }: FormValues) => {
    updateSurchargeExemption.mutate({
      accountId,
      surchargeExemption: surchargeExemption as SurchargeExemption,
    });
    closeModal();
  };

  return (
    <Form onSubmit={form.handleSubmit(onSubmit)}>
      <Row>
        <Col>
          <Select
            options={options}
            value={{
              value: selected,
              label: SurchargeExemptionText[selected as SurchargeExemption],
            }}
            onChange={(v) => {
              if (v) {
                setSelected(v.value);
                form.setValue('surchargeExemption', v.value);
              }
            }}
          />
        </Col>
      </Row>
      <Row className="mt-2">
        <Col className="align-right">
          <Stack direction="horizontal" gap={1}>
            <Button variant="outline-primary" className="ms-auto" onClick={() => closeModal()}>
              Fortryd
            </Button>
            <Button type="submit" variant="success">
              Gem
            </Button>
          </Stack>
        </Col>
      </Row>
    </Form>
  );
}
