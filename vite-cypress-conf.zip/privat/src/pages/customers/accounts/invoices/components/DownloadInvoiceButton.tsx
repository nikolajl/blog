import { useGetEdiExInvoices } from '@/api/invoices';
import Button from '@/components/forms/Button';
import { PropsWithChildren } from 'react';
import { ButtonProps } from 'react-bootstrap';

type DownloadInvoiceProps = ButtonProps &
  PropsWithChildren<{
    invoiceNumber: string;
  }>;

export default function DownloadInvoiceButton({
  invoiceNumber,
  children,
  ...rest
}: DownloadInvoiceProps) {
  const { data, isLoading } = useGetEdiExInvoices(invoiceNumber);

  const latestEdiExInvoice =
    data &&
    data
      .sort((left, right) => {
        return (
          new Date(left.deliveredToDistributorDate).getTime() -
          new Date(right.deliveredToDistributorDate).getTime()
        );
      })
      .reverse()[0];
  const url = latestEdiExInvoice
    ? `/Invoice/DownloadEdiExInvoice?invoiceNumber=${invoiceNumber}&invoiceUuid=${latestEdiExInvoice.invoiceUuid}`
    : `/Invoice/DownloadInvoice?invoiceKey=${invoiceNumber}`;

  const title = latestEdiExInvoice ? 'Gem indbetalingskort som PDF' : 'Gem fakturaen som PDF';
  return (
    <Button
      {...rest}
      href={url}
      loading={isLoading}
      /* size="sm"
      variant="success" */
      title={title}
      target="_blank"
      rel="noreferrer">
      {children}
    </Button>
  );
}
