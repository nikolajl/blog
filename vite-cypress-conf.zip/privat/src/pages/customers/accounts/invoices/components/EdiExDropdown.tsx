import { useGetEdiExInvoices } from '@/api/invoices';
import { DeliveryMethodText } from '@/api/types/invoices';
import { formatDate } from '@/utils/format';
import { useState } from 'react';
import { Container, Spinner } from 'react-bootstrap';
import styles from './EdiExDropdown.module.scss';
import cx from 'classnames';
type EdiExDropdownProps = {
  invoiceNumber: string;
};

export default function EdiExDropdown({ invoiceNumber }: EdiExDropdownProps) {
  const { data, isLoading } = useGetEdiExInvoices(invoiceNumber);
  const [open, setOpen] = useState(false);
  const invoicesOrdered =
    !data || data.length === 0
      ? null
      : data
          .sort(
            (left, right) =>
              //left.deliveredToDistributorDate > right.deliveredToDistributorDate ? 1 : -1
              new Date(left.deliveredToDistributorDate).getTime() -
              new Date(right.deliveredToDistributorDate).getTime()
          )
          .reverse();

  return (
    <>
      {isLoading && (
        <Container className="mx-auto">
          <Spinner size="sm" animation="border" variant="secondary" />
          <em className="text-muted">Henter EdiEx...</em>
        </Container>
      )}
      {invoicesOrdered && (
        <div>
          <span className="text-muted fst-italic">
            Sendt {invoicesOrdered.length} {invoicesOrdered?.length === 1 ? 'gang' : 'gange'}
          </span>

          {invoicesOrdered && (
            <span
              className={cx(styles.hideShowEdi, 'linkstyle')}
              onClick={() => {
                setOpen(!open);
              }}>
              {open ? 'Skjul' : 'Vis'}
            </span>
          )}

          {open &&
            invoicesOrdered &&
            invoicesOrdered.map((edi) => (
              <div key={edi.invoiceUuid}>
                <a
                  title={edi.deliveryEmail ? edi.deliveryEmail : 'Gem indbetalingskort som PDF'}
                  href={`/invoice/downloadediexinvoice?invoiceNumber=${edi.invoiceNumber}&invoiceUuid=${edi.invoiceUuid}`}
                  target="_blank"
                  rel="noreferrer">
                  <strong>{formatDate(edi.deliveredToDistributorDate)}</strong> (
                  {DeliveryMethodText[edi.deliveryMethod]})
                </a>
                <hr style={{ margin: '0 0 3px 0', borderTop: 'darkgrey 1px solid' }} />
              </div>
            ))}
        </div>
      )}
    </>
  );
}
