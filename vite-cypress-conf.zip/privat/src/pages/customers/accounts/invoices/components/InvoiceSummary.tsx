import cx from 'classnames';
import { Invoice } from '@/api/types/invoices';
import { formatDate } from '@/utils/format';
import { formatDunning, formatDeliveryStatus } from '@/utils/format/invoices';
import DunningRelatedInvoices from './DunningRelatedInvoices';
import { useModal } from '@/components/providers/ModalProvider';
import { useInvoiceItemAdjustments } from '@/api/invoices';
import { FaBan, FaMoneyBill } from 'react-icons/fa';
import { formatAmount } from '@/utils/format/currency';

type Props = {
  invoice: Invoice;
};

// TODO: Er det bedre at bruge useGetInvoice?
export default function InvoiceSummary({ invoice }: Props) {
  const { showModal } = useModal();
  const invoiceItemAdjustments = useInvoiceItemAdjustments(invoice.invoiceId);

  let invoiceAdjustmentTotal = 0;
  let writeOffDetailSum = 0;
  let writeOffTaxSum = 0;
  invoiceItemAdjustments.data?.forEach((x) => {
    if (x.amount) {
      invoiceAdjustmentTotal += x.amount;

      if (x.sourceType === 'InvoiceDetail') {
        if (x.type === 'Charge' && x.amount) {
          writeOffDetailSum += x.amount;
        }
        if (x.type === 'Credit' && x.amount) {
          writeOffDetailSum -= x.amount;
        }
      }

      if (x.sourceType === 'Tax') {
        if (x.type === 'Charge' && x.amount) {
          writeOffTaxSum += x.amount;
        }
        if (x.type === 'Credit' && x.amount) {
          writeOffTaxSum -= x.amount;
        }
      }
    }
  });

  let paymentStatus = null;
  if (invoice.invoiceAmount < 0) {
    paymentStatus = <span className="text-weight-bold">Kreditnota</span>;
  } else if (invoice.invoiceBalance === 0) {
    paymentStatus = (
      <span className="text-weight-bold text-success">
        <i className="fas fa-check"></i> Betalt
      </span>
    );
  } else if (invoice.invoiceBalance > 0) {
    paymentStatus = <span className="text-weight-bold text-warning">Ikke betalt</span>;
  }

  let invoiceType = null;

  if (invoice.invoiceTypeC === 'Default') {
    invoiceType = <span>Standard</span>;
  } else if (invoice.invoiceTypeC === 'Compensation') {
    invoiceType = (
      <span>
        <FaMoneyBill size={20} className="text-muted" /> Godtgørelse{' '}
        <em className="text-muted">(Kreditnota)</em>
      </span>
    );
  } else if (invoice.invoiceTypeC === 'Cancellation') {
    invoiceType = (
      <span>
        <FaBan size={16} className="text-muted" /> Opsigelse
      </span>
    );
  } else if (invoice.invoiceTypeC === 'WriteOff') {
    invoiceType = (
      <span>
        Standard <em className="text-muted">(Afskrevet)</em>
      </span>
    );
  } else if (invoice.invoiceTypeC === 'MobilePayUpfrontCaptured') {
    invoiceType = <span>MobilePay Køb</span>;
  } else if (invoice.invoiceTypeC === 'MigrationAccountBalanceCorrection') {
    invoiceType = <span>Overført saldo fra migrering</span>;
  } else {
    invoiceType = invoice.invoiceTypeC;
  }

  return (
    <>
      <div>
        <b>Fakturatype:</b> {invoiceType}
      </div>
      <div>
        <b>RVS-status:</b>
        {invoice.dunningStatus === 'NotInDunning' ? (
          <span className="ms-1">{formatDunning(invoice.dunningStatus)}</span>
        ) : (
          <a
            href=""
            title="Se flow"
            onClick={(event) => {
              event.preventDefault();
              showModal(
                'RVS Flow',
                <DunningRelatedInvoices
                  dunningRelatedInvoiceNumber={invoice.dunningRelatedInvoiceNumber}
                  currency={invoice.currency}
                />
              );
            }}
            className="ms-1">
            {formatDunning(invoice.dunningStatus)}
          </a>
        )}
      </div>
      <div>
        <b>For kunde:</b> {invoice.accountNumber}
      </div>
      <div>
        <b>Fakturabalance:</b>{' '}
        {formatAmount(invoice.invoiceBalance, { currency: invoice.currency })}
      </div>
      {invoice.invoiceTypeC !== 'Compensation' && (
        <div>
          <b>Betalingsstatus:</b>
          {invoice.invoiceTypeC === 'WriteOff' && invoice.invoiceBalance ? (
            <span className="text-weight-bold text-warning">
              Beløb afskrevet (RVS-flow):{' '}
              <span
                className="text-danger"
                title={`Beløb: ${writeOffDetailSum}\nMoms: ${writeOffTaxSum}\nTotal: ${
                  writeOffDetailSum + writeOffTaxSum
                }`}>
                {writeOffDetailSum + writeOffTaxSum}
              </span>
            </span>
          ) : (
            paymentStatus
          )}
        </div>
      )}
      <div>
        <b>Forsendelsesstatus:</b>{' '}
        {formatDeliveryStatus(invoice.deliveryMethod, invoice.sentToEdiExStatus)}
      </div>
      <div>
        <b>Forfaldsdato:</b>
        <span
          className={cx({
            'text-weight-bold text-danger':
              invoice.invoiceBalance > 0 && new Date(invoice.dueDate) < new Date(),
          })}>
          {' '}
          {formatDate(invoice.dueDate)}
        </span>
      </div>
      <div>
        <b>Påført tilgodehavende:</b>{' '}
        {formatAmount(invoice.creditBalanceAdjustmentAmount, { currency: invoice.currency })}
      </div>
      <div>
        <b>Interne korrektioner:</b>{' '}
        {formatAmount(invoiceAdjustmentTotal, { currency: invoice.currency })}
      </div>
    </>
  );
}
