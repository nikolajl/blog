import { useDunningRelatedInvoices } from '@/api/invoices';
import { formatCurrency, formatDate } from '@/utils/format';
import { formatReminderType } from '@/utils/format/invoices';
import { addDays } from 'date-fns';
import React from 'react';
import { Badge, Spinner, Table } from 'react-bootstrap';

type Props = {
  dunningRelatedInvoiceNumber: string;
  currency: string;
};

export default function DunningRelatedInvoices({
  dunningRelatedInvoiceNumber,
  currency = 'DKK',
}: Props) {
  const dunningRelatedInvoices = useDunningRelatedInvoices(dunningRelatedInvoiceNumber);

  if (dunningRelatedInvoices.isLoading) {
    return (
      <div className="text-center">
        <Spinner animation="border" />
      </div>
    );
  }

  // order by dueDate desc
  const list = dunningRelatedInvoices.data?.sort((a, b) => (a.dueDate < b.dueDate ? 1 : -1));

  return (
    <Table>
      <thead>
        <tr>
          <th>Frist</th>
          <th>Type</th>
          <th>FakturaNr</th>
          <th>Balance</th>
        </tr>
      </thead>
      <tbody>
        {list?.map((x) =>
          x.extendedDueDaysForDisplay__c > 0 ? (
            <React.Fragment key={x.id}>
              <tr title="Påmindelse uden faktura">
                <td>
                  <Badge>
                    {formatDate(addDays(new Date(x.dueDate), x.extendedDueDaysForDisplay__c))}
                  </Badge>
                </td>
                <td>{formatReminderType(x.reminderTypeEnum)}</td>
                <td> - </td>
                <td> - </td>
              </tr>
              <tr>
                <td>
                  <Badge>{formatDate(x.dueDate)}</Badge>
                </td>
                <td>Oprindelig faktura</td>
                <td>{x.invoiceNumber}</td>
                <td>{formatCurrency(x.balance, { currency })}</td>
              </tr>
            </React.Fragment>
          ) : (
            <tr key={x.id}>
              <td>
                <Badge>{formatDate(x.dueDate)}</Badge>
              </td>
              <td>{formatReminderType(x.reminderTypeEnum)}</td>
              <td>{x.invoiceNumber}</td>
              <td>{formatCurrency(x.balance, { currency })}</td>
            </tr>
          )
        )}
      </tbody>
    </Table>
  );
}
