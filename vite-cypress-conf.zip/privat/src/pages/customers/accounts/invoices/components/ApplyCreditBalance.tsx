import { useGetAccountV2 } from '@/api/accounts';
import { useApplyCreditOnInvoice, useGetInvoice } from '@/api/invoices';
import Button from '@/components/forms/Button';
import { useModal } from '@/components/providers/ModalProvider';
import FormCurrency from '@/components/ui/forms/FormCurrency';
import { formatAmount } from '@/utils/format/currency';
import { yupResolver } from '@hookform/resolvers/yup';
import { Col, Form, Row, Stack } from 'react-bootstrap';
import { FormProvider, useForm } from 'react-hook-form';
import * as yup from 'yup';

type Props = {
  accountNumber: string;
  invoiceId: string;
  creditBalance: number;
  currency?: string;
};

export default function ApplyCreditBalance({
  accountNumber,
  invoiceId,
  creditBalance,
  currency = 'DKK',
}: Props) {
  const schema = yup.object({
    amount: yup
      .number()
      .required()
      .moreThan(0, 'Beløb skal være over 0')
      .max(creditBalance, `Beløb må højst være ${formatAmount(creditBalance, { currency })}`),
  });

  type FormValues = yup.InferType<typeof schema>;

  const form = useForm<FormValues>({
    resolver: yupResolver(schema),
    defaultValues: { amount: 0 },
  });
  const applyCreditOnInvoice = useApplyCreditOnInvoice();
  const { closeModal } = useModal();
  const invoice = useGetInvoice(invoiceId);
  const account = useGetAccountV2(accountNumber);

  const onSubmit = ({ amount }: FormValues) => {
    applyCreditOnInvoice.mutate({
      accountNumber,
      invoiceId,
      amount,
    });
    closeModal();
  };

  const accountCreditBalance = account.data?.metrics?.creditBalance;
  const invoiceBalance = invoice.data?.invoiceBalance;

  return (
    <FormProvider {...form}>
      <Form onSubmit={form.handleSubmit(onSubmit)}>
        <Row>
          <Col>
            <FormCurrency name="amount" currency={currency} />
          </Col>
          <Col>
            <div className="mb-2">
              <div>Faktura balance: {formatAmount(invoiceBalance, { currency })}</div>
              <div>Konto tilgodehavende: {formatAmount(accountCreditBalance, { currency })}</div>
              <b>
                Højest mulig påførsel:{' '}
                {formatAmount(
                  invoiceBalance &&
                    accountCreditBalance &&
                    Math.min(invoiceBalance, accountCreditBalance),
                  { currency }
                )}
              </b>
            </div>
          </Col>
        </Row>
        <Row className="mt-2">
          <Col className="align-right">
            <Stack direction="horizontal" gap={1}>
              <Button variant="outline-primary" className="ms-auto" onClick={() => closeModal()}>
                Luk
              </Button>
              <Button type="submit" variant="success">
                Påfør beløb
              </Button>
            </Stack>
          </Col>
        </Row>
      </Form>
    </FormProvider>
  );
}
