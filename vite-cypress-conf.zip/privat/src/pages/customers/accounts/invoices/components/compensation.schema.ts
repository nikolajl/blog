import * as yup from 'yup';
import { setLocale } from 'yup';
import { CompensationType } from './CompensationTypeSelect';

setLocale({
  mixed: {
    required: '',
  },
});

export const compensationSchema = yup.object({
  effectiveDate: yup.date().required(),
  compensationType: yup.mixed<CompensationType>().required('Der skal vælges en godtgørelseskode'),
  reason: yup.string().nullable(),
  amount: yup.number().min(0.01, 'Beløb skal være 0,01 eller højere').required(),
  accountNumber: yup.string().required(),
  isTaxed: yup.bool().required(),
  ratePlanChargeId: yup.string().required(),
  subscriptionNumber: yup.string().required(),
  isInvoicePaymentProcessed: yup.bool().required(),
  invoiceId: yup.string().required(),
});
export type CompensationSchemaType = yup.InferType<typeof compensationSchema>;
