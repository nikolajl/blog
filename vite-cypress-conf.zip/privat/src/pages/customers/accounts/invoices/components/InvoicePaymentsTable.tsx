import { useGetInvoicePayments } from '@/api/invoices';
import { Account } from '@/api/types/accounts';
import { formatCurrency, formatDate } from '@/utils/format';
import { MakeGenerics, useMatch } from '@tanstack/react-location';
import { Badge, Container, Spinner, Table } from 'react-bootstrap';

type RouteProps = MakeGenerics<{
  Params: {
    ssoId: string;
    accountNumber: string;
    invoiceId?: string;
  };
}>;

type Props = {
  account: Account;
};

export function InvoicePaymentsTable({ account }: Props) {
  const { params } = useMatch<RouteProps>();

  const invoicePayments = useGetInvoicePayments(params.invoiceId ?? '');

  const getPaymentMethod = (): string | null => {
    const { paymentMethodName, paymentMethodCreditCard } = account;

    if (paymentMethodName === 'CreditCard') return paymentMethodCreditCard.cardType;
    return paymentMethodName ?? null;
  };

  // TODO: Use formatPaymentStatus ?
  const displayPaymentStatus = {
    Draft: 'Kladde',
    Processing: 'Gennemføres',
    Processed: 'Gennemført',
    Error: 'Fejl',
    Voided: 'Anulleret af forretningen',
    Canceled: 'Annulleret af kunden',
    Posted: 'Sendt',
  };

  return (
    <>
      <Table striped hover variant="light">
        <thead>
          <tr>
            <th>Betalingsdato</th>
            <th>Beløb</th>
            <th>Betalingsnummer</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {!invoicePayments.isFetching &&
            invoicePayments.data?.map((payment) => (
              <tr key={payment.id}>
                <td>{formatDate(payment.effectiveDate)}</td>
                <td>
                  {formatCurrency(payment.amount)}
                  {account && (
                    <>
                      {' '}
                      <Badge bg={'secondary'}>{getPaymentMethod()}</Badge>
                    </>
                  )}
                </td>
                <td>{payment.paymentNumber}</td>
                <td>{displayPaymentStatus[payment.status]}</td>
              </tr>
            ))}
        </tbody>
      </Table>
      {invoicePayments.isLoading && (
        <Container className="mx-auto text-center">
          <Spinner size="sm" animation="border" />
          Henter data...
        </Container>
      )}
    </>
  );
}
