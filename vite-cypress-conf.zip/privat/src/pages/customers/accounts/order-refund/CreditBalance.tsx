import CurrencyInput from '@/components/forms/CurrencyInput';
import FormDate from '@/components/forms/FormDate';
import { formatCurrency } from '@/utils/format';
import { Form, Table } from 'react-bootstrap';
import cx from 'classnames';
import styles from './RefundOrder.module.scss';
import { addDays } from 'date-fns';
import { useRefundOrdersByAccount } from '@/api/refunds';

type Props = {
  accountNumber: string;
  creditBalance: number;
  creditBalanceRefund?: CreditBalanceRefund;
  onChange: (creditBalanceRefund: CreditBalanceRefund) => void;
};

export type CreditBalanceRefund = {
  isSelected?: boolean;
  isFutureSelected?: boolean;
  effectiveDate: Date | null;
  refundAmount: number | undefined;
  isValid?: boolean;
};

const isValid = (
  isSelected: boolean,
  effectiveDate?: Date,
  isFutureSelected?: boolean,
  refundAmount?: number,
  creditBalance?: number
) => {
  if (isFutureSelected && !effectiveDate) return false;
  return isSelected && !!refundAmount && refundAmount > 0 && refundAmount <= (creditBalance ?? 0);
};

export default function CreditBalance({
  accountNumber,
  creditBalance,
  creditBalanceRefund,
  onChange,
}: Props) {
  const {
    effectiveDate = null,
    isFutureSelected = false,
    isSelected = false,
    refundAmount = creditBalance,
  } = creditBalanceRefund ?? {};

  const existingRefunds = useRefundOrdersByAccount(accountNumber, {
    orderStatus: 'Created',
  });

  const creditBalanceRefunds = existingRefunds.data?.filter(
    (x) => x.sourceType === 'CreditBalance'
  );

  return (
    <>
      <h2 className="text-center mt-2">Tilgodehavende</h2>
      <Table className={'align-middle ' + styles.overflowTable}>
        <thead>
          <tr>
            <th className={styles.paymentNumberWidth}></th>
            <th className={styles.typeWidth}></th>
            <th className={styles.futureDateWidth}></th>
            <th>Status</th>
            <th className={cx(styles.amountWidth, 'text-end')}>Beløb</th>
            <th className={cx(styles.possiblePayoutWidth, 'text-end')}>Muligt at udbetale</th>
            <th className={cx(styles.payoutWidth, 'text-end')}>Til udbetaling</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <Form.Check
                type="checkbox"
                id="credit-balance-check"
                label="Tilgodehavende"
                checked={isSelected}
                disabled={creditBalance <= 0}
                onChange={(event) => {
                  onChange({
                    isSelected: event.target.checked,
                    refundAmount: refundAmount ?? creditBalance,
                    isValid: isValid(
                      event.target.checked,
                      effectiveDate ?? undefined,
                      false,
                      refundAmount,
                      creditBalance
                    ),
                    effectiveDate,
                  });
                }}
              />
            </td>
            <td>
              <Form.Check
                type="checkbox"
                id="future-credit-balance-check"
                label="Fremtidig"
                disabled={!isSelected}
                checked={isFutureSelected}
                onChange={(event) => {
                  onChange({
                    isSelected,
                    refundAmount: creditBalance,
                    isFutureSelected: event.target.checked,
                    effectiveDate: event.target.checked ? effectiveDate : null,
                    isValid: isValid(
                      isSelected,
                      effectiveDate ?? undefined,
                      event.target.checked,
                      refundAmount,
                      creditBalance
                    ),
                  });
                }}
              />
            </td>
            <td>
              <FormDate
                disabled={!isFutureSelected}
                size="sm"
                selected={effectiveDate}
                minDate={addDays(new Date(), 1)}
                placeholderText="Udbetalingsdato"
                onChange={(date) => {
                  const newDate = date instanceof Date ? date : effectiveDate;
                  onChange({
                    effectiveDate: newDate,
                    isFutureSelected,
                    refundAmount: creditBalance,
                    isSelected,
                    isValid: true,
                  });
                }}
                isInvalid={!effectiveDate && isFutureSelected}
              />
            </td>
            <td>
              {creditBalanceRefunds ? `Afventer godk. (${creditBalanceRefunds?.length})` : ''}
            </td>
            <td className="text-end">{formatCurrency(creditBalance)}</td>
            <td className="text-end">{formatCurrency(creditBalance)}</td>
            <td>
              <CurrencyInput
                dataCy="credit-balance-input"
                value={refundAmount}
                onChange={(value) =>
                  onChange({
                    isSelected,
                    refundAmount: value,
                    isValid: isValid(isSelected, undefined, false, value, creditBalance),
                    effectiveDate: effectiveDate ?? null,
                    isFutureSelected: isFutureSelected,
                  })
                }
                isInvalid={
                  isSelected &&
                  isValid(isSelected, undefined, false, refundAmount, creditBalance) === false
                }
                disabled={!isSelected || isFutureSelected}
              />
            </td>
          </tr>
        </tbody>
      </Table>
    </>
  );
}
