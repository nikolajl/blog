import { useAccount } from '@/api/accounts';
import PageLayout from '@/components/layouts/PageLayout';
import { MakeGenerics, useMatch } from '@tanstack/react-location';
import { useState } from 'react';
import { Col, Row } from 'react-bootstrap';
import { GlobalHotKeys } from 'react-hotkeys';
import CreditBalance, { CreditBalanceRefund } from './CreditBalance';
import InvoicePayments, { SelectedPayment } from './InvoicePayments';
import RefundForm from './RefundForm';

type RouteProps = MakeGenerics<{
  Params: {
    ssoId: string;
    accountNumber: string;
  };
}>;

const keyMap = {
  CUSTOMER_OVERVIEW: 'Alt+j',
};

export default function AccountRefundsPage() {
  const { params } = useMatch<RouteProps>();
  const account = useAccount(params.accountNumber);

  const [creditBalanceRefund, setCreditBalanceRefund] = useState<CreditBalanceRefund | undefined>();
  const [selectedPayments, setSelectedPayments] = useState<SelectedPayment[]>([]);

  const hotkeyHandlers = {
    CUSTOMER_OVERVIEW: () =>
      window.location.assign(
        `/Customer/ViewCustomer/${params.ssoId}?accountNumber=${params.accountNumber}`
      ),
  };

  if (!account.data) {
    return null;
  }

  const onSubmitSuccess = () => {
    setCreditBalanceRefund(undefined);
    setSelectedPayments([]);
  };

  return (
    <PageLayout title="Anmod om udbetaling">
      <GlobalHotKeys keyMap={keyMap} handlers={hotkeyHandlers} />
      <h2>{account.data.accountNumber}</h2>
      <Row>
        <Col>
          <CreditBalance
            accountNumber={params.accountNumber}
            creditBalance={account.data.creditBalance}
            creditBalanceRefund={creditBalanceRefund}
            onChange={(x) => {
              console.log('setCreditBalanceRefund', x);
              setCreditBalanceRefund(x);
              setSelectedPayments([]);
            }}
          />
          <InvoicePayments
            accountNumber={params.accountNumber}
            accountId={account.data.id}
            selectedPayments={selectedPayments}
            onChange={(x) => {
              setCreditBalanceRefund(undefined);
              setSelectedPayments(x);
            }}
          />
        </Col>
        <Col md={4}>
          <RefundForm
            creditBalanceRefund={creditBalanceRefund}
            selectedPayments={selectedPayments}
            accountNumber={params.accountNumber}
            account={account.data}
            onSubmitSuccess={onSubmitSuccess}
          />
        </Col>
      </Row>
    </PageLayout>
  );
}
