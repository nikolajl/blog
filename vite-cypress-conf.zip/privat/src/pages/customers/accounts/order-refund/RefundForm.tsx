import { useEffect, useState } from 'react';
import { Col, Form, FormText, Row } from 'react-bootstrap';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { CreateRefundOrder, RefundChannelType } from '@/api/types/refunds';
import { useCreateRefundOrder } from '@/api/refunds';
import Button from '@/components/forms/Button';
import { formatCurrency } from '@/utils/format';
import { CreditBalanceRefund } from './CreditBalance';
import { SelectedPayment } from './InvoicePayments';
import { useForm } from 'react-hook-form';
import { Account } from '@/api/types/accounts';
import Panel from '@/components/ui/Panel';

const schema = yup.object({
  refundChannel: yup.mixed<RefundChannelType>().oneOf(['CreditCard', 'BankTransfer']).required(),
  comment: yup.string(),
  regNr: yup.string().when('refundChannel', {
    is: 'BankTransfer',
    then: (x) => x.length(4).required(),
  }),
  kontoNr: yup.string().when('refundChannel', {
    is: 'BankTransfer',
    then: (x) => x.max(10).required(),
  }),
  noteToCustomer: yup.string().when('refundChannel', {
    is: 'BankTransfer',
    then: (x) => x.max(16),
  }),
});

type FormValues = yup.InferType<typeof schema>;

type Props = {
  accountNumber: string; // TODO: Remove
  account: Account; // TODO: Remove
  creditBalanceRefund?: CreditBalanceRefund;
  selectedPayments: SelectedPayment[];
  onSubmitSuccess: () => void;
};
export default function RefundForm({
  creditBalanceRefund,
  selectedPayments,
  accountNumber, // TODO: Remove
  account, // TODO: Remove
  onSubmitSuccess,
}: Props) {
  const form = useForm<FormValues>({ resolver: yupResolver(schema) });

  const {
    mutate,
    isLoading: isCreateRefundLoading,
    isSuccess: isCreateRefundSuccessful,
  } = useCreateRefundOrder();

  const [customValidation, setCustomValidation] = useState('');
  const selectedRefundType = form.watch('refundChannel');

  const isRefundTypeOptional =
    !creditBalanceRefund?.isSelected &&
    selectedPayments.every((x) => x.payment.paymentType === 'Electronic') &&
    account.paymentMethodCreditCard?.paymentMethodId;

  if (!selectedRefundType && (selectedPayments.length || creditBalanceRefund?.isSelected)) {
    if (isRefundTypeOptional) {
      form.setValue('refundChannel', 'CreditCard');
    } else {
      form.setValue('refundChannel', 'BankTransfer');
    }
  }

  if (selectedRefundType != 'BankTransfer' && creditBalanceRefund?.isSelected) {
    form.setValue('refundChannel', 'BankTransfer');
  }

  const totalAmount = selectedPayments.reduce(
    (r, x) => r + (x.refundAmount ?? 0),
    creditBalanceRefund?.refundAmount ?? 0
  );

  useEffect(() => {
    if (isCreateRefundSuccessful && form.formState.isSubmitSuccessful) {
      form.reset();
      setCustomValidation('');
      onSubmitSuccess();
    }
  }, [onSubmitSuccess, isCreateRefundSuccessful, form]);

  const onSubmit = (values: FormValues) => {
    if (!isRefundTypeOptional && values.refundChannel === 'CreditCard') {
      form.setError('refundChannel', {
        message: 'Kreditkort kan kun vælges når alle valgte betalinger er betalt med kreditkort',
      });
      return;
    }

    if (Object.keys(form.formState.errors).length) {
      return;
    }

    if (
      !selectedPayments.every(
        (x) => x.refundAmount && x.refundAmount > 0 && x.refundAmount <= x.payment.refundableAmount
      )
    ) {
      setCustomValidation('Valgte tilbagebetalinger er ikke alle valide');
      return;
    }

    if (creditBalanceRefund?.isSelected && !creditBalanceRefund?.isValid) {
      setCustomValidation('Valgte tilbagebetalinger er ikke alle valide');
      return;
    }

    /* if (creditBalanceRefund?.isFutureSelected && creditBalanceRefund.effectiveDate === null) {
      setCustomValidation('Fremtidig udbetaling mangler dato');
      return;
    }
 */
    const refundOrders: CreateRefundOrder[] = mapValuesToRefundOrderRequest(
      selectedPayments,
      values,
      creditBalanceRefund,
      account
    );

    mutate({
      accountNumber,
      accountId: account.id,
      refundOrders,
    });
  };

  return (
    <Form className="sticky" onSubmit={form.handleSubmit(onSubmit)} noValidate>
      {
        /* (!!selectedPayments.length || creditBalanceRefund?.isSelected) */ true && (
          <Panel title="Detaljer om udbetaling">
            <Row>
              <Col className="my-1">
                <Form.Check
                  id="refundType-creditCard"
                  type="radio"
                  value="CreditCard"
                  disabled={!isRefundTypeOptional}
                  label="Udbetaling til kreditkort"
                  {...form.register('refundChannel')}
                />
                <Form.Check
                  id="refundType-manual"
                  type="radio"
                  value="BankTransfer"
                  label="Udbetaling til bankkonto"
                  {...form.register('refundChannel')}
                />
                <FormText>{form.formState.errors.refundChannel?.message}</FormText>
              </Col>
            </Row>
            <Row>
              <Col className="my-1" md={3}>
                <Form.Control
                  type="text"
                  placeholder="Reg.nr."
                  isInvalid={form.formState.errors['regNr'] !== undefined}
                  disabled={selectedRefundType !== 'BankTransfer'}
                  {...form.register('regNr')}
                />
              </Col>
            </Row>
            <Row>
              <Col className="my-1" md={6}>
                <Form.Control
                  type="text"
                  placeholder="Konto nr."
                  isInvalid={form.formState.errors['kontoNr'] !== undefined}
                  disabled={selectedRefundType !== 'BankTransfer'}
                  {...form.register('kontoNr')}
                />
              </Col>
            </Row>
            <Row>
              <Col className="my-1" md={8}>
                <Form.Control
                  type="text"
                  placeholder="Evt. besked til kunden (16 tegn)"
                  maxLength={16}
                  disabled={selectedRefundType !== 'BankTransfer'}
                  {...form.register('noteToCustomer')}
                />
              </Col>
            </Row>
            <Row>
              <Col className="my-1">
                <Form.Control
                  as="textarea"
                  placeholder="Kommentar (400 tegn)"
                  rows={5}
                  {...form.register('comment')}
                />
              </Col>
            </Row>
            <Row>
              <Col className="my-1">
                <p>
                  Beløb til refusion: <strong>{formatCurrency(totalAmount)}</strong>
                </p>
              </Col>
              <Col className="text-end">
                <div>{customValidation}</div>
                <Button
                  variant="outline-success"
                  type="submit"
                  disabled={!(!!selectedPayments.length || creditBalanceRefund?.isSelected)}
                  loading={isCreateRefundLoading}>
                  Send anmodning
                </Button>
              </Col>
            </Row>
          </Panel>
        )
      }
    </Form>
  );
}

function mapValuesToRefundOrderRequest(
  selectedPayments: SelectedPayment[],
  values: FormValues,
  creditBalanceRefund: CreditBalanceRefund | undefined,
  account: Account
) {
  const refundOrders: CreateRefundOrder[] = selectedPayments.map(
    ({ payment, refundAmount = 0 }) => ({
      comment: values.comment,
      noteToCustomer: values.noteToCustomer,
      paymentNumber: payment.paymentNumber,
      paymentId: payment.paymentId,
      invoiceNumber: payment.invoiceNumber,
      invoiceId: payment.invoiceId,
      refundChannel: values.refundChannel,
      regNr: values.regNr,
      kontoNr: values.kontoNr,
      amount: refundAmount,
      electronicPaymentMethodId: null,
      sourceType: 'Payment',
      effectiveDate: null,
    })
  );

  if (creditBalanceRefund) {
    refundOrders.push({
      comment: values.comment,
      noteToCustomer: values.noteToCustomer,
      refundChannel: values.refundChannel,
      amount: creditBalanceRefund.isFutureSelected ? null : creditBalanceRefund.refundAmount ?? 0,
      electronicPaymentMethodId: account.paymentMethodCreditCard?.paymentMethodId,
      sourceType: 'CreditBalance',
      regNr: values.regNr,
      kontoNr: values.kontoNr,
      refundFullAmount: creditBalanceRefund.isFutureSelected,
      effectiveDate: creditBalanceRefund.effectiveDate,
    });
  }
  return refundOrders;
}
