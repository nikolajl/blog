import FormDate from '@/components/forms/FormDate';
import { Col, Form, Row, Spinner, Table } from 'react-bootstrap';
import styles from './RefundOrder.module.scss';
import cx from 'classnames';
import { InvoicePayment, InvoicePaymentView } from '@/api/types/refunds';
import { useRefundInvoicePayments, useRefundOrdersByAccount } from '@/api/refunds';
import { addMonths } from 'date-fns';
import { useCallback, useState } from 'react';
import CurrencyInput from '@/components/forms/CurrencyInput';
import { formatCurrency, formatDate } from '@/utils/format';

type Props = {
  accountNumber: string;
  accountId?: string;
  selectedPayments: SelectedPayment[];
  onChange: (selectedPayments: SelectedPayment[]) => void;
};
export default function InvoicePayments({
  accountNumber,
  accountId,
  selectedPayments,
  onChange,
}: Props) {
  const [fromDate, setFromDate] = useState<Date | null>(addMonths(new Date(), -1));
  const [toDate, setToDate] = useState<Date | null>(new Date());

  const invoicePayments = useRefundInvoicePayments(accountId, { fromDate, toDate }); //"K13444363"
  const { data: invoicePaymentsData } = invoicePayments;
  const isLoading = invoicePayments.isLoading || !accountId;
  const existingRefunds = useRefundOrdersByAccount(accountNumber, {
    orderStatus: 'Created',
  });

  const payments = invoicePaymentsData?.map((invoicePayment) => ({
    ...invoicePayment,
    refunds: existingRefunds.data?.filter(
      (x) =>
        x.paymentNumber === invoicePayment.paymentNumber &&
        x.invoiceNumber === invoicePayment.invoiceNumber
    ),
    refundAmount: selectedPayments.find(
      (x) =>
        x.payment.paymentNumber === invoicePayment.paymentNumber &&
        x.payment.invoiceNumber === invoicePayment.invoiceNumber
    )?.refundAmount,
    isSelected: !!selectedPayments.find(
      (x) =>
        x.payment.paymentNumber === invoicePayment.paymentNumber &&
        x.payment.invoiceNumber === invoicePayment.invoiceNumber
    )?.isSelected,
  }));

  const sortByDateDesc = (a: InvoicePayment, b: InvoicePayment): number => {
    return a.paymentEffectiveDate < b.paymentEffectiveDate ? 1 : -1;
  };

  const handleChange = useCallback(
    (event: SelectedPayment) => {
      if (event.isSelected) {
        const existing = selectedPayments.find(
          (x) =>
            x.payment.paymentNumber === event.payment.paymentNumber &&
            x.payment.invoiceNumber === event.payment.invoiceNumber
        );
        if (existing) {
          onChange(selectedPayments.map((x) => (x === existing ? event : existing)));
        } else {
          onChange([...selectedPayments, event]);
        }
      } else {
        onChange(
          selectedPayments.filter(
            (x) =>
              !(
                x.payment.paymentNumber === event.payment.paymentNumber &&
                x.payment.invoiceNumber === event.payment.invoiceNumber
              )
          )
        );
      }
    },
    [selectedPayments, onChange]
  );

  return (
    <>
      <Row>
        <h2 className="text-center mt-2">Betalinger</h2>
        <Col>
          <div className="d-flex">
            <div style={{ width: 125 }}>
              <FormDate
                size="sm"
                placeholderText="Fra dato"
                selected={fromDate}
                maxDate={toDate}
                onChange={(date) => date instanceof Date && setFromDate(date)}
              />
            </div>
            <div className="align-self-center mx-2">-</div>
            <div style={{ width: 125 }}>
              <FormDate
                size="sm"
                selected={toDate}
                minDate={fromDate}
                placeholderText="Til dato"
                onChange={(date) => date instanceof Date && setToDate(date)}
              />
            </div>
          </div>
        </Col>
      </Row>
      <Table responsive className="align-middle">
        <thead>
          <tr>
            <th className={styles.paymentNumberWidth}></th>
            <th className={styles.typeWidth}>Type af indbetaling</th>
            <th className={styles.appliedWidth}>Påført</th>
            <th className={styles.dateWidth}>Dato</th>
            <th>Status</th>
            <th className={cx(styles.amountWidth, 'text-end')}>Beløb</th>
            <th className={cx(styles.possiblePayoutWidth, 'text-end')}>Muligt at udbetale</th>
            <th className={cx(styles.payoutWidth, 'text-end')}>Til udbetaling</th>
          </tr>
        </thead>
        {isLoading ? (
          <tbody>
            <tr>
              <td colSpan={8} align="center">
                <Spinner animation="border" />
              </td>
            </tr>
          </tbody>
        ) : (
          <tbody>
            {payments?.sort(sortByDateDesc).map((x) => (
              <RefundRow
                key={`${x.paymentNumber}-${x.invoiceNumber}`}
                payment={x}
                onchange={handleChange}
                refundAmount={x.refundAmount}
                isSelected={x.isSelected}
              />
            ))}
          </tbody>
        )}
      </Table>
    </>
  );
}

export type SelectedPayment = {
  isValid: boolean;
  isSelected: boolean;
  refundAmount?: number;
  payment: InvoicePaymentView;
};

type RefundRowProps = {
  payment: InvoicePaymentView;
  onchange: (event: SelectedPayment) => void;
  isSelected: boolean;
  refundAmount?: number;
};

const RefundRow = ({ payment, onchange, refundAmount, isSelected }: RefundRowProps) => {
  const isValid =
    isSelected && !!refundAmount && refundAmount > 0 && refundAmount <= payment.refundableAmount;

  return (
    <tr>
      <td>
        <Form.Check
          value={payment.paymentNumber}
          id={`${payment.paymentNumber}-${payment.invoiceNumber}`}
          label={payment.paymentNumber}
          checked={isSelected}
          disabled={payment.refundableAmount <= 0}
          onChange={(event) => {
            onchange({
              isSelected: event.target.checked,
              isValid,
              payment,
              refundAmount: refundAmount ?? payment.refundableAmount,
            });
          }}
        />
      </td>
      <td>{payment.paymentType === 'External' ? 'Alm. indbetaling' : 'Kreditkort'}</td>
      <td>
        <a href={`/Invoice/InvoiceDetails/${payment.invoiceId}`}>{payment.invoiceNumber}</a>
      </td>
      <td>{formatDate(payment.paymentEffectiveDate)}</td>
      <td>{payment.refunds?.length ? `Afventer godk. (${payment.refunds.length})` : ''}</td>
      <td className={cx(styles.amountWidth, 'text-end')}>{formatCurrency(payment.amount)}</td>
      <td className="text-end">{formatCurrency(payment.refundableAmount)}</td>
      <td>
        <CurrencyInput
          disabled={!isSelected}
          value={refundAmount ?? payment.refundableAmount}
          onChange={(value: number | undefined): void => {
            onchange({
              isSelected,
              isValid,
              payment,
              refundAmount: value,
            });
          }}
          isInvalid={isSelected && refundAmount !== undefined ? !isValid : undefined}
        />
      </td>
    </tr>
  );
};
