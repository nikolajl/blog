import { useQuarantines } from '@/api/quarantines';
import Panel from '@/components/ui/Panel';
import { formatDate } from '@/utils/format';
import { ListGroup, ListGroupItem, Row, Spinner } from 'react-bootstrap';

type Props = {
  ssoId: string;
};

export default function QuarantinePanel({ ssoId }: Props) {
  const { data, isLoading, failureCount } = useQuarantines(ssoId);

  if (isLoading)
    return (
      <Panel title="Kundekarantæne(r)" className="col-6">
        <Spinner animation="border" size="sm" /> Henter Kundekarantæner ({failureCount}. forsøg)
      </Panel>
    );

  return (
    <Panel title="Kundekarantæne(r)" className="col-6">
      {data ? (
        <ListGroup>
          {data?.quarantines.map((quarantine, index) => (
            <ListGroupItem key={quarantine.Identifier + index}>
              <Row>
                <b>{quarantine.Identifier}</b>
                <span>{quarantine.BrandEnumString}</span>
                <span>Beskrivelse: {quarantine.Description}</span>
                <span>Udløbsdato: {formatDate(quarantine.ExpireDate)}</span>
              </Row>
            </ListGroupItem>
          ))}
        </ListGroup>
      ) : (
        <small className="gray">Ingen karantæner</small>
      )}
    </Panel>
  );
}
