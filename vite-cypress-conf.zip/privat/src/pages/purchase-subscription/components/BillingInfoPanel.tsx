import { useGetAccountV2 } from '@/api/accounts';
import Panel from '@/components/ui/Panel';
import { formatFullAddressFromBillToContactV2 } from '@/utils/format';
import { useEffect } from 'react';
import { Spinner } from 'react-bootstrap';
import { useFormContext } from 'react-hook-form';

type Props = {
  accountNumber: string;
};

export default function BillingInfoPanel({ accountNumber }: Props) {
  const account = useGetAccountV2(accountNumber);

  const form = useFormContext();
  useEffect(() => {
    if (account.data) {
      form.setValue('accountType', account.data.basicInfo?.accountTypeC);
      const billingAddress = {
        cvr: account.data.billToContact?.cvrC ?? undefined,
        companyName: account.data.billToContact?.companyNameC ?? undefined,
        coName: account.data.billToContact?.coNameC ?? undefined,
        customerReference: account.data.basicInfo?.customerReferenceC ?? undefined,
        email: account.data.billToContact?.personalEmail ?? undefined,
        firstName: account.data.billToContact?.firstName ?? undefined,
        lastName: account.data.billToContact?.lastName ?? undefined,
        phonePrimary: account.data.billToContact?.phonePrimaryC ?? undefined,
        phoneSecondary: account.data.billToContact?.phoneSecondaryC ?? undefined,
      };

      if (account.data.billToContact?.addressPointC) {
        if (account.data.billToContact.postboxC) {
          form.setValue('billingAddressType', 'Postbox');
          form.setValue('billingAddress', {
            ...billingAddress,
            masterAddressPoint: account.data.billToContact?.addressPointC,
            poBox: account.data.billToContact?.postboxC,
          });
        } else if (
          account.data.billToContact.countryCodeC &&
          account.data.billToContact.countryCodeC !== 'DK'
        ) {
          form.setValue('billingAddressType', 'ForeignAddress');
          form.setValue('billingAddress', {
            ...billingAddress,
            addressLine1: account.data.billToContact.foreignAddress1C,
            addressLine2: account.data.billToContact.foreignAddress2C,
            addressLine3: account.data.billToContact.foreignAddress3C,
            addressLine4: account.data.billToContact.foreignAddress4C,
            country: account.data.billToContact.countryCodeC,
          });
        } else {
          form.setValue('billingAddressType', 'DkAddress');
          form.setValue('billingAddress', {
            ...billingAddress,
            masterAddressPoint: account.data.billToContact?.addressPointC,
            houseFloor: account.data.billToContact?.floorC,
            houseSide: account.data.billToContact?.sideC,
            internalLocation: account.data.billToContact.address2,
          });
        }
      }
    }
  }, [account.data]);

  if (account.data?.billToContact) {
    const {
      address1,
      foreignAddress1C,
      postboxC,
      zipCode,
      city,
      firstName,
      lastName,
      phonePrimaryC,
      phoneSecondaryC,
      personalEmail,
    } = account.data.billToContact;

    return (
      <Panel title="Betalingsoplysninger" className="col-6">
        {account.data && (
          <>
            {firstName && lastName && (
              <div className="mt-1">
                <b>Navn:</b> {firstName} {lastName}
              </div>
            )}
            {(address1 || foreignAddress1C || postboxC) && (
              <div>
                <b>Adresse:</b> {formatFullAddressFromBillToContactV2(account.data.billToContact)}
              </div>
            )}
            {zipCode && city && (
              <div>
                <b>By:</b> {zipCode} {city}
              </div>
            )}
            {personalEmail && (
              <div>
                <b>Email:</b> {personalEmail}
              </div>
            )}
            {phonePrimaryC && (
              <div>
                <b>Telefon:</b> {phonePrimaryC}
              </div>
            )}
            {phoneSecondaryC && (
              <div className="mb-1">
                <b>Telefon (sek.):</b> {phoneSecondaryC}
              </div>
            )}
          </>
        )}
      </Panel>
    );
  }

  return (
    <Panel title="Betalingsoplysninger" className="col-6">
      <Spinner animation="border" size="sm" /> Henter betalersoplysninger...
    </Panel>
  );
}
