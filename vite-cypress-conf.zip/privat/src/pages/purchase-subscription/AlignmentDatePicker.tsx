import FormDate from '@/components/forms/FormDate';
import { formatDate } from '@/utils/format';
import { useFormContext } from 'react-hook-form';

type Props = {
  disabled?: boolean;
  minDate?: Date;
  maxDate?: Date;
};
export default function AlignmentDatePicker({ minDate, maxDate, disabled }: Props) {
  const form = useFormContext();

  const [alignmentDate, orderEffectiveDate] = form.watch(['alignmentDate', 'orderEffectiveDate']);

  if (orderEffectiveDate)
    return (
      <div>
        <div>Faktura Til og med deaktiveret for året ud (kampagner)</div>
        <div>Abonnementets effektive startdato {formatDate(orderEffectiveDate)}</div>
      </div>
    );

  return (
    <FormDate
      disabled={disabled}
      minDate={minDate}
      maxDate={maxDate}
      onChange={(date) => form.setValue('alignmentDate', date ?? undefined)}
      selected={alignmentDate}
      placeholderText="Faktura til og med"
    />
  );
}
