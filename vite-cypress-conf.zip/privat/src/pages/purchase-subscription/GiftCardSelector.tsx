import { Col, Form, FormControl, FormLabel, Row, Spinner } from 'react-bootstrap';
import { useState } from 'react';
import cx from 'classnames';
import { BillingPeriodAlignment, Product, ProductRatePlan } from '@/api/types/catalog';
import FormDate from '@/components/forms/FormDate';
import Button from '@/components/forms/Button';
import Tooltip from '@/components/ui/Tooltip';
import { formatCurrency, formatDate } from '@/utils/format';
import { productHasPrint, useBasket } from './basket/basket.hooks';
import { useProductCatalog } from '@/api/catalog';
import { useGetGiftCard } from '@/api/giftcard';
import { useNextDeliveryDate } from '@/api/distribution';

type Props = {
  disabled?: boolean;
};
export default function GiftCardSelector({ disabled }: Props) {
  const [giftCardCode, setGiftCardCode] = useState('');
  const [startDate, setStartDate] = useState<Date | undefined>();
  const [billingPeriodAlignment, setBillingPeriodAlignment] =
    useState<BillingPeriodAlignment>('AlignToCharge');

  const { addProductToBasket, brand, basket } = useBasket();
  const productCatalog = useProductCatalog();
  const giftCard = useGetGiftCard(giftCardCode);
  const nextDeliveryDate = useNextDeliveryDate();
  const [giftCardProductRatePlan, brandEnumString] = findProductRatePlan(
    productCatalog.data,
    giftCard.data?.redeemGiftCardProductRatePlanId
  );

  const isInvalidGiftCardCode = !!(giftCardCode && giftCard.isFetched && !giftCardProductRatePlan);
  const isDisabled =
    disabled ||
    !(
      giftCard.data &&
      giftCard.data.status === 'Active' &&
      new Date() < new Date(giftCard.data.expiresAt) &&
      giftCardProductRatePlan &&
      billingPeriodAlignment &&
      startDate &&
      (!brand || brandEnumString === brand) &&
      !basket.some((x) => x.type === 'product' && x.giftCard?.id === giftCard.data.id)
    );

  const addToBasket = () => {
    if (
      giftCard.data &&
      giftCard.data.status === 'Active' &&
      giftCardProductRatePlan &&
      billingPeriodAlignment &&
      startDate &&
      brandEnumString
    ) {
      addProductToBasket(
        giftCardProductRatePlan,
        brandEnumString,
        billingPeriodAlignment,
        startDate,
        undefined,
        'Redeem',
        giftCard.data
      );
    }
    // TODO: clear form.
  };

  const billingPeriodAlignmentOptions = [
    {
      id: 'bpa-charge',
      value: 'AlignToCharge' as BillingPeriodAlignment,
      label: 'Startdato',
      tooltip: 'Basis produkt tilpasses IKKE, men faktureres en hel periode',
    },
    {
      id: 'bpa-term',
      value: 'AlignToTerm' as BillingPeriodAlignment,
      label: 'Abonnement',
      tooltip: 'Basis produkt tilpasses abonnementsperiode',
    },
  ];

  const minStartDate =
    giftCardProductRatePlan && productHasPrint(giftCardProductRatePlan)
      ? nextDeliveryDate.data
      : new Date();

  return (
    <div>
      <Row>
        <Col>
          <FormControl
            onBlur={(e) => setGiftCardCode(e.target.value.trim())}
            type="text"
            className="required"
            placeholder="Indtast gavekort indløsningskode"
            isInvalid={isInvalidGiftCardCode}
          />
          <div className="my-2">
            <FormDate
              className="required"
              placeholderText="Startdato"
              minDate={minStartDate}
              selected={startDate ?? null}
              onChange={(date) => setStartDate(date ?? undefined)}
              disabled={!giftCardProductRatePlan || disabled}
            />
          </div>
          <FormLabel>Fakturatilpasning</FormLabel>
          {billingPeriodAlignmentOptions.map((option) => {
            return (
              <Form.Check type="radio" id={option.id} key={option.value}>
                <Form.Check.Label>{option.label}</Form.Check.Label>
                <Form.Check.Input
                  type={'radio'}
                  checked={billingPeriodAlignment === option.value}
                  onChange={() => setBillingPeriodAlignment(option.value)}
                  value={option.value}
                />
                <Tooltip>{option.tooltip}</Tooltip>
              </Form.Check>
            );
          })}
        </Col>
        <Col>
          {giftCard.isFetching ? (
            <Spinner animation="border" />
          ) : (
            <>
              <div>
                <b>
                  Gavekort:
                  {giftCard.data?.status && (
                    <span
                      className={cx('ms-1', {
                        'text-danger': giftCard.data.status === 'Redeemed',
                      })}>
                      {giftCardStatus[giftCard.data.status]}
                    </span>
                  )}
                </b>
              </div>
              <div>{giftCardProductRatePlan?.name}</div>
              <div>Værdi: {formatCurrency(giftCard.data?.amount ?? 0)}</div>
              <div>Udløber: {formatDate(giftCard.data?.expiresAt)}</div>
              <ProductRatePlanDetails productRatePlan={giftCardProductRatePlan} />
            </>
          )}
        </Col>
      </Row>
      <Row>
        <Col className="d-flex justify-content-end">
          <Button
            disabled={isDisabled}
            type="button"
            variant="outline-success"
            onClick={addToBasket}
            className="float-right">
            Tilføj til kurv
          </Button>
        </Col>
      </Row>
    </div>
  );
}

const giftCardStatus = {
  Active: 'Aktivt',
  Redeemed: 'Allerede indløst',
  Reserved: 'Reserveret',
};

function findProductRatePlan(
  catalog?: Product[],
  ratePlanId?: string
): [ProductRatePlan?, string?] {
  if (!catalog) return [];
  if (!ratePlanId) return [];

  for (const product of catalog) {
    for (const ratePlan of product.productRatePlans) {
      if (ratePlan.productRatePlanId === ratePlanId) return [ratePlan, product.brandEnumString];
    }
  }

  return [];
}

type ProductRatePlanDetailsProps = {
  productRatePlan?: ProductRatePlan;
};
function ProductRatePlanDetails({ productRatePlan }: ProductRatePlanDetailsProps) {
  return (
    <div className="mt-2 border-top">
      <div>
        <strong>Samlet pris ved køb</strong>
      </div>
      <div>
        <span>
          {productRatePlan
            ? formatCurrency(productRatePlan.pricing.upFrontPrice)
            : formatCurrency(0)}
          <i className="gray">{`(Heraf moms ${
            productRatePlan
              ? formatCurrency(productRatePlan.pricing.upFrontTaxAmount)
              : formatCurrency(0)
          })`}</i>
        </span>
      </div>
      <div>
        <div>
          <strong>Samlet pris pr. efterfølgende betaling</strong>
        </div>
        <span>
          {productRatePlan
            ? formatCurrency(productRatePlan.pricing.recurringPrice)
            : formatCurrency(0)}
          <i className="gray">{`(Heraf moms ${
            productRatePlan
              ? formatCurrency(productRatePlan.pricing.recurringTaxAmount)
              : formatCurrency(0)
          })`}</i>
        </span>
      </div>
      {productRatePlan?.description && (
        <div>
          <div>
            <strong>Beskrivelse</strong>
          </div>
          <span>{productRatePlan.description}</span>
        </div>
      )}
      {productRatePlan && (
        <div>
          <strong>Features</strong>
          <ul>
            {productRatePlan.accessFeatures
              .sort((a, b) => a.accessFeatureName.localeCompare(b.accessFeatureName))
              .map(({ accessFeatureName }, index) => (
                <li key={accessFeatureName + index}>{accessFeatureName}</li>
              ))}
          </ul>
        </div>
      )}
    </div>
  );
}
