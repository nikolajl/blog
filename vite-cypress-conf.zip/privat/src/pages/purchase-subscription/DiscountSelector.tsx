import { Col, Form, InputGroup, Row } from 'react-bootstrap';
import Button from '@/components/forms/Button';
import FormDate from '@/components/forms/FormDate';
import { useState } from 'react';
import { addDays } from 'date-fns';
import { useBasket } from './basket/basket.hooks';
import Select from 'react-select';
import NumberFormat, { NumberFormatValues } from 'react-number-format';

type DimensionOption = {
  name: string;
};
type Props = {
  disabled?: boolean;
};

export default function DiscountSelector({ disabled }: Props) {
  const [consecutive, setConsecutive] = useState(false);
  const [amount, setAmount] = useState<number | 0>();
  const [fromDate, setFromDate] = useState<Date | null>(null);
  const [toDate, setToDate] = useState<Date | null>(null);

  const {
    addDiscountToBasket,
    basketHasNoProductItems,
    getAllDimensions,
    getBasketDiscounts,
    getAllProductItems,
  } = useBasket();

  const dimensions: DimensionOption[] | undefined = getAllDimensions().map((d) => {
    return {
      name: d,
    };
  });

  const earliestBasketProductStartDate = () => {
    const products = getAllProductItems();
    if (products) {
      const date = products.sort(
        (a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime()
      )[0]?.startDate;
      return date;
    } else {
      return undefined;
    }
  };

  const [dimension, setDimension] = useState<DimensionOption | null>(
    dimensions.length === 1 ? dimensions[0] : null
  );

  const onAddDiscount = () => {
    amount &&
      fromDate &&
      (consecutive || toDate) &&
      dimension &&
      addDiscountToBasket(amount, dimension.name, fromDate, consecutive, toDate ?? undefined);

    // reset:
    setDimension(null);
    setFromDate(null);
    setToDate(null);
    setAmount(0);
    setConsecutive(false);
  };

  const isAddDiscountDisabled =
    disabled ||
    !amount ||
    !fromDate ||
    (!consecutive && !toDate) ||
    !dimension ||
    basketHasNoProductItems() ||
    getBasketDiscounts().length > 0;

  return (
    <div>
      <Row>
        <Col>
          <div className="w-50 my-1">
            <InputGroup>
              <Form.Control
                value={amount}
                onValueChange={(values: NumberFormatValues) => {
                  // max 100% - (max prop does not work with NumberFormat)
                  let v = values.floatValue && values.floatValue > 100 ? 100 : values.floatValue;
                  v = v && v < 0 ? 0 : v; // only positive numbers
                  setAmount(v);
                }}
                as={NumberFormat}
                decimalSeparator=","
                decimalScale={2}
                placeholder="Rabat"
                step={'.01'}
              />
              <InputGroup.Text>%</InputGroup.Text>
            </InputGroup>
          </div>
          <div className="my-1">
            <Select
              placeholder="Vælg dimension"
              value={dimension}
              options={dimensions ?? []}
              onChange={(value) => setDimension(value)}
              noOptionsMessage={() => 'Ingen produkter i kurven'}
              getOptionLabel={(d) => d.name}
              getOptionValue={(d) => d.name}
            />
          </div>
          <div className="my-2">
            <FormDate
              disabled={!earliestBasketProductStartDate()}
              className="required"
              placeholderText="Vælg startdato"
              selected={fromDate}
              startDate={fromDate}
              minDate={earliestBasketProductStartDate()}
              onChange={(date) => setFromDate(date)}
            />
          </div>
          <div className="my-2">
            <Form.Check
              checked={consecutive}
              label="Fortløbende"
              onChange={(value) => {
                setConsecutive(value.target.checked);
                setToDate(null);
              }}
            />
          </div>
          <div className="my-2">
            <FormDate
              disabled={consecutive}
              placeholderText={consecutive ? 'Fortløbende' : 'Vælg slutdato'}
              selected={toDate}
              minDate={fromDate ? addDays(fromDate, 1) : null}
              onChange={(date) => setToDate(date)}
            />
          </div>
        </Col>
        <Col></Col>
        <div className="d-flex justify-content-end">
          <Button
            disabled={isAddDiscountDisabled}
            type="button"
            variant="outline-success"
            onClick={onAddDiscount}>
            Tilføj rabat til kurv
          </Button>
        </div>
      </Row>
    </div>
  );
}
