import { InputText } from '@/components/forms/InputText';
import Panel from '@/components/ui/Panel';
import { ButtonGroup, Col, Form, Row } from 'react-bootstrap';
import { useFormContext } from 'react-hook-form';
import cx from 'classnames';
import AddressSelect from '@/components/forms/AddressSelect';
import { DistributionAddress } from '@/api/types/distribution';
import { fetchLookUpAddress } from '@/api/distribution';
import { DawaAutoCompleteResult } from '@/api/dawa';
import Button from '@/components/forms/Button';
import PostnrBySelect from '@/components/forms/PostnrBySelect';
import CountriesSelect from '@/components/forms/CountriesSelect';
import { itemHasPrint } from './basket/basket.hooks';
import { BasketItemData } from './basket/BasketItemModels';
import { useAuthContext } from '@/components/providers/AuthProvider';
import { AxiosError } from 'axios';
import { useToastProvider } from '@/components/messages/ToastProvider';

async function fetchAddress(vejnavn: string, husnr: string, postnr: string) {
  const list = await fetchLookUpAddress(vejnavn, postnr);
  if (list && list.length) {
    const match = list.filter((x) => `${x.houseNumber}${x.houseLetter ?? ''}` === husnr).pop();
    return match;
  }
}

export default function BillingAddressPanel() {
  const { showError } = useToastProvider();
  const auth = useAuthContext();
  const hasSpaBusinessExtras = auth?.user.flags['SpaBusinessExtras'];

  const form = useFormContext();

  const [basket, accountType, paymentMethod, addressType] = form.watch([
    'basket',
    'accountType',
    'paymentMethod',
    'billingAddressType',
  ]);

  if (!basket) return null;

  const onAddressChange = async (value: DawaAutoCompleteResult | null) => {
    // Clear address
    if (!value) {
      form.setValue('billingAddress.masterAddressPoint', null, { shouldValidate: true });
      return;
    }

    const distribution = await fetchAddress(
      value.data.vejnavn,
      value.data.husnr,
      value.stormodtagerpostnr ? value.data.stormodtagerpostnr : value.data.postnr
    ).catch((err: AxiosError) => {
      showError(err.message, err.name);
    });

    if (distribution) {
      form.setValue('billingAddress.masterAddressPoint', distribution.masterAddressPointID, {
        shouldValidate: true,
      });
      form.setValue('billingAddress.houseFloor', value.data.etage);
      form.setValue('billingAddress.houseSide', value.data.dør);
    }
  };

  const onPostcodeChange = async (value: DistributionAddress | null) => {
    if (!value) {
      form.setValue('billingAddress.masterAddressPoint', null, { shouldValidate: true });
      return;
    }

    const distribution = await fetchAddress('Postboks', '1', value.zipCode).catch(
      (err: AxiosError) => {
        showError(err.message, err.name);
      }
    );
    if (distribution) {
      form.setValue('billingAddress.masterAddressPoint', distribution.masterAddressPointID, {
        shouldValidate: true,
      });
    }
  };

  const isAddressRequired =
    paymentMethod === 'PaymentSlip' || basket.some((x: BasketItemData) => itemHasPrint(x));
  const isPhoneRequired = paymentMethod === 'MobilePay';
  const isEmailRequired =
    paymentMethod === 'BankTransfer' ||
    (form.getValues().billingAddress?.addBillingAddressEmailUserBinding ?? false);
  const isEanRequired = paymentMethod === 'EAN';
  const isNameRequired = accountType === 'Consumer';

  return (
    <Panel title="Betaleradresse">
      <Row className="mb-1">
        <Col>
          <InputText name="billingAddress.customerReference" label="Kundereference" />
        </Col>
      </Row>
      {isEanRequired &&
        (basket.length === 0 ||
          !basket.every((x: BasketItemData) => x.type === 'product' && x.ratePlan.isTrial)) && (
          <Row className="mb-1">
            <Col>
              <InputText name="billingAddress.ean" label="EAN" required />
            </Col>
          </Row>
        )}
      <Row className="mb-1">
        <Col>
          <InputText name="billingAddress.firstName" label="Fornavn" required={isNameRequired} />
        </Col>
      </Row>
      <Row className="mb-1">
        <Col>
          <InputText name="billingAddress.lastName" label="Efternavn" required={isNameRequired} />
        </Col>
      </Row>

      {accountType === 'Business' && (
        <>
          <Row className="mb-1">
            <Col>
              <InputText name="billingAddress.companyName" label="Firmanavn" required />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              {addressType === 'ForeignAddress' ? (
                <InputText name="billingAddress.vat" label="VAT" />
              ) : (
                <InputText name="billingAddress.cvr" label="CVR" />
              )}
            </Col>
          </Row>
        </>
      )}
      <Row className="mb-1">
        <Col>
          <InputText name="billingAddress.email" label="E-mail" required={isEmailRequired} />
        </Col>
        {accountType === 'Business' && hasSpaBusinessExtras && (
          <Col xs={3}>
            <Form.Check
              type="checkbox"
              id="fake-sso-check"
              label="Brug dummy SSO ID"
              {...form.register('billingAddress.useDummySsoId')}
            />
            <Form.Check
              type="checkbox"
              id="billingAddress-userAccess-check"
              label="Tildel brugeradgang"
              {...form.register('billingAddress.addBillingAddressEmailUserBinding')}
            />
          </Col>
        )}
      </Row>
      <Row className="mb-1">
        <Col>
          <InputText
            name="billingAddress.phonePrimary"
            label="Telefon"
            required={isPhoneRequired}
          />
        </Col>
        <Col>
          <InputText name="billingAddress.phoneSecondary" label="Telefon (sek.)" />
        </Col>
      </Row>
      <ButtonGroup size="sm" className="my-2">
        {!isAddressRequired && (
          <Button
            variant="outline-secondary"
            tabIndex={-1}
            active={addressType === 'NoAddress'}
            onClick={() => form.setValue('billingAddressType', 'NoAddress')}>
            Ingen adresse
          </Button>
        )}
        <Button
          variant="outline-secondary"
          tabIndex={-1}
          active={addressType === 'DkAddress'}
          onClick={() => {
            form.setValue('billingAddressType', 'DkAddress');
            // form.setValue('billingAddress.vat', '');
            form.resetField('billingAddress.vat');
          }}>
          Dansk adresse
        </Button>
        <Button
          variant="outline-secondary"
          tabIndex={-1}
          active={addressType === 'Postbox'}
          onClick={() => form.setValue('billingAddressType', 'Postbox')}>
          Postboks
        </Button>
        <Button
          variant="outline-secondary"
          tabIndex={-1}
          active={addressType === 'ForeignAddress'}
          onClick={() => {
            form.setValue('billingAddressType', 'ForeignAddress');
            //form.setValue('billingAddress.cvr', '');
            form.resetField('billingAddress.cvr');
          }}>
          Udenlandsk adresse
        </Button>
      </ButtonGroup>

      {addressType === 'NoAddress' && isAddressRequired && (
        <Row className="mb-1">
          <Col>Adresse skal angives</Col>
        </Row>
      )}

      {addressType === 'DkAddress' && (
        <>
          <Row className="mb-1">
            <Col>
              <AddressSelect
                name="billingAddress.masterAddressPoint"
                label="Indtast adresse (søgning)"
                onChange={onAddressChange}
                required
              />
            </Col>
          </Row>
          <Row className={cx('mb-1', { 'd-none': accountType !== 'Consumer' })}>
            <Col>
              <InputText name="billingAddress.coName" label="c/o" />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <InputText name="billingAddress.internalLocation" label="Intern Lokation" />
            </Col>
          </Row>
        </>
      )}

      {addressType === 'Postbox' && (
        <>
          <Row className="mb-1">
            <Col>
              <InputText name="billingAddress.poBox" label="Postboks" required />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <PostnrBySelect
                name="billingAddress.masterAddressPoint"
                label="Postnr. / By"
                onChange={onPostcodeChange}
              />
            </Col>
          </Row>
        </>
      )}

      {addressType === 'ForeignAddress' && (
        <>
          <Row className="mb-1">
            <Col>
              <CountriesSelect
                required
                label="Vælg land"
                // onChange={onCountryChange}
                name="billingAddress.country"
              />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <InputText required name="billingAddress.addressLine1" label="Adresselinje 1" />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <InputText required name="billingAddress.addressLine2" label="Adresselinje 2" />
            </Col>
          </Row>

          <Row className="mb-1">
            <Col>
              <InputText name="billingAddress.addressLine3" label="Adresselinje 3" />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <InputText name="billingAddress.addressLine4" label="Adresselinje 4" />
            </Col>
          </Row>
          {accountType === 'Consumer' ? (
            <Row className="mb-1">
              <Col>
                <InputText name="billingAddress.coName" label="c/o" />
              </Col>
            </Row>
          ) : null}
        </>
      )}
    </Panel>
  );
}
