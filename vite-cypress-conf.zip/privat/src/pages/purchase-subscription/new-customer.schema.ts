import * as yup from 'yup';
import {
  BasketItemData,
  CampaignBasketItem,
  DiscountBasketItem,
  ProductBasketItem,
} from './basket/BasketItemModels';
import { setLocale } from 'yup';
import { SubscriptionGroup } from '@/api/subscription-groups';

setLocale({
  mixed: {
    required: '',
  },
});
export const dkAddressSchema = yup.object({
  internalLocation: yup.string(),
  houseSide: yup.string().nullable(),
  houseFloor: yup.string().nullable(),
  masterAddressPoint: yup.number().required(),
});

export const postboxSchema = yup.object({
  poBox: yup.string().required(),
  masterAddressPoint: yup.number().required(),
});

export const foreignAddressSchema = yup.object({
  country: yup.string().required(),
  addressLine1: yup.string().required(),
  addressLine2: yup.string().required(),
  addressLine3: yup.string(),
  addressLine4: yup.string(),
});

export const billingAddressSchema = yup.object({
  firstName: yup.string(),
  lastName: yup.string(),
  customerReference: yup.string(),
  ean: yup.string(),
  email: yup.string().email('Du skal indtaste en gyldig e-mail'),
  phonePrimary: yup.string().matches(/^\+?[0-9 ]{8,}$/, {
    message: 'Du skal indtaste et gyldigt telefonnummer',
    excludeEmptyString: true,
  }),
  phoneSecondary: yup.string().matches(/^\+?[0-9 ]{8,}$/, {
    message: 'Du skal indtaste et gyldigt telefonnummer',
    excludeEmptyString: true,
  }),
  companyName: yup.string(),
  cvr: yup
    .string()
    .matches(/^\d{8}$/, { message: 'CVR skal være 8 cifre', excludeEmptyString: true }),
  vat: yup.string(),
  coName: yup.string(),
});

export const deliveryAddressSchema = yup
  .object()
  .shape(
    {
      // firstname is required if companyName is not filled in
      firstName: yup.string().when('companyName', {
        is: (companyName: string) => !companyName || companyName.length === 0,
        then: yup.string().required(),
        otherwise: yup.string(),
      }),
      // lastName is required if companyName is not filled in
      lastName: yup.string().when('companyName', {
        is: (companyName: string) => !companyName || companyName.length === 0,
        then: yup.string().required(),
        otherwise: yup.string(),
      }),

      companyName: yup.string().when(['firstName', 'lastName'], {
        is: (firstName: string, lastName: string) =>
          (!firstName || firstName.length === 0) && (!lastName || lastName.length === 0),
        then: yup.string().required(),
        otherwise: yup.string(),
      }),

      coName: yup.string().when('companyName', {
        is: (companyName: string) => !companyName || companyName.length === 0,
        then: yup.string(),
        otherwise: yup.string().max(0, 'C/O må ikke være udfyldt når firmanavn er indtastet'),
      }),

      // Fælles
      afloCode: yup.string(),
      afloText: yup.string(),
    },
    [
      ['firstName', 'companyName'],
      ['lastName', 'companyName'],
      ['firstName', 'lastName'],
    ]
  )
  .nullable();

export const paymentMethods = [
  { value: 'MobilePay', label: 'MobilePay' },
  { value: 'NewPaymentMethod', label: 'Kreditkort' },
  { value: 'EAN', label: 'EAN' },
  { value: 'BankTransfer', label: 'Bankoverførsel' },
  { value: 'PaymentSlip', label: 'Indbetalingskort (standard)' },
  //{ value: 'PaymentSlipConsolidated', label: 'Samlefaktura (Indbetalingskort)' },
  //{ value: 'BankTransferConsolidated', label: 'Samlefaktura (Bankoverførsel)' },
  //{ value: 'EANConsolidated', label: 'Samlefaktura (EAN)' },
  { value: 'NoPayment', label: 'Ingen betalingsmetode', disabled: true, hidden: true },
  // { value: 'Betalingsservice', label: 'Betalingsservice', disabled: true },
];

type AccountType = 'Consumer' | 'Business';
type AddressType = 'NoAddress' | 'DkAddress' | 'Postbox' | 'ForeignAddress';

type PaymentMethod =
  | 'Betalingsservice'
  | 'PaymentSlip'
  | 'PaymentSlipConsolidated'
  | 'BankTransfer'
  | 'BankTransferConsolidated'
  | 'EAN'
  | 'EANConsolidated'
  | 'NewPaymentMethod'
  | 'MobilePay'
  | 'NoPayment'
  | 'DefaultPaymentMethod'
  | 'PhysicalBill';

export type PaymentTerm =
  | 'PBS'
  | 'MobilePay'
  | 'UseExistingTermOnAccount'
  | 'UseDefaultBasedOnPaymentMethod'
  | 'ZeroDays'
  | 'TenDays'
  | 'ElevenDays'
  | 'FourteenDays'
  | 'ThirtyDays'
  | 'FortyFiveDays'
  | 'SixtyDays';

export type ExtraDataType = {
  ssoId?: string;
  accountNumber?: string;
  products?: ProductBasketItem[];
  campaigns?: CampaignBasketItem[];
  discounts?: DiscountBasketItem[];
  subscriptionGroupId?: string;
  mobilePayRedirectLink: string;
};

export const newCustomerSchema = yup.object({
  accountType: yup.mixed<AccountType>(),

  paymentMethod: yup.mixed<PaymentMethod>(),
  paymentTerms: yup.mixed<PaymentTerm>(),

  billingAddressType: yup.mixed<AddressType>(),
  billingAddress: billingAddressSchema
    .when('billingAddressType', (btype: AddressType, schema) => {
      switch (btype) {
        case 'DkAddress':
          return schema.concat(dkAddressSchema);
        case 'ForeignAddress':
          return schema.concat(foreignAddressSchema);
        case 'Postbox':
          return schema.concat(postboxSchema);
        default:
          // console.log('no address returning schema', schema);
          return schema;
      }
    })
    .when('accountType', (accountType, schema) => {
      if (accountType === 'Consumer') {
        return schema.shape({
          firstName: yup.string().required(),
          lastName: yup.string().required(),
        });
      }
      if (accountType === 'Business') {
        return schema.shape(
          {
            firstName: yup
              .string()
              .when('lastName', (lastName, v) =>
                lastName ? v.matches(/\w+/, 'Både fornavn og efternavn skal angives') : v
              ),
            lastName: yup
              .string()
              .when('firstName', (firstName, v) =>
                firstName ? v.matches(/\w+/, 'Både fornavn og efternavn skal angives') : v
              ),
            companyName: yup.string().required(),
            useDummySsoId: yup.boolean(),
            addBillingAddressEmailUserBinding: yup.boolean(),
            email: yup
              .string()
              .email('Du skal indtaste en gyldig e-mail')
              .when('addBillingAddressEmailUserBinding', {
                is: true,
                then: yup.string().email('Du skal indtaste en gyldig e-mail').required(),
              }),
          },
          ['firstName', 'lastName']
        );
      }
      return schema;
    })
    .when('paymentMethod', (paymentMethod, schema) => {
      if (paymentMethod === 'EAN') {
        return schema.shape({
          ean: yup
            .string()
            .matches(/^\d{13}$/, { message: 'EAN skal være 13 cifre', excludeEmptyString: true })
            .required(),
        });
      }
      return schema;
    })
    .when('paymentMethod', (paymentMethod, schema) => {
      if (paymentMethod === 'MobilePay') {
        return schema.shape({
          phonePrimary: yup
            .string()
            .matches(/^\+?[0-9 ]{8,}$/, 'Du skal indtaste et gyldigt telefonnummer')
            .required(),
        });
      }
    })
    .when('paymentMethod', (paymentMethod, schema) => {
      if (paymentMethod === 'BankTransfer') {
        return schema.shape({
          email: yup.string().email('Du skal indtaste en gyldig e-mail').required(),
        });
      }
    }),
  hasDeliveryAddress: yup.bool(),
  deliveryAddressType: yup.mixed<AddressType>(),
  deliveryAddress: deliveryAddressSchema
    .when('accountType', (accountType: AccountType, schema: yup.AnyObjectSchema) => {
      if (accountType === 'Business') {
        return schema.shape({
          subscriptionCustomerReference: yup.string().max(30, 'Max. 30 tegn'),
          addDeliveryAddressEmailUserBinding: yup.boolean(),
          addDeliveryAddressEmailAdminSsoId: yup.boolean(),
          email: yup
            .string()
            .email('Du skal indtaste en gyldig e-mail')
            .when('addDeliveryAddressEmailUserBinding', {
              is: true,
              then: yup.string().email('Du skal indtaste en gyldig e-mail').required(),
            })
            .when('addDeliveryAddressEmailAdminSsoId', {
              is: true,
              then: yup.string().email('Du skal indtaste en gyldig e-mail').required(),
            }),
        });
      }
      return schema;
    })
    .when('deliveryAddressType', (deliveryAddressType: AddressType, schema: yup.AnySchema) => {
      switch (deliveryAddressType) {
        case 'DkAddress':
          return schema.concat(dkAddressSchema);
        case 'ForeignAddress':
          return schema.concat(foreignAddressSchema);
        case 'Postbox':
          return schema.concat(postboxSchema);
        case 'NoAddress':
          return schema;
        default:
          return schema;
      }
    })
    .when('hasDeliveryAddress', (hasDeliveryAddress: boolean, schema: yup.AnySchema) => {
      if (!hasDeliveryAddress) return yup.object().shape({}).nullable();
      return schema;
    }),

  basket: yup
    .array<BasketItemData>()
    .min(1, 'Ingen produkter i kurv')
    .max(9, 'Max. 9 produkter i kurv'),
  brand: yup.string(),
  hasPrint: yup.bool(),
  alignmentDate: yup.date(),
  orderEffectiveDate: yup.date(),
  subscriptionGroup: yup.mixed<SubscriptionGroup>(),
});

// TODO: Rename this, if it will also be used to add subscription to existing customer
export type NewCustomerSchemaType = yup.InferType<typeof newCustomerSchema>;
export type NewCustomerExportSchemaType = NewCustomerSchemaType & ExtraDataType;
