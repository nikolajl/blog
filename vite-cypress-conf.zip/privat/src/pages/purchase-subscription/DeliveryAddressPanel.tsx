import { InputText } from '@/components/forms/InputText';
import Panel from '@/components/ui/Panel';
import { ButtonGroup, Col, Row, Form } from 'react-bootstrap';
import { useFormContext } from 'react-hook-form';
import AddressSelect from '@/components/forms/AddressSelect';
import { DistributionAddress } from '@/api/types/distribution';
import { fetchLookUpAddress } from '@/api/distribution';
import { DawaAutoCompleteResult } from '@/api/dawa';
import Button from '@/components/forms/Button';
import PostnrBySelect from '@/components/forms/PostnrBySelect';
import CountriesSelect from '@/components/forms/CountriesSelect';
import AfloSelect from '../../components/forms/AfloSelect';
import { useAuthContext } from '@/components/providers/AuthProvider';
import { useState } from 'react';
import { useBasket } from './basket/basket.hooks';

async function fetchAddress(vejnavn: string, husnr: string, postnr: string) {
  const list = await fetchLookUpAddress(vejnavn, postnr);
  if (list && list.length) {
    const match = list.filter((x) => `${x.houseNumber}${x.houseLetter ?? ''}` === husnr).pop();

    return match;
  }
}

export default function DeliveryAddressPanel() {
  const auth = useAuthContext();
  const hasSpaBusinessExtras = auth?.user.flags['SpaBusinessExtras'];
  const [disableCOField, setDisableCOField] = useState(false);
  const form = useFormContext();
  const { basketHasPrint } = useBasket();

  const [basket, addressType, accountType, hasDeliveryAddress] = form.watch([
    'basket',
    'deliveryAddressType',
    'accountType',
    'hasDeliveryAddress',
  ]);

  if (!basket) return null;

  const onAddressChange = async (value: DawaAutoCompleteResult | null) => {
    // Clear address
    if (!value) {
      form.setValue('deliveryAddress.masterAddressPoint', null, { shouldValidate: true });
      return;
    }
    const distribution = await fetchAddress(
      value.data.vejnavn,
      value.data.husnr,
      value.stormodtagerpostnr ? value.data.stormodtagerpostnr : value.data.postnr
    );
    if (distribution) {
      form.setValue('deliveryAddress.masterAddressPoint', distribution.masterAddressPointID, {
        shouldValidate: true,
      });
      form.setValue('deliveryAddress.houseFloor', value.data.etage);
      form.setValue('deliveryAddress.houseSide', value.data.dør);
    }
  };

  const onPostcodeChange = async (value: DistributionAddress | null) => {
    if (!value) {
      form.setValue('deliveryAddress.masterAddressPoint', null, { shouldValidate: true });
      return;
    }

    const distribution = await fetchAddress('Postboks', '1', value.zipCode);
    if (distribution) {
      form.setValue('deliveryAddress.masterAddressPoint', distribution.masterAddressPointID, {
        shouldValidate: true,
      });
    }
  };

  const isEmailRequired =
    form.getValues().deliveryAddress?.addDeliveryAddressEmailUserBinding ?? false;

  return (
    <Panel
      title="Anden modtager"
      optional={true}
      initialOpen={hasDeliveryAddress}
      toggleHandler={(toggle) => {
        form.setValue('hasDeliveryAddress', toggle);
      }}>
      {accountType === 'Business' && hasSpaBusinessExtras && (
        <>
          <Row className="mb-1">
            <Col>
              <InputText
                name="deliveryAddress.subscriptionCustomerReference"
                label="Abonnementskundereference (max. 30 tegn)"
              />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <InputText name="deliveryAddress.email" label="E-mail" required={isEmailRequired} />
            </Col>
            <Col xs={4}>
              <Form.Check
                type="checkbox"
                id="deliveryAddress-userAccess-check"
                label="Tildel brugeradgang"
                {...form.register('deliveryAddress.addDeliveryAddressEmailUserBinding')}
              />
              <Form.Check
                type="checkbox"
                id="deliveryAddress-userAdmin-check"
                label="Abonnementsadministrator"
                {...form.register('deliveryAddress.addDeliveryAddressEmailAdminSsoId')}
              />
            </Col>
          </Row>
        </>
      )}
      <Row className="mb-1">
        <Col>
          <InputText name="deliveryAddress.firstName" label="Fornavn" />
        </Col>
      </Row>
      <Row className="mb-1">
        <Col>
          <InputText name="deliveryAddress.lastName" label="Efternavn" />
        </Col>
      </Row>
      <Row className="mb-1">
        <Col>
          <InputText
            name="deliveryAddress.companyName"
            label="Firmanavn"
            onChange={(event) => {
              if (event.target.value) {
                setDisableCOField(true);
                form.setValue('deliveryAddress.coName', undefined);
              } else {
                setDisableCOField(false);
              }
            }}
          />
        </Col>
      </Row>

      <ButtonGroup size="sm" className="my-2">
        {accountType === 'Business' && !basketHasPrint() && (
          <Button
            variant="outline-secondary"
            tabIndex={-1}
            active={addressType === 'NoAddress'}
            onClick={() => form.setValue('deliveryAddressType', 'NoAddress')}>
            Ingen adresse
          </Button>
        )}
        <Button
          variant="outline-secondary"
          tabIndex={-1}
          active={addressType === 'DkAddress'}
          onClick={() => form.setValue('deliveryAddressType', 'DkAddress')}>
          Dansk adresse
        </Button>
        <Button
          variant="outline-secondary"
          tabIndex={-1}
          active={addressType === 'Postbox'}
          onClick={() => form.setValue('deliveryAddressType', 'Postbox')}>
          Postboks
        </Button>
        <Button
          variant="outline-secondary"
          tabIndex={-1}
          active={addressType === 'ForeignAddress'}
          onClick={() => form.setValue('deliveryAddressType', 'ForeignAddress')}>
          Udenlandsk adresse
        </Button>
      </ButtonGroup>

      {addressType === 'DkAddress' && (
        <>
          <Row className="mb-1">
            <Col>
              <AddressSelect
                name="deliveryAddress.masterAddressPoint"
                label="Indtast adresse (søgning)"
                onChange={onAddressChange}
              />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <InputText name="deliveryAddress.coName" label="c/o" disabled={disableCOField} />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <InputText name="deliveryAddress.internalLocation" label="Intern Lokation" />
            </Col>
          </Row>
        </>
      )}

      {addressType === 'Postbox' && (
        <>
          <Row className="mb-1">
            <Col>
              <InputText name="deliveryAddress.poBox" label="Postboks" required />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <PostnrBySelect
                name="deliveryAddress.masterAddressPoint"
                label="Postnr. / By"
                onChange={onPostcodeChange}
              />
            </Col>
          </Row>
        </>
      )}

      {addressType === 'ForeignAddress' && (
        <>
          <Row className="mb-1">
            <Col>
              <CountriesSelect
                required
                label="Vælg land"
                // onChange={onCountryChange}
                name="deliveryAddress.country"
              />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <InputText required name="deliveryAddress.addressLine1" label="Adresselinje 1" />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <InputText required name="deliveryAddress.addressLine2" label="Adresselinje 2" />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <InputText name="deliveryAddress.addressLine3" label="Adresselinje 3" />
            </Col>
          </Row>
          <Row className="mb-1">
            <Col>
              <InputText name="deliveryAddress.addressLine4" label="Adresselinje 4" />
            </Col>
          </Row>
        </>
      )}
      {basketHasPrint() && (
        <Row className="mb-1">
          <Col>
            <AfloSelect name="deliveryAddress.afloCode" />
          </Col>
        </Row>
      )}
    </Panel>
  );
}
