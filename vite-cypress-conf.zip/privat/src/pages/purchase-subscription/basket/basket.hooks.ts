import {
  BillingPeriodAlignment,
  CampaignOffer,
  CampaignOfferStep,
  ProductRatePlan,
} from '@/api/types/catalog';

import { v4 as uuid } from 'uuid';
import { useFormContext } from 'react-hook-form';
import {
  ProductBasketItem,
  CampaignBasketItem,
  BasketItemData,
  DiscountBasketItem,
} from './BasketItemModels';
import { GiftCard, GiftCardType } from '@/api/types/giftcard';

export function useBasket() {
  const form = useFormContext();
  const basket = form.watch('basket') as BasketItemData[];
  const brand = form.watch('brand') as string;

  return {
    form,
    basket,
    brand,
    basketHasPrint() {
      return basket?.some(itemHasPrint) ?? false;
    },
    basketIsEmpty: () => {
      return !basket.length;
    },
    basketHasNoProductItems() {
      return !basket?.some((x) => x.type === 'product');
    },

    basketHasCampaignWithAbsoluteDateDiscounts() {
      return basket.some(
        (x) => x.type === 'campaign' && x.campaignOffer.type === 'WithAbsoluteDateDiscounts'
      );
    },
    getAllProductItems() {
      return basket?.filter((item): item is ProductBasketItem => item.type === 'product');
    },
    getAllDimensions() {
      // https://stackoverflow.com/questions/54695545/filtering-from-union-type-to-subtype
      const products = basket?.filter((item): item is ProductBasketItem => item.type === 'product');
      console.log('products in basket', products);
      const dimensions =
        products &&
        products
          .map((x) => x.ratePlan.productRatePlanCharges.map((y) => y.dimension))
          .flat()
          .filter(function (value, index, self) {
            // remove duplicates
            return self.indexOf(value) === index;
          });
      return dimensions;
    },
    getBasketDiscounts() {
      return basket?.filter((x) => x.type === 'discount') as DiscountBasketItem[];
    },
    addProductToBasket(
      product: ProductRatePlan,
      brand: string,
      billingPeriodAlignment: BillingPeriodAlignment,
      startDate: Date,
      endDate?: Date,
      giftCardType?: GiftCardType,
      giftCard?: GiftCard
    ) {
      const newBasket = [
        ...basket,
        createProductBasketItem(
          product,
          billingPeriodAlignment,
          startDate,
          endDate,
          giftCardType,
          giftCard
        ),
      ];

      form.setValue('basket', newBasket, { shouldValidate: true });
      form.setValue('brand', brand);
    },
    addCampaignToBasket(
      brand: string,
      campaign: CampaignOffer,
      billingPeriodAlignment: BillingPeriodAlignment
    ) {
      const newBasket = [
        ...basket,
        ...campaign.products.map((product) =>
          createCampaignBasketItem(campaign, product, billingPeriodAlignment)
        ),
      ];
      form.setValue('brand', brand);
      form.setValue('basket', newBasket);
      form.setValue('orderEffectiveDate', getOrderEffectiveDate(newBasket));
    },
    addRedeemGiftCardToBasket(
      brand: string,
      giftCard: GiftCard,
      product: ProductRatePlan,
      billingPeriodAlignment: BillingPeriodAlignment,
      startDate: Date,
      endDate?: Date
    ) {
      const newBasket = [
        ...basket,
        createProductBasketItem(product, billingPeriodAlignment, startDate, endDate),
        // createGiftCardBasketItem(giftCard),
      ];

      form.setValue('brand', brand);
      form.setValue('basket', newBasket, { shouldValidate: true });
    },
    addDiscountToBasket(
      amount: number,
      dimension: string,
      startDate: Date,
      consecutive: boolean,
      endDate?: Date
    ) {
      const item = createDiscountItem(amount, dimension, startDate, consecutive, endDate);
      const newBasket = [...basket, item];
      form.setValue('basket', newBasket, { shouldValidate: true });
    },
    removeFromBasket(item: BasketItemData) {
      const newBasket = basket.filter((x) => x !== item);
      form.setValue('basket', newBasket);
      form.setValue('orderEffectiveDate', getOrderEffectiveDate(newBasket));
      if (newBasket.length <= 0) {
        form.setValue('brand', '');
      }
    },
  };
}

function getOrderEffectiveDate(basket: BasketItemData[]) {
  const campaignWithOrderEffectiveDate = basket
    .filter((x) => x.type === 'campaign' && x.campaignOffer.orderEffectiveDate)
    .pop() as CampaignBasketItem;
  const orderEffectiveDate = campaignWithOrderEffectiveDate?.campaignOffer.orderEffectiveDate;

  return orderEffectiveDate;
}

export function productHasPrint(ratePlan: ProductRatePlan) {
  return ratePlan.accessFeatures.some((x) => x.accessFeatureName.includes('PRINT'));
}

export function campaignHasPrint(campaign: CampaignOffer) {
  return campaign.products.some(campaignOfferStepHasPrint);
}

export function campaignOfferStepHasPrint(campaignOfferStep: CampaignOfferStep) {
  return campaignOfferStep.chargeInfos?.some((x) => x.accessFeature.includes('PRINT'));
}

// TODO: if only campaign and product had similar naming of accessFeatures ...
export function itemHasPrint(item: BasketItemData) {
  if (item.type === 'product') return productHasPrint(item.ratePlan);
  if (item.type === 'campaign') return campaignOfferStepHasPrint(item.campaignOfferStep);
  return false;
}

let uniq = 1;
function createProductBasketItem(
  product: ProductRatePlan,
  billingPeriodAlignment: BillingPeriodAlignment,
  startDate: Date,
  endDate?: Date,
  giftCardType?: GiftCardType,
  giftCard?: GiftCard
): ProductBasketItem {
  return {
    type: 'product',
    key: `${product.productRatePlanId}-${uniq++}`,
    billingPeriodAlignment,
    ratePlan: product,
    startDate,
    endDate,
    giftCardType,
    giftCard,
  };
}

function createCampaignBasketItem(
  campaignOffer: CampaignOffer,
  campaignOfferStep: CampaignOfferStep,
  billingPeriodAlignment: BillingPeriodAlignment
): CampaignBasketItem {
  return {
    type: 'campaign',
    key: `${campaignOfferStep.idToPurchase}-${uniq++}`,
    billingPeriodAlignment,
    campaignOffer,
    campaignOfferStep,
  };
}

function createDiscountItem(
  amount: number,
  dimension: string,
  startDate: Date,
  consecutive: boolean,
  endDate?: Date
): DiscountBasketItem {
  return {
    type: 'discount',
    key: uuid(),
    amount,
    startDate,
    consecutive,
    endDate,
    dimension,
  };
}
