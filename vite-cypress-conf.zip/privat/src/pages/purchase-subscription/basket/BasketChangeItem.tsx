import ExpandCard from '@/components/ui/ExpandCard';
import { formatDate } from '@/utils/format';
import { Badge, ListGroup, ListGroupItem } from 'react-bootstrap';
import { FaCaretLeft, FaCaretDown } from 'react-icons/fa';
import { ProductChangeBasketItem } from './BasketItemModels';
import styles from './Basket.module.scss';
import BasketItemAccessFeatureTable from './BasketItemAccessFeatureTable';
import Button from '@/components/forms/Button';

type Props = {
  basketData: ProductChangeBasketItem;
};

export default function Change({ basketData }: Props) {
  return (
    <ExpandCard open={false} customClass={styles.productBasketItem}>
      <ExpandCard.Summary customClass={styles.productBasketItemSummary}>
        <p className={styles.basketHeader}>{basketData.type}</p>
        <Badge className={styles.basketType} bg={'secondary'}>
          Produktændring
        </Badge>
        {basketData.newStartDate && <p>Ny Startdato {formatDate(basketData.newStartDate)}</p>}
        {basketData.newEndDate && <p>Ny Slutdato {formatDate(basketData.newEndDate)}</p>}
        <Button className="mt-2" variant="outline-secondary" onClick={() => console.log('hej')}>
          Fjern fra kurven
        </Button>
        <div>
          <FaCaretLeft size={20} className={styles.caretLeft} />
          <FaCaretDown size={20} className={styles.caretDown} />
        </div>
      </ExpandCard.Summary>
      <ExpandCard.Section customClass={styles.productBasketItemBody}>
        {basketData.newStartDate && (
          <ListGroup>
            <ListGroupItem>
              <p>
                <strong>Nuværende startdato: </strong>
                {formatDate(basketData.productRatePlan.ratePlanStartDate)}
              </p>
            </ListGroupItem>
            <ListGroupItem>
              <p>
                <strong>Ny startdato: </strong>
                {formatDate(basketData.newStartDate)}
              </p>
            </ListGroupItem>
          </ListGroup>
        )}
        {basketData.newEndDate && (
          <ListGroup>
            <ListGroupItem>
              <p>
                <strong>Nuværende slutdato: </strong>
                {formatDate(basketData.productRatePlan.ratePlanEndDate)}
              </p>
            </ListGroupItem>
            <ListGroupItem>
              <p>
                <strong>Ny slutdato: </strong>
                {formatDate(basketData.newEndDate)}
              </p>
            </ListGroupItem>
          </ListGroup>
        )}
        {basketData.productRatePlan.accessFeaturesWithWeekdayMask &&
          BasketItemAccessFeatureTable(basketData.productRatePlan.accessFeaturesWithWeekdayMask)}
      </ExpandCard.Section>
    </ExpandCard>
  );
}
