import {
  BillingPeriodAlignment,
  CampaignOffer,
  CampaignOfferStep,
  ProductRatePlan,
  SubscriptionRatePlan,
} from '@/api/types/catalog';
import { GiftCard, GiftCardType } from '@/api/types/giftcard';

export type ProductBasketItem = {
  key: string;
  type: 'product';
  ratePlan: ProductRatePlan;
  billingPeriodAlignment: BillingPeriodAlignment;
  startDate: Date;
  endDate?: Date;
  giftCardType?: GiftCardType;
  giftCard?: GiftCard;
};

export type ProductChangeBasketItem = {
  key: string;
  type: 'productChange';
  productRatePlan: SubscriptionRatePlan;
  newStartDate?: Date;
  newEndDate?: Date;
};

export type CampaignBasketItem = {
  key: string;
  type: 'campaign';
  billingPeriodAlignment: BillingPeriodAlignment;
  campaignOffer: CampaignOffer;
  campaignOfferStep: CampaignOfferStep;
};

export type GiftCardBasketItem = {
  key: string;
  type: 'giftcard';
  giftCard: GiftCard;
};

export type DiscountBasketItem = {
  key: string;
  type: 'discount';
  amount: number;
  dimension: string;
  startDate: Date;
  consecutive: boolean;
  endDate?: Date;
};

export type BasketItemData =
  | ProductBasketItem
  | ProductChangeBasketItem
  | CampaignBasketItem
  | GiftCardBasketItem
  | DiscountBasketItem;
