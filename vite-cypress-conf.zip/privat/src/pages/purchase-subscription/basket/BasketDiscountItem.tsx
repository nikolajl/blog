import ExpandCard from '@/components/ui/ExpandCard';
import Button from '@/components/forms/Button';
import { DiscountBasketItem } from './BasketItemModels';
import styles from './Basket.module.scss';
import { useBasket } from './basket.hooks';
import { Badge } from 'react-bootstrap';
import { formatDate } from '@/utils/format';

import cx from 'classnames';

type Props = {
  basketData: DiscountBasketItem;
};

export default function BasketDiscountItem({ basketData }: Props) {
  const { removeFromBasket, getAllDimensions, getAllProductItems } = useBasket();

  const currentDimensionsInBasket = getAllDimensions();
  console.log('dimension', currentDimensionsInBasket);

  const matchingDimensions = currentDimensionsInBasket.some((d) => d === basketData.dimension);
  const matchingStartDate = getAllProductItems().some((p) => p.startDate <= basketData.startDate);

  const invalid = !matchingDimensions || !matchingStartDate;

  return (
    <ExpandCard
      open={false}
      customClass={cx(styles.productBasketItem, invalid ? styles.invalid : '')}>
      <ExpandCard.Summary customClass={styles.productBasketItemSummary}>
        <p className={styles.basketHeader}>{`${basketData.amount}% - ${basketData.dimension}`}</p>
        <Badge className={styles.basketType} bg={invalid ? 'danger' : 'secondary'}>
          {invalid ? 'Rabat ikke gyldig' : 'Rabat'}
        </Badge>
        {invalid && (
          <span className="ms-1 text-danger fst-italic ">ingen matchende startdato/dimension</span>
        )}
        <p>
          <span>Startdato: </span>
          {formatDate(basketData.startDate)}
        </p>
        <p>
          {basketData.consecutive ? (
            <span>Fortløbende</span>
          ) : (
            <>
              <span>Slutdato: </span>
              {formatDate(basketData.endDate)}
            </>
          )}
        </p>
        <Button
          className="mt-2"
          variant="outline-secondary"
          onClick={() => removeFromBasket(basketData)}>
          Fjern fra kurven
        </Button>
      </ExpandCard.Summary>
    </ExpandCard>
  );
}
