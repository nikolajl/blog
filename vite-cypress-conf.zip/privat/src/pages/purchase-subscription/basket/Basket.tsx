import Panel from '@/components/ui/Panel';
import { useBasket } from './basket.hooks';
import BasketItem from './BasketItem';

import { BasketItemData } from './BasketItemModels';

export default function Basket() {
  const { basket } = useBasket();

  return (
    <Panel title="Kurv">
      {basket.map((item: BasketItemData) => {
        switch (item.type) {
          case 'product':
            return <BasketItem.Product key={item.key} basketData={item} />;
          case 'productChange':
            return <BasketItem.Change key={item.key} basketData={item} />;
          case 'campaign':
            return <BasketItem.Campaign key={item.key} basketData={item} />;
          case 'discount':
            return <BasketItem.Discount key={item.key} basketData={item} />;
          default:
            return <h1>Product type not supported yet, add to switch in Basket.tsx</h1>;
        }
      })}
    </Panel>
  );
}
