import ExpandCard from '@/components/ui/ExpandCard';
import {
  formatDate,
  formatCurrency,
  formatAlignment,
  formatPaymentFrequency,
} from '@/utils/format';
import { FaCaretLeft, FaCaretDown } from 'react-icons/fa';
import { CampaignBasketItem } from './BasketItemModels';
import styles from './Basket.module.scss';
import BasketItemAccessFeatureTable from './BasketItemAccessFeatureTable';
import Button from '@/components/forms/Button';
import { useBasket } from './basket.hooks';
import { Badge } from 'react-bootstrap';

type Props = {
  basketData: CampaignBasketItem;
};

export default function BasketCampaignItem({ basketData }: Props) {
  const { periodPrice } = basketData.campaignOfferStep;
  const { removeFromBasket } = useBasket();

  return (
    <ExpandCard open={false} customClass={styles.productBasketItem}>
      <ExpandCard.Summary customClass={styles.productBasketItemSummary}>
        <p className={styles.basketHeader}>{basketData.campaignOfferStep.name}</p>
        <Badge className={styles.basketType} bg={'secondary'}>
          {basketData.campaignOfferStep.type === 'PeriodDiscountStep'
            ? 'Kampagne: Step'
            : 'Kampagne: Basis'}
        </Badge>
        <p>
          <span>Startdato: </span>
          {formatDate(basketData.campaignOfferStep.startDate)}
        </p>
        <p>
          <strong>Pris for perioden: </strong>
          {formatCurrency(periodPrice)}
        </p>
        <Button
          className="mt-2"
          variant="outline-secondary"
          onClick={() => removeFromBasket(basketData)}>
          Fjern fra kurven
        </Button>
        <div>
          <FaCaretLeft size={20} className={styles.caretLeft} />
          <FaCaretDown size={20} className={styles.caretDown} />
        </div>
      </ExpandCard.Summary>
      <ExpandCard.Section customClass={styles.productBasketItemBody}>
        <p>
          <strong>Beskrivelse: </strong>
          {basketData.campaignOfferStep.description}
        </p>
        <p>
          <strong>Fakturatilpasning: </strong>
          {formatAlignment(
            basketData.campaignOfferStep.type === 'BaseProductStep'
              ? basketData.billingPeriodAlignment
              : basketData.campaignOfferStep.billingPeriodAlignment
          )}
        </p>
        <p>
          <strong>Betalingsfrekvens: </strong>
          {formatPaymentFrequency(
            basketData.campaignOfferStep.billingPeriodType,
            Number(basketData.campaignOfferStep.billingPeriodUnitAmount)
          )}
        </p>
        {basketData.campaignOfferStep.chargeInfos &&
          BasketItemAccessFeatureTable(basketData.campaignOfferStep.chargeInfos)}
      </ExpandCard.Section>
    </ExpandCard>
  );
}
