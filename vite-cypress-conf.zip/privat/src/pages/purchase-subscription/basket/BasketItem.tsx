import BasketChangeItem from './BasketChangeItem';
import BasketCampaignItem from './BasketCampaignItem';
import BasketDiscountItem from './BasketDiscountItem';
import BasketProductItem from './BasketProductItem';

export default function BasketItem() {
  return <></>;
}

BasketItem.Product = BasketProductItem;
BasketItem.Change = BasketChangeItem;
BasketItem.Campaign = BasketCampaignItem;
BasketItem.Discount = BasketDiscountItem;
