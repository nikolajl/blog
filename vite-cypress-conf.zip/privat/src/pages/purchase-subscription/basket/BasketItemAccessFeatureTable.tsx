import { Table } from 'react-bootstrap';
import { FaCheck } from 'react-icons/fa';
import { AccessFeature, ChargeInfo } from '@/api/types/catalog';

export default function BasketItemAccessFeatureTable(
  accessFeatures: AccessFeature[] | ChargeInfo[]
) {
  return (
    <Table striped>
      <thead>
        <tr>
          <th>Access features</th>
          <th className="text-center">M</th>
          <th className="text-center">T</th>
          <th className="text-center">O</th>
          <th className="text-center">T</th>
          <th className="text-center">F</th>
          <th className="text-center">L</th>
          <th className="text-center">S</th>
        </tr>
      </thead>
      <tbody>
        {accessFeatures
          .map((x) =>
            'accessFeatureName' in x
              ? x
              : { accessFeatureName: x.accessFeature, weekdayMask: x.weekdayMask }
          )
          .sort((a, b) => a.accessFeatureName.localeCompare(b.accessFeatureName))
          .map((feature) => (
            <tr key={feature.accessFeatureName}>
              <td>{feature.accessFeatureName}</td>
              {feature.weekdayMask &&
                feature.weekdayMask.split('').map((day, i) =>
                  day === '_' ? (
                    <td key={i} />
                  ) : (
                    <td key={i} style={{ textAlign: 'center' }}>
                      <FaCheck color={'green'} />
                    </td>
                  )
                )}
            </tr>
          ))}
      </tbody>
    </Table>
  );
}
