import Button from '@/components/forms/Button';
import ExpandCard from '../../../components/ui/ExpandCard';
import { BasketItemData } from './BasketItemModels';
import styles from './Basket.module.scss';
import {
  formatAlignment,
  formatCurrency,
  formatDate,
  formatPaymentFrequency,
} from '@/utils/format';
import { FaCaretDown, FaCaretLeft } from 'react-icons/fa';
import { useBasket } from './basket.hooks';
import BasketItemAccessFeatureTable from './BasketItemAccessFeatureTable';
import { Badge } from 'react-bootstrap';

type Props = {
  basketData: BasketItemData;
};

export default function BasketProductItem({ basketData }: Props) {
  const { removeFromBasket } = useBasket();

  if (basketData.type !== 'product') return null;
  const { upFrontPrice, upFrontTaxAmount, recurringPrice, recurringTaxAmount } =
    basketData.ratePlan.pricing;
  const amount = basketData.giftCard?.amount;

  return (
    <ExpandCard open={false} customClass={styles.productBasketItem}>
      <ExpandCard.Summary customClass={styles.productBasketItemSummary}>
        <p className={styles.basketHeader}>{basketData.ratePlan.name} </p>
        <Badge className={styles.basketType} bg={'secondary'}>
          {basketData.giftCardType && basketData.giftCardType === 'Purchase' && 'Gavekort'}
          {basketData.giftCardType &&
            basketData.giftCardType === 'Redeem' &&
            'Gavekort - indløsning'}
        </Badge>
        <p>
          <span>Startdato: </span>
          {formatDate(basketData.startDate)}
        </p>
        {basketData.giftCardType && basketData.giftCardType === 'Redeem' && (
          <div>
            <p className={styles.gray}>
              <em>
                Produktpris: <strong>{formatCurrency(Number(upFrontPrice))}</strong>
                {` (Heraf moms ${formatCurrency(Number(upFrontTaxAmount))})`}
              </em>
            </p>

            <p className={styles.gray}>
              <em>
                Gavekort værdi: <strong>-{formatCurrency(amount ?? 0)}</strong>
              </em>
            </p>
          </div>
        )}

        <p className={styles.gray}>
          <em>
            Samlet pris ved køb:{' '}
            <strong>{formatCurrency(Number(upFrontPrice) - (amount ?? 0))}</strong>
            {` (Heraf moms ${formatCurrency(Number(upFrontTaxAmount))})`}
          </em>
        </p>
        <p className={styles.gray}>
          <em>
            Samlet pris pr. efterfølgende betaling:{' '}
            <strong>{formatCurrency(Number(recurringPrice))}</strong>
            {` (Heraf moms ${formatCurrency(Number(recurringTaxAmount))})`}
          </em>
        </p>
        <Button
          className="mt-2"
          variant="outline-secondary"
          onClick={() => removeFromBasket(basketData)}>
          Fjern fra kurven
        </Button>
        <div>
          <FaCaretLeft size={20} className={styles.caretLeft} />
          <FaCaretDown size={20} className={styles.caretDown} />
        </div>
      </ExpandCard.Summary>
      <ExpandCard.Section customClass={styles.productBasketItemBody}>
        <p>
          <strong>Beskrivelse: </strong>
          {basketData.ratePlan.description}
        </p>
        <p>
          <strong>Fakturatilpasning: </strong>
          {formatAlignment(basketData.billingPeriodAlignment)}
        </p>
        <p>
          <strong>Betalingsfrekvens: </strong>
          {formatPaymentFrequency(
            basketData.ratePlan.billingPeriodUnitOfMeasureEnumString,
            basketData.ratePlan.billingPeriodLength
          )}
        </p>
        {BasketItemAccessFeatureTable(basketData.ratePlan.accessFeatures)}
      </ExpandCard.Section>
    </ExpandCard>
  );
}
