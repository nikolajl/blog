import { usePollSubscriptionOrder } from '@/api/orders';
import { useEffect, useState } from 'react';
import { Container, Modal, ModalBody, Row, Spinner } from 'react-bootstrap';

interface Props {
  show: boolean;
  orderNumber: string;
}

function usePolling(orderNumber: string) {
  const [redirectUrl, setRedirectUrl] = useState('');
  const { data } = usePollSubscriptionOrder(orderNumber);
  const ssoId = data?.SsoId;
  const status = data?.StatusEnumString;
  const accountNumber = data?.CreatedSubscription?.AccountNumber;
  const subscriptionNumber = data?.CreatedSubscription?.SubscriptionNumber;

  if (ssoId) {
    setTimeout(() => {
      setRedirectUrl(`/Customer/ViewCustomer/${ssoId}?processingOrder=${orderNumber}`);
    }, 5000);
  }

  useEffect(() => {
    if (status === 'Finished') {
      const query = new URLSearchParams();
      if (accountNumber) query.append('accountNumber', accountNumber);
      if (subscriptionNumber) query.append('subscriptionNumber', subscriptionNumber);
      setRedirectUrl(`/Customer/ViewCustomer/${ssoId}?${query}`);
    }
  }, [ssoId, status, accountNumber, subscriptionNumber]);

  return redirectUrl;
}

export default function PollingModal(props: Props) {
  const { show, orderNumber } = props;
  const redirectUrl = usePolling(orderNumber);

  useEffect(() => {
    if (redirectUrl) window.location.assign(redirectUrl);
  }, [redirectUrl]);

  return (
    <Modal show={show && !!orderNumber} size={'lg'}>
      <Modal.Header>
        <Modal.Title>Ordren behandles</Modal.Title>
      </Modal.Header>
      <ModalBody>
        <Container>
          <Row>
            <div>
              <Spinner animation="border" size="sm" /> Afventer at ordren behandles..
            </div>
          </Row>
        </Container>
      </ModalBody>
    </Modal>
  );
}
