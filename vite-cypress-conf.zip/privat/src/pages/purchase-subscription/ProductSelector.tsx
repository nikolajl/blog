import { BillingPeriodAlignment, Product, ProductRatePlan } from '@/api/types/catalog';
import { useProductCatalog } from '@/api/catalog';
import Button from '@/components/forms/Button';
import FormDate from '@/components/forms/FormDate';
import { formatCurrency } from '@/utils/format';
import { useState } from 'react';
import { Container, Dropdown, Spinner, Row, Col, Form } from 'react-bootstrap';
import { productHasPrint, useBasket } from './basket/basket.hooks';
import styles from './ProductSelector.module.scss';
import RatePlanFilter, {
  billingPeriod,
  getRateplanFilterAccessFeatures,
  RatePlanFilterSettings,
} from './RatePlanFilter';
import { useFormContext } from 'react-hook-form';
import { useNextDeliveryDate } from '@/api/distribution';
import Tooltip from '@/components/ui/Tooltip';
import { useUser } from '@/api/user';

type Props = {
  disabled?: boolean;
};

export default function ProductSelector({ disabled }: Props) {
  const form = useFormContext();
  const user = useUser();
  const [brand, basket] = form.watch(['brand', 'basket']);
  const nextDeliveryDate = useNextDeliveryDate();
  const { data, isLoading } = useProductCatalog();
  const [selectedProduct, setSelectedProduct] = useState<Product>();
  const [selectedProductRatePlan, setSelectedProductRatePlan] = useState<ProductRatePlan>();
  const [isGiftCard, setIsGiftCard] = useState(false);
  const [ratePlanFilter, setRatePlanFilter] = useState<RatePlanFilterSettings>({});

  const [fromDate, setFromDate] = useState<Date | null>(null);
  const [billingPeriodAlignment, setBillingPeriodAlignment] =
    useState<BillingPeriodAlignment>('AlignToCharge');

  const { addProductToBasket } = useBasket();

  const onAddProduct = () => {
    if (selectedProductRatePlan) {
      addProductToBasket(
        selectedProductRatePlan,
        selectedProduct?.brandEnumString ?? '',
        billingPeriodAlignment,
        fromDate ?? new Date(),
        undefined,
        isGiftCard ? 'Purchase' : undefined,
        undefined
      );
      invalidate();
    }
  };

  const invalidate = () => {
    setSelectedProduct(undefined);
    setSelectedProductRatePlan(undefined);
    setIsGiftCard(false);
    setFromDate(null);
  };

  const onProductSelected = (product: Product) => {
    setSelectedProduct(product);
    setSelectedProductRatePlan(undefined);
  };

  const onProductRatePlanSelected = (ratePlan: ProductRatePlan) => {
    if (!ratePlan?.duration) setIsGiftCard(false);
    setSelectedProductRatePlan(ratePlan);
  };

  const filteredRatePlans = selectedProduct?.productRatePlans.filter((ratePlan) => {
    if (
      ratePlanFilter.otherRecurringPrice === 'yes' &&
      ratePlan.pricing.recurringPrice === ratePlan.pricing.upFrontPrice
    ) {
      return false;
    }
    if (
      ratePlanFilter.otherRecurringPrice === 'no' &&
      ratePlan.pricing.recurringPrice !== ratePlan.pricing.upFrontPrice
    ) {
      return false;
    }

    if (ratePlanFilter.weekdaymask) {
      if (
        !getRateplanFilterAccessFeatures(ratePlan).some(
          (af) => af.weekdayMask === ratePlanFilter.weekdaymask
        )
      ) {
        return false;
      }
    }

    if (ratePlanFilter.billingPeriod) {
      if (ratePlanFilter.billingPeriod !== billingPeriod(ratePlan)) {
        return false;
      }
    }

    if (
      ratePlanFilter.giftCardOnly &&
      user.data?.flags['AllowGiftcardPurchase'] &&
      !ratePlan?.duration
    ) {
      return false;
    }

    // if not filtered, include it
    return true;
  });

  const ratePlanDisplay = (ratePlan: ProductRatePlan) =>
    `${ratePlan.name} (${formatCurrency(ratePlan.pricing.upFrontPrice)})`;

  const billingPeriodAlignmentOptions = [
    {
      id: 'bpa-charge',
      value: 'AlignToCharge' as BillingPeriodAlignment,
      label: 'Startdato',
      tooltip: 'Produkt tilpasses IKKE, men faktureres en hel periode',
    },
    {
      id: 'bpa-term',
      value: 'AlignToTerm' as BillingPeriodAlignment,
      label: 'Abonnement',
      tooltip: 'Produkt tilpasses abonnementsperiode',
    },
  ];

  const isAddProductDisabled =
    disabled ||
    !selectedProductRatePlan ||
    (!isGiftCard && (!fromDate || (brand === 'Finans' && basket.length)));

  const minStartDate =
    selectedProductRatePlan && productHasPrint(selectedProductRatePlan)
      ? nextDeliveryDate.data
      : new Date();

  return (
    <div>
      <Row>
        {isLoading ? (
          <Container className="mx-auto text-center my-2">
            <Spinner size="sm" animation="border" />
            Henter data...
          </Container>
        ) : (
          <>
            <Col>
              <Dropdown id="choose-product" className="dropdown-new-customer mb-2">
                <Dropdown.Toggle
                  className="dropdown-new-customer md-2"
                  variant="outline-secondary"
                  disabled={disabled}>
                  {!selectedProduct ? (
                    <span>Vælg produkt</span>
                  ) : (
                    <span>{selectedProduct.name}</span>
                  )}
                </Dropdown.Toggle>
                <Dropdown.Menu className={styles.dropdownMenu}>
                  <Dropdown.Item>Vælg produkt</Dropdown.Item>
                  {data
                    ?.filter((x) => (brand ? x.brandEnumString === brand : true))
                    ?.sort((a, b) => a.name.localeCompare(b.name))
                    .map((product) => (
                      <Dropdown.Item
                        key={product.productId}
                        onClick={() => onProductSelected(product)}>
                        {product.name}
                      </Dropdown.Item>
                    ))}
                </Dropdown.Menu>
              </Dropdown>
              {selectedProduct && (
                <RatePlanFilter
                  onFilterChange={(filter) => setRatePlanFilter(filter)}
                  product={selectedProduct}
                />
              )}

              {selectedProduct && (
                <Dropdown data-cy={'choose-plan'} id={styles.choosePlan} className="my-2">
                  <Dropdown.Toggle
                    className={styles.dropdownToggle}
                    variant="outline-secondary"
                    disabled={!selectedProduct || disabled}>
                    {selectedProductRatePlan
                      ? ratePlanDisplay(selectedProductRatePlan)
                      : !filteredRatePlans?.length
                      ? 'Ingen matchende abonnementstyper'
                      : 'Vælg abonnementstype'}
                  </Dropdown.Toggle>
                  {!!filteredRatePlans?.length && (
                    <>
                      {user.data?.flags['AllowGiftcardPurchase'] &&
                        selectedProductRatePlan?.duration && (
                          <div className="my-2">
                            <Form.Check
                              id="giftcard-checkbox"
                              type="checkbox"
                              label="Gavekort?"
                              onChange={(e) => setIsGiftCard(e.target.checked)}
                              checked={isGiftCard}
                            />
                          </div>
                        )}
                      <Dropdown.Menu className={styles.dropdownMenu}>
                        <Dropdown.Item>Vælg abonnementstype</Dropdown.Item>
                        {filteredRatePlans
                          .sort(
                            (a, b) =>
                              parseFloat(a.pricing.upFrontPrice) -
                              parseFloat(b.pricing.upFrontPrice)
                          )
                          .map((ratePlan, index) => {
                            return (
                              <Dropdown.Item
                                key={`${ratePlan.productRatePlanId}-${index}`}
                                onClick={() => onProductRatePlanSelected(ratePlan)}>
                                {ratePlanDisplay(ratePlan)}
                              </Dropdown.Item>
                            );
                          })}
                      </Dropdown.Menu>
                    </>
                  )}
                </Dropdown>
              )}
              {isGiftCard ? null : (
                <>
                  <div className="my-2">
                    <FormDate
                      className="required"
                      placeholderText="Vælg startdato"
                      selected={fromDate}
                      disabled={!selectedProductRatePlan || disabled}
                      minDate={minStartDate}
                      onChange={(date) => date instanceof Date && setFromDate(date)}
                    />
                  </div>
                  <Form.Label>Fakturatilpasning</Form.Label>
                  {billingPeriodAlignmentOptions.map((option) => {
                    return (
                      <Form.Check
                        type="radio"
                        id={option.id}
                        key={option.value}
                        disabled={disabled}>
                        <Form.Check.Label>{option.label}</Form.Check.Label>
                        <Form.Check.Input
                          type={'radio'}
                          checked={billingPeriodAlignment === option.value}
                          onChange={() => setBillingPeriodAlignment(option.value)}
                          value={option.value}
                        />
                        <Tooltip>{option.tooltip}</Tooltip>
                      </Form.Check>
                    );
                  })}
                </>
              )}
            </Col>
            <Col>
              <div>
                <strong>Samlet pris ved køb</strong>
              </div>
              <div>
                <span>
                  {selectedProductRatePlan
                    ? formatCurrency(selectedProductRatePlan.pricing.upFrontPrice)
                    : formatCurrency(0)}
                  <i className="gray">{`(Heraf moms ${
                    selectedProductRatePlan
                      ? formatCurrency(selectedProductRatePlan.pricing.upFrontTaxAmount)
                      : formatCurrency(0)
                  })`}</i>
                </span>
              </div>
              <div>
                <div>
                  <strong>Samlet pris pr. efterfølgende betaling</strong>
                </div>
                <span>
                  {selectedProductRatePlan
                    ? formatCurrency(selectedProductRatePlan.pricing.recurringPrice)
                    : formatCurrency(0)}
                  <i className="gray">{`(Heraf moms ${
                    selectedProductRatePlan
                      ? formatCurrency(selectedProductRatePlan.pricing.recurringTaxAmount)
                      : formatCurrency(0)
                  })`}</i>
                </span>
              </div>
              {selectedProductRatePlan?.description?.trim() &&
                selectedProductRatePlan.description !== 'userdata: NULL' && (
                  <div>
                    <div>
                      <strong>Beskrivelse</strong>
                    </div>
                    <span>{selectedProductRatePlan.description}</span>
                  </div>
                )}
              {selectedProductRatePlan && (
                <div>
                  <strong>Features</strong>
                  <ul>
                    {selectedProductRatePlan.accessFeatures
                      .sort((a, b) => a.accessFeatureName.localeCompare(b.accessFeatureName))
                      .map(({ accessFeatureName }, index) => (
                        <li key={accessFeatureName + index}>{accessFeatureName}</li>
                      ))}
                  </ul>
                </div>
              )}
            </Col>
          </>
        )}
      </Row>

      <div className="d-flex justify-content-end">
        <Button
          disabled={isAddProductDisabled}
          type="button"
          variant="outline-success"
          onClick={onAddProduct}>
          Tilføj produkt til kurv
        </Button>
      </div>
    </div>
  );
}
