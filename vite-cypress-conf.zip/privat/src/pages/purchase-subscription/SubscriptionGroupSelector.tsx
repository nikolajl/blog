import { SubscriptionGroup, useSubscriptionGroupsByBrand } from '@/api/subscription-groups';
import { useState } from 'react';
import Select, { StylesConfig } from 'react-select';

type Props = {
  onChange: (value: SubscriptionGroup | null) => void;
  brand: string;
};

export function SubscritpionGroupSelect({ onChange, brand }: Props) {
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<SubscriptionGroup | null>();

  const { data } = useSubscriptionGroupsByBrand(brand);

  const customStyle: StylesConfig<SubscriptionGroup, false> = {
    control: (provided) => ({
      ...provided,
      borderRadius: '3px',
    }),
  };

  return (
    <Select
      className="my-2 w-50 react-select"
      styles={customStyle}
      isClearable
      placeholder="Vælg abonnementsgruppe"
      options={data ?? []}
      onChange={(value) => {
        setSelected(value);
        onChange(value);
      }}
      onInputChange={(value, event) => {
        if (event.action === 'input-change') !value && setSelected(null);
        setQuery(value);
      }}
      onBlur={() => !selected && onChange(null)}
      noOptionsMessage={() => 'Ingen valgmuligheder'}
      filterOption={(option) => option.value.includes(query.toLowerCase())}
      onMenuOpen={() => selected && setQuery(selected.name)}
      inputValue={query}
      value={selected}
      getOptionLabel={(group) => group.name ?? ''}
      getOptionValue={(group) => group.name.toLowerCase() ?? ''}
    />
  );
}
