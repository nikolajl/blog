import { Col, Dropdown, Form, FormLabel, Row, Spinner } from 'react-bootstrap';
import { useCampaignCatalog, useCampaignOfferById } from '@/api/catalog';
import { useState } from 'react';
import { BillingPeriodAlignment, Campaign, CampaignOffer } from '@/api/types/catalog';
import FormDate from '@/components/forms/FormDate';
import Button from '@/components/forms/Button';
import Tooltip from '@/components/ui/Tooltip';
import { formatDate, formatPeriodPrice } from '@/utils/format';
import { campaignHasPrint, useBasket } from './basket/basket.hooks';
import { useNextDeliveryDate } from '@/api/distribution';
import styles from './ProductSelector.module.scss';

type Props = {
  disabled?: boolean;
};
export default function CampaignSelector({ disabled }: Props) {
  const [{ campaign, offerId }, setSelectedCampaign] = useState<{
    campaign?: Campaign;
    offerId?: string;
  }>({});
  const [startDate, setStartDate] = useState<Date | undefined>();
  const [billingPeriodAlignment, setBillingPeriodAlignment] =
    useState<BillingPeriodAlignment>('AlignToCharge');
  const nextDeliveryDate = useNextDeliveryDate();
  const { data, isFetching } = useCampaignOfferById(
    campaign?.brandName,
    campaign?.campaignFriendlyId,
    offerId,
    startDate
  );

  const { addCampaignToBasket, brand, basketHasCampaignWithAbsoluteDateDiscounts } = useBasket();
  const isDisabled = !data || isFetching || !startDate;

  const onClick = () => {
    // This check is just to keep typescript happy
    if (data && campaign) {
      addCampaignToBasket(campaign?.brandName, data, billingPeriodAlignment);
      setStartDate(undefined);
      setSelectedCampaign({});
    }
  };

  const billingPeriodAlignmentOptions = [
    {
      id: 'bpa-charge',
      value: 'AlignToCharge' as BillingPeriodAlignment,
      label: 'Startdato',
      tooltip: 'Basis produkt tilpasses IKKE, men faktureres en hel periode',
    },
    {
      id: 'bpa-term',
      value: 'AlignToTerm' as BillingPeriodAlignment,
      label: 'Abonnement',
      tooltip: 'Basis produkt tilpasses abonnementsperiode',
    },
  ];

  const minStartDate = data && campaignHasPrint(data) ? nextDeliveryDate.data : new Date();
  const maxStartDate = data && data.endDate ? new Date(data.endDate) : undefined;

  return (
    <div>
      <Row>
        <Col>
          <CampaignSelect
            brand={brand}
            campaign={campaign}
            offerId={offerId}
            onChange={(campaign, offerId) => {
              setSelectedCampaign({ campaign, offerId });
              setStartDate(undefined);
            }}
            disabled={disabled}
            excludeCampaignsWithAbsoluteDateDiscounts={basketHasCampaignWithAbsoluteDateDiscounts()}
          />
          <div className="my-2">
            <FormDate
              className="required"
              placeholderText="Startdato"
              minDate={minStartDate}
              maxDate={maxStartDate}
              selected={startDate ?? null}
              onChange={(date) => setStartDate(date ?? undefined)}
              disabled={!data || disabled}
            />
          </div>
          <FormLabel>Fakturatilpasning (basis produkt)</FormLabel>
          {billingPeriodAlignmentOptions.map((option) => {
            return (
              <Form.Check type="radio" id={option.id} key={option.value}>
                <Form.Check.Label>{option.label}</Form.Check.Label>
                <Form.Check.Input
                  type={'radio'}
                  checked={billingPeriodAlignment === option.value}
                  onChange={() => setBillingPeriodAlignment(option.value)}
                  value={option.value}
                />
                <Tooltip>{option.tooltip}</Tooltip>
              </Form.Check>
            );
          })}
        </Col>
        <Col>
          <CampaignOfferDetails data={data} isFetching={isFetching} />
        </Col>
      </Row>
      <Row>
        <Col className="d-flex justify-content-end">
          <Button
            disabled={isDisabled}
            type="button"
            variant="outline-success"
            onClick={onClick}
            className="float-right">
            Tilføj kampagne til kurv
          </Button>
        </Col>
      </Row>
    </div>
  );
}

type CampaignSelectProps = {
  brand?: string;
  campaign?: Campaign;
  offerId?: string;
  onChange: (campaign?: Campaign, offerId?: string) => void;
  disabled?: boolean;
  excludeCampaignsWithAbsoluteDateDiscounts: boolean;
};
function CampaignSelect({
  brand,
  campaign,
  offerId,
  onChange,
  disabled,
  excludeCampaignsWithAbsoluteDateDiscounts = false,
}: CampaignSelectProps) {
  const { data, isLoading } = useCampaignCatalog();
  const offerDisplayName = campaign?.offers
    .filter((x) => x.offerFriendlyId === offerId)
    .pop()?.offerDisplayName;

  return (
    <div>
      <Dropdown className="mb-2">
        <Dropdown.Toggle variant="outline-secondary" disabled={disabled}>
          {campaign ? campaign.campaignDisplayName : ' Vælg kampagne'}
        </Dropdown.Toggle>
        <Dropdown.Menu className={styles.dropdownMenu}>
          <Dropdown.Item>{isLoading ? 'Henter kampagner ...' : 'Vælg kampagne'}</Dropdown.Item>
          {data
            ?.filter((campaign) => (brand ? campaign.brandName === brand : true))
            ?.filter((campaign) =>
              excludeCampaignsWithAbsoluteDateDiscounts
                ? !campaign.offers.some((x) => x.hasAbsoluteDateDiscountSteps)
                : true
            )
            ?.sort((a, b) => a.campaignDisplayName.localeCompare(b.campaignDisplayName))
            .map((campaign) => (
              <Dropdown.Item key={campaign.campaignFriendlyId} onClick={() => onChange(campaign)}>
                {campaign.campaignFriendlyId}
              </Dropdown.Item>
            ))}
        </Dropdown.Menu>
      </Dropdown>

      {campaign && (
        <Dropdown className="mb-2">
          <Dropdown.Toggle variant="outline-secondary" disabled={disabled}>
            {offerDisplayName ? offerDisplayName : 'Vælg tilbud'}
          </Dropdown.Toggle>
          <Dropdown.Menu>
            <Dropdown.Item>Vælg tilbud</Dropdown.Item>
            {campaign?.offers
              ?.sort((a, b) => a.offerDisplayName.localeCompare(b.offerDisplayName))
              .map((offer) => (
                <Dropdown.Item
                  key={offer.offerFriendlyId}
                  onClick={() => onChange(campaign, offer.offerFriendlyId)}>
                  {offer.offerDisplayName} {offer.isTrial ? ' (Trial)' : ''}
                </Dropdown.Item>
              ))}
          </Dropdown.Menu>
        </Dropdown>
      )}
    </div>
  );
}

type CampaignOfferDetailsProps = {
  data?: CampaignOffer;
  isFetching: boolean;
};
function CampaignOfferDetails({ data, isFetching }: CampaignOfferDetailsProps) {
  if (isFetching) return <Spinner animation="border" />;

  if (!data) return null;

  return (
    <div>
      {data.products.map((product) => {
        return (
          <div key={product.idToPurchase}>
            <div>{product.name}</div>
            <div>
              {formatDate(product.startDate)} - {formatDate(product.endDate)}
            </div>
            <div>
              {formatPeriodPrice(
                product.periodPrice,
                data.currency,
                product.billingPeriodType,
                product.billingPeriodUnitAmount
              )}
            </div>
            <div>Beskrivelse</div>
            <div>{product.description}</div>
            <div>Features</div>
            <ul>
              {product.chargeInfos?.map(({ accessFeature }) => (
                <li key={accessFeature}>{accessFeature}</li>
              ))}
            </ul>
          </div>
        );
      })}
    </div>
  );
}
