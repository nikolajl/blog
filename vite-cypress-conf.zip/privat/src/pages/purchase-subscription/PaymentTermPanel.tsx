import InputRadioGroup from '@/components/forms/InputRadioGroup';
import Panel from '@/components/ui/Panel';
import { useFormContext } from 'react-hook-form';
import { ProductBasketItem } from './basket/BasketItemModels';

const paymentExtensionOptions = [
  // { label: 'MobilePay', value: 'MobilePay' },
  // { label: 'PBS', value: 'PBS' },
  // { label: 'Øjeblikkelig betalingsfrist', value: 'ZeroDays' },
  { label: '14 Dage (standard)', value: 'FourteenDays' },
  { label: '30 Dage', value: 'ThirtyDays' },
  { label: '45 Dage', value: 'FortyFiveDays' },
  { label: '60 Dage', value: 'SixtyDays' },
];

export default function PaymentTermPanel() {
  const form = useFormContext();
  const [accountType, paymentMethod, basket] = form.watch([
    'accountType',
    'paymentMethod',
    'basket',
  ]);

  if (accountType !== 'Business') {
    return null;
  }

  if (['NewPaymentMethod', 'MobilePay', 'NoPayment'].indexOf(paymentMethod) !== -1) {
    return null;
  }

  // TODO: Use basket methods

  // Hide paymentMethod if trial
  if (basket.length && basket.every((x: ProductBasketItem) => x.ratePlan?.isTrial)) {
    return null;
  }

  return (
    <Panel title="Betalingsfrist">
      <InputRadioGroup name="paymentTerms" options={paymentExtensionOptions} />
    </Panel>
  );
}
