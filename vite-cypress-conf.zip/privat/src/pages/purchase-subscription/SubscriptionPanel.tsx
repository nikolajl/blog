import Panel from '@/components/ui/Panel';
import AlignmentDatePicker from './AlignmentDatePicker';

export default function SubscriptionPanel() {
  return (
    <Panel title="Abonnement">
      <AlignmentDatePicker />
    </Panel>
  );
}
