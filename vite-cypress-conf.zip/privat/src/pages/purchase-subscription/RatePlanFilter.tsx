import { Product, ProductRatePlan } from '@/api/types/catalog';
import React, { useEffect, useMemo, useState } from 'react';
import { Col, Collapse, Row } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';

export type RatePlanFilterSettings = {
  otherRecurringPrice?: string;
  weekdaymask?: string;
  billingPeriod?: BillingPeriod;
  giftCardOnly?: boolean;
};

type Props = {
  onFilterChange: (filterSettings: RatePlanFilterSettings) => void;
  product: Product;
};

const billingOptionsDisplay: Record<BillingPeriod, string> = {
  Weekly: 'Ugentlig',
  Monthly: 'Månedlig',
  Quarterly: 'Kvartalsvis',
  SemiYearly: 'Halvårlig',
  Yearly: 'Årlig',
  Other: 'Andre',
};

// TODO: Extract this to somewhere
type BillingPeriod = 'Weekly' | 'Monthly' | 'Quarterly' | 'SemiYearly' | 'Yearly' | 'Other';

// TODO: Extract this to somewhere
export const billingPeriod = (ratePlan: ProductRatePlan): BillingPeriod => {
  // This looks weird, but it's what they want
  if (ratePlan.billingPeriodUnitOfMeasureEnumString === 'Week') return 'Weekly';
  else if (
    ratePlan.billingPeriodUnitOfMeasureEnumString === 'Month' &&
    ratePlan.billingPeriodLength === 1
  )
    return 'Monthly';
  else if (
    ratePlan.billingPeriodUnitOfMeasureEnumString === 'Month' &&
    ratePlan.billingPeriodLength === 3
  )
    return 'Quarterly';
  else if (
    ratePlan.billingPeriodUnitOfMeasureEnumString === 'Month' &&
    ratePlan.billingPeriodLength === 6
  )
    return 'SemiYearly';
  else if (
    ratePlan.billingPeriodUnitOfMeasureEnumString === 'Year' &&
    ratePlan.billingPeriodLength === 1
  )
    return 'Yearly';
  else return 'Other';
};

// TODO: Extract this to somewhere
export function getRateplanFilterAccessFeatures(ratePlan: ProductRatePlan) {
  const printAccessFeatures = ratePlan.accessFeatures.filter((af) =>
    af.accessFeatureName.includes('PRINT')
  );

  if (!printAccessFeatures.length) {
    const accessFeaturesByDaysNotIncluded = ratePlan.accessFeatures.map(
      (af) => af.weekdayMask.split('_').length
    );
    const mostLimitedAccessFeature = Math.max(...accessFeaturesByDaysNotIncluded);
    const mostLimitedAccessFeatureIndex =
      accessFeaturesByDaysNotIncluded.indexOf(mostLimitedAccessFeature);

    if (mostLimitedAccessFeatureIndex !== -1) {
      return [ratePlan.accessFeatures[mostLimitedAccessFeatureIndex]];
    }
  }

  return printAccessFeatures;
}

function getOptions(product: Product) {
  const billingOptions: Record<string, boolean> = {};
  const weekdayOptions: Record<string, boolean> = {};

  product.productRatePlans.forEach((ratePlan) => {
    billingOptions[billingPeriod(ratePlan)] = true;
    getRateplanFilterAccessFeatures(ratePlan).forEach((af) => {
      weekdayOptions[af.weekdayMask] = true;
    });
  });

  return {
    billingOptions,
    weekdayOptions,
  };
}

export default function RatePlanFilter({ onFilterChange, product }: Props) {
  const cookie = localStorage.getItem('rateplanFilterIsOpen');
  console.log('cookie', cookie);
  if (cookie === null) {
    localStorage.setItem('rateplanFilterIsOpen', 'true');
  }
  const [isOpen, setIsOpen] = useState(cookie === null ? true : cookie === 'true');
  const [otherRecurringPrice, setOtherRecurringPrice] = useState<string | undefined>(undefined);
  const [giftCardOnly, setGiftCardOnly] = useState<boolean | undefined>(undefined);
  const [weekdaymask, setWeekdaymask] = useState<string | undefined>(undefined);
  const [billingPeriod, setBillingPeriod] = useState<BillingPeriod | undefined>(undefined);

  const { billingOptions, weekdayOptions } = useMemo(() => getOptions(product), [product]);
  useEffect(() => {
    onFilterChange({
      otherRecurringPrice,
      weekdaymask,
      billingPeriod,
      giftCardOnly,
    });
  }, [otherRecurringPrice, weekdaymask, billingPeriod, giftCardOnly]);

  const onClearFilterChange = (x: React.ChangeEvent<HTMLInputElement>) => {
    if (x.target.checked) {
      setOtherRecurringPrice(undefined);
      setWeekdaymask(undefined);
      setBillingPeriod(undefined);
      setGiftCardOnly(undefined);
    }
  };

  return (
    <div className="my-2">
      <div className="mb-2">
        <i
          role="button"
          className="gray"
          onClick={() => {
            setIsOpen(!isOpen);
            localStorage.setItem('rateplanFilterIsOpen', !isOpen ? 'true' : 'false');
          }}>
          {isOpen ? 'Skjul filtrer' : 'Vis filtrer'}
        </i>
      </div>
      <Collapse in={isOpen}>
        <div>
          <Row>
            <Col>
              <Form.Check
                type="radio"
                id="clear-filter"
                label="Alle abonnementstyper"
                checked={!otherRecurringPrice && !weekdaymask && !billingPeriod && !giftCardOnly}
                onChange={onClearFilterChange}
              />
              <p className="mb-1 mt-3">Anden slutpris</p>
              <Form.Check
                type="radio"
                id="recurringPrice-no"
                label="Nej"
                value="no"
                name="recurringPrice"
                checked={otherRecurringPrice === 'no'}
                onChange={(x) => setOtherRecurringPrice(x.target.value)}
              />
              <Form.Check
                type="radio"
                id="recurringPrice-yes"
                name="recurringPrice"
                value="yes"
                label="Ja"
                checked={otherRecurringPrice === 'yes'}
                onChange={(x) => setOtherRecurringPrice(x.target.value)}
              />

              <p className="mb-1 mt-3">Gavekort produkter</p>
              <Form.Check
                type="checkbox"
                id="giftCardProducts-check"
                label="Vis kun gavekort produkter"
                value="giftCardOnly"
                name="giftCardProducts"
                checked={giftCardOnly === true}
                onChange={(event) => setGiftCardOnly(event.target.checked)}
              />
            </Col>
          </Row>
          <Row>
            <Col>
              <p className="mb-1 mt-3">Omfatning</p>
              {Object.keys(weekdayOptions)
                .sort()
                .map((mask) => (
                  <Form.Check
                    type="radio"
                    key={mask}
                    id={mask}
                    name="weekdayMask"
                    value={mask}
                    label={mask}
                    checked={weekdaymask === mask}
                    onChange={(x) => setWeekdaymask(x.target.value)}
                  />
                ))}
            </Col>
            <Col>
              <p className="mb-1 mt-3">Betalingsperiode</p>
              {Object.keys(billingOptionsDisplay).map(
                (option) =>
                  billingOptions[option] && (
                    <Form.Check
                      type="radio"
                      id={option}
                      key={option}
                      name="billingPeriod"
                      value={option}
                      label={billingOptionsDisplay[option as BillingPeriod]}
                      checked={billingPeriod === option}
                      onChange={(x) => setBillingPeriod(x.target.value as BillingPeriod)}
                    />
                  )
              )}
            </Col>
          </Row>
        </div>
      </Collapse>
    </div>
  );
}
