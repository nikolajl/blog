import Button from '@/components/forms/Button';
import PageLayout from '@/components/layouts/PageLayout';
import Panel from '@/components/ui/Panel';
import Basket from './basket/Basket';
import { yupResolver } from '@hookform/resolvers/yup';
import { Col, Form, Row } from 'react-bootstrap';
import { FormProvider, useForm } from 'react-hook-form';
import AccountTypePanel from './AccountTypePanel';
import { newCustomerSchema, NewCustomerSchemaType } from './new-customer.schema';

import PaymentTermPanel from './PaymentTermPanel';
import SelectProductContainer from './SelectProductContainer';
import PaymentMethodPanel from './PaymentMethodPanel';
import BillingAddressPanel from './BillingAddressPanel';
import { useSubscriptionOrderPurchase } from '@/api/orders';
import { useEffect, useState } from 'react';
import PollingModal from './PollingModal';
import { BasketItemData } from './basket/BasketItemModels';
import { itemHasPrint } from './basket/basket.hooks';
import DeliveryAddressPanel from './DeliveryAddressPanel';
import SubscriptionPanel from './SubscriptionPanel';
import { MakeGenerics, useSearch } from '@tanstack/react-location';
import BillingInfoPanel from './components/BillingInfoPanel';
import { useGetAccountV2 } from '@/api/accounts';
import QuarantinePanel from './components/QuarantinePanel';
import { GlobalHotKeys } from 'react-hotkeys';
import { SubscritpionGroupSelect } from './SubscriptionGroupSelector';
import { useUser } from '@/api/user';

const keyMap = {
  CUSTOMER_OVERVIEW: 'Alt+j',
};

type RouteProps = MakeGenerics<{
  Search: {
    ssoId: string;
    accountNumber: string;
  };
}>;

export default function PurchaseSubscriptionPage() {
  const { ssoId, accountNumber } = useSearch<RouteProps>();
  const [showPollingModal, setShowPollingModal] = useState(false);
  const form = useForm<NewCustomerSchemaType>({
    resolver: yupResolver(newCustomerSchema),
    mode: 'onChange',
    defaultValues: {
      accountType: 'Consumer',
      paymentMethod: 'PaymentSlip',
      paymentTerms: 'FourteenDays',
      basket: [],
      brand: '',
      billingAddressType: 'DkAddress',
      deliveryAddressType: 'DkAddress',
      hasDeliveryAddress: !!ssoId && !!accountNumber,
    },
  });

  const { mutate, data, isLoading } = useSubscriptionOrderPurchase();
  const user = useUser();
  const [accountType] = form.watch(['accountType']);

  useEffect(() => {
    if (data?.data.redirectUrl) {
      window.location.assign(data?.data.redirectUrl);
    }
  }, [data?.data.redirectUrl]);

  const account = useGetAccountV2(accountNumber);
  useEffect(() => {
    if (account.data) {
      form.setValue('brand', account.data.basicInfo?.brandC);
    }
  }, [account.data]);

  const hotkeyHandlers = {
    CUSTOMER_OVERVIEW: () => {
      ssoId &&
        accountNumber &&
        window.location.assign(`/Customer/ViewCustomer/${ssoId}?accountNumber=${accountNumber}`);
    },
  };

  const onSubmit = (values: NewCustomerSchemaType) => {
    console.log('formvalues: ', values);
    mutate({
      ...values,

      paymentMethod: values.basket?.every((x) => x.type === 'product' && x.ratePlan.isTrial)
        ? 'NoPayment'
        : values.paymentMethod,
      paymentTerms: values.accountType === 'Business' ? values.paymentTerms : undefined,
      // Copy billing information to delivery information if
      // 1. Basket contains basket items and the delivery address has not been set
      deliveryAddress: values.hasDeliveryAddress
        ? values.deliveryAddress
        : values.basket?.some((x: BasketItemData) => itemHasPrint(x))
        ? Object.assign(values.billingAddress)
        : undefined,

      deliveryAddressType: values.hasDeliveryAddress
        ? values.deliveryAddressType
        : values.basket?.some((x: BasketItemData) => itemHasPrint(x))
        ? values.billingAddressType
        : undefined,

      // Add extra data
      // Special handling for basket items, so backend will know the correct model
      products: values.basket?.filter((x) => x.type === 'product'),
      discounts: values.basket?.filter((x) => x.type === 'discount'),
      campaigns: values.basket
        ?.filter((x) => x.type === 'campaign')
        // billingPeriodAlignment for campaigns only apply to the base step
        ?.map((x) => {
          if (x.billingPeriodAlignment && x.campaignOfferStep.type === 'BaseProductStep') {
            x.campaignOfferStep.billingPeriodAlignment = x.billingPeriodAlignment;
          }
          return x;
        }),
      subscriptionGroupId: values.subscriptionGroup?.id ?? undefined,
      mobilePayRedirectLink: window.location.host.includes('localhost')
        ? 'https://test-eb-kundeoverblik.jppol.dk/empty.html'
        : `${window.location.protocol}//${window.location.host}/empty.html`,

      // When page is used for add-subscription
      ssoId,
      accountNumber,
    });

    setShowPollingModal(true);
  };

  const isAddSubscription = !!ssoId && !!accountNumber;

  return (
    <PageLayout title={isAddSubscription ? 'Tilføj abonnement' : 'Opret ny kunde'}>
      <GlobalHotKeys keyMap={keyMap} handlers={hotkeyHandlers} />
      <FormProvider {...form}>
        <Form onSubmit={form.handleSubmit(onSubmit, (e) => console.log('form invalid', e))}>
          {/* TODO: handle this in a more general way (toastify?) */}
          <Row>
            <Col>
              <Panel title="Produktvælger">
                <SelectProductContainer disabled={isLoading || account.isFetching} />
              </Panel>
              <SubscriptionPanel />
              {!isAddSubscription && <AccountTypePanel />}
              {accountType === 'Business' &&
                user.data?.flags['ShowSubscriptionGroupPickerKO'] &&
                accountType === 'Business' && (
                  <Panel title="Abonnementsgruppe">
                    <SubscritpionGroupSelect
                      brand="JyllandsPosten"
                      onChange={(value) => form.setValue('subscriptionGroup', value ?? undefined)}
                    />
                  </Panel>
                )}
              {isAddSubscription ? (
                <>
                  <DeliveryAddressPanel />
                  <div className="row">
                    <BillingInfoPanel accountNumber={accountNumber} />
                    <QuarantinePanel ssoId={ssoId} />
                  </div>
                </>
              ) : (
                <>
                  <PaymentMethodPanel />
                  <PaymentTermPanel />
                  <BillingAddressPanel />
                </>
              )}

              {!isAddSubscription && <DeliveryAddressPanel />}
            </Col>
            <Col className="sticky">
              <Basket />
              <div className="d-flex flex-row-reverse">
                <Button
                  loading={isLoading}
                  disabled={isLoading || !form.getValues().basket?.length}
                  variant="success"
                  type="submit">
                  Køb
                </Button>
              </div>
            </Col>
          </Row>
        </Form>
      </FormProvider>
      {data?.data && !data?.data.redirectUrl && (
        <PollingModal show={showPollingModal} orderNumber={data?.data.orderNumber} />
      )}
    </PageLayout>
  );
}
