import InputRadioGroup from '@/components/forms/InputRadioGroup';
import Panel from '@/components/ui/Panel';

export default function AccountTypePanel() {
  return (
    <Panel title="Kontotype">
      <InputRadioGroup
        name="accountType"
        options={[
          { label: 'Privat', value: 'Consumer' },
          { label: 'Erhverv', value: 'Business' },
        ]}
      />
    </Panel>
  );
}
