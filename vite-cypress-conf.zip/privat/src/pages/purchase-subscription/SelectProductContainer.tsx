import { useState } from 'react';
import CampaignSelector from './CampaignSelector';
import ProductSelector from './ProductSelector';
import Button from '@/components/forms/Button';
import { ButtonGroup, Col, Row } from 'react-bootstrap';
import GiftCardSelector from './GiftCardSelector';
import { useUser } from '@/api/user';
import DiscountSelector from './DiscountSelector';

type SelectedType = 'Product' | 'Campaign' | 'GiftCard' | 'Discount';

type Props = {
  disabled?: boolean;
};

export default function SelectProductContainer({ disabled }: Props) {
  const [selected, setSelected] = useState<SelectedType>('Product');
  const user = useUser();

  return (
    <Row>
      <Col>
        <ButtonGroup className="mb-2">
          <Button
            variant="outline-primary"
            active={selected === 'Product'}
            onClick={() => setSelected('Product')}
            disabled={disabled}>
            Alm. produkt
          </Button>
          <Button
            variant="outline-primary"
            active={selected === 'Campaign'}
            onClick={() => setSelected('Campaign')}
            disabled={disabled}>
            Kampagne
          </Button>
          {user.data?.flags['AllowGiftcardPurchase'] && (
            <Button
              variant="outline-primary"
              active={selected === 'GiftCard'}
              onClick={() => setSelected('GiftCard')}>
              Gavekort
            </Button>
          )}
          {user.data?.flags['SpaDiscounts'] && ( // https://jira-jppol.atlassian.net/browse/UR-885
            <Button
              variant="outline-primary"
              active={selected === 'Discount'}
              onClick={() => setSelected('Discount')}>
              Rabat
            </Button>
          )}
        </ButtonGroup>
        <div className="my-2">
          {(() => {
            switch (selected) {
              case 'Product':
                return <ProductSelector disabled={disabled} />;
              case 'Campaign':
                return <CampaignSelector disabled={disabled} />;
              case 'GiftCard':
                return <GiftCardSelector disabled={disabled} />;
              case 'Discount':
                return <DiscountSelector disabled={disabled} />;
            }
          })()}
        </div>
      </Col>
    </Row>
  );
}
