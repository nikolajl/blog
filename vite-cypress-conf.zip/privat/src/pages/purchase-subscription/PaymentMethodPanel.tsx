import InputRadioGroup from '@/components/forms/InputRadioGroup';
import { useAuthContext } from '@/components/providers/AuthProvider';
import Panel from '@/components/ui/Panel';
import { useFormContext } from 'react-hook-form';
import { ProductBasketItem } from './basket/BasketItemModels';
import { paymentMethods } from './new-customer.schema';

export default function PaymentMethodPanel() {
  const auth = useAuthContext();
  const form = useFormContext();

  const basket = form.watch('basket');

  const hasMobilePay = auth?.user.flags['MobilePayPaymentMethod'];
  const hasCreditCard = auth?.user.flags['CreditCardPaymentMethod'];

  const options = paymentMethods.filter(
    (x) =>
      !(
        (x.value === 'MobilePay' && !hasMobilePay) ||
        (x.value === 'CreditCard' && !hasCreditCard) ||
        x.hidden
      )
  );

  // TODO: Use basket methods
  // Hide paymentMethod if trial
  if (basket.length && basket.every((x: ProductBasketItem) => x.ratePlan?.isTrial)) {
    return null;
  }

  return (
    <Panel title="Betalingsmetode">
      <InputRadioGroup name="paymentMethod" options={options} />
    </Panel>
  );
}
