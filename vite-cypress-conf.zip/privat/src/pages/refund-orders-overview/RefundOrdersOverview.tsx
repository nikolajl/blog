import { RefundOrder } from '@/api/types/refunds';
import { useAcceptRefundOrder, useRefundOrders, useRejectRefundOrder } from '@/api/refunds';
import Pagination from '@/components/Pagination';
import { formatCurrency, formatDate } from '@/utils/format';
import { useState } from 'react';
import cx from 'classnames';
import {
  Button,
  ButtonGroup,
  Col,
  Dropdown,
  DropdownButton,
  Spinner,
  Table,
} from 'react-bootstrap';
import DetailsModal from './DetailsModal';
import styles from './RefundOrdersOverview.module.scss';
import { FaCaretUp, FaCaretDown } from 'react-icons/fa';
import PageLayout from '@/components/layouts/PageLayout';
import { useAuthContext } from '@/components/providers/AuthProvider';
import FormDate from '@/components/forms/FormDate';
import { addDays } from 'date-fns';
import { useModal } from '@/components/providers/ModalProvider';
import Tooltip from '@/components/ui/Tooltip';
export const statusOptions = [
  { key: 'All', value: 'Alle' },
  { key: 'Created', value: 'Afventer' },
  { key: 'Accepted', value: 'Godkendt' },
  { key: 'Rejected', value: 'Afvist' },
  { key: 'Paid', value: 'Udbetalt' },
];

export default function RefundOrdersOverview() {
  const [sortDesc, setSortDesc] = useState(true);
  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const [filter, setFilter] = useState('Created');
  const [fromDate, setFromDate] = useState<Date | null>(null);
  const [toDate, setToDate] = useState<Date | null>(null);
  const { showModal, closeModal } = useModal();

  const { data, isLoading } = useRefundOrders(
    pageNumber,
    pageSize,
    filter === 'All' ? '' : filter,
    fromDate ?? undefined,
    toDate ? addDays(toDate, 1) : undefined // We add 1 day to be inclusive
  );
  const reject = useRejectRefundOrder();
  const accept = useAcceptRefundOrder();
  const auth = useAuthContext();
  const rejectRefund = (refundOrderId: string) =>
    reject.mutate({ refundOrderId }, { onSuccess: () => closeModal() });
  const acceptRefund = (refundOrderId: string) =>
    accept.mutate({ refundOrderId }, { onSuccess: () => closeModal() });
  const anyMutationIsLoading = reject.isLoading || accept.isLoading;

  const buttonDisabled = (order: RefundOrder) => {
    if (order.createdBy == auth?.user.user) return true;
    if (!auth?.user.claims.includes('Kundeoverblik.GodkendUdbetalinger')) return true; // important should be first!
    if (anyMutationIsLoading) return true;
    if (!!order.effectiveDate && new Date(order.effectiveDate) > new Date()) return true;
    if (order.status !== 'Created') return true;
    return false;
  };

  const sortData = () => {
    data?.refundOrders.sort((a, b) => {
      const adate = new Date(a.creationDate);
      const bdate = new Date(b.creationDate);

      if (sortDesc) return adate < bdate ? -1 : 1;
      return adate > bdate ? -1 : 1; // asc;
    });
  };
  const pageSizeOptions: number[] = [10, 25, 50, 100];

  return (
    <PageLayout title="Udbetalingsbestillinger">
      <ButtonGroup>
        {statusOptions.map((opts, index) => (
          <Button
            variant={'outline-primary'}
            key={'opts-' + index}
            type="button"
            onClick={() => {
              setFilter(opts.key);
              setPageNumber(1);
            }}
            active={filter == opts.key}>
            {opts.value}
          </Button>
        ))}
        <DropdownButton variant="secondary" as={ButtonGroup} title={`Antal per side: ${pageSize}`}>
          {pageSizeOptions.map((option) => (
            <Dropdown.Item
              key={option}
              onClick={() => {
                setPageSize(option);
                setPageNumber(1);
              }}>
              {option}
            </Dropdown.Item>
          ))}
        </DropdownButton>
      </ButtonGroup>
      <Col style={{ float: 'right' }}>
        <div className="d-flex">
          <div style={{ width: 125 }}>
            <FormDate
              size="sm"
              placeholderText="Fra dato"
              selected={fromDate}
              maxDate={toDate}
              onChange={(date) => date instanceof Date && setFromDate(date)}
            />
          </div>
          <div className="align-self-center mx-2">-</div>
          <div style={{ width: 125 }}>
            <FormDate
              size="sm"
              selected={toDate}
              minDate={fromDate}
              placeholderText="Til dato"
              onChange={(date) => date instanceof Date && setToDate(date)}
            />
          </div>
        </div>
      </Col>
      {isLoading && <p>Henter udbetalingsbestillinger...</p>}
      {!isLoading && (
        <>
          <Table striped hover variant="light" className="mt-3" responsive={'sm'}>
            <thead>
              <tr>
                <th
                  className="sortCol"
                  onClick={() => {
                    setSortDesc(!sortDesc);
                    sortData();
                  }}>
                  Dato {sortDesc ? <FaCaretDown /> : <FaCaretUp />}
                </th>
                <th>Id</th>
                <th>Detaljer</th>
                <th>Kontonummer</th>
                <th>Type</th>
                <th>Status</th>
                <th>Beløb</th>
                <th>Oprettet af</th>
                <th>Behandlet af</th>
                <th>Handlinger</th>
              </tr>
            </thead>
            <tbody>
              {data?.refundOrders
                ?.filter((x) => (filter != 'All' ? x.status == filter : x))
                .map((order) => {
                  const createdByYou = order.createdBy === auth?.user.user;
                  return (
                    <tr key={'refund-' + order.id}>
                      <td>{formatDate(order.creationDate)}</td>
                      <td>{order.id}</td>
                      <td>
                        <Button
                          size="sm"
                          variant="outline-primary"
                          onClick={() => {
                            showModal(
                              'Udbetalingsdetaljer',
                              <DetailsModal
                                id={order.id}
                                acceptHandler={(id) => {
                                  acceptRefund(id);
                                }}
                                rejectHandler={(id) => {
                                  rejectRefund(id);
                                }}
                                disableActions={
                                  !auth?.user.claims.includes('Kundeoverblik.GodkendUdbetalinger')
                                }
                                disableAccept={buttonDisabled(order)}
                              />,
                              true,
                              { size: 'lg' }
                            );
                          }}>
                          Se detaljer
                        </Button>
                      </td>
                      <td>
                        <a href={`/Customer/Results?input=${order.accountNumber}`}>
                          {order.accountNumber}
                        </a>
                      </td>
                      <td>{order.sourceType === 'Payment' ? 'Indbetaling' : 'Tilgodehavende'}</td>
                      <td>{statusOptions.find((x) => x.key == order.status)?.value ?? ''}</td>
                      <td>{formatCurrency(order.amount)}</td>
                      <td className={cx(createdByYou ? styles.createdByYou : null)}>
                        {order.createdBy}
                        {createdByYou && (
                          <Tooltip>
                            Denne ordre er oprettet af dig, og du kan derfor ikke godkende
                          </Tooltip>
                        )}
                      </td>
                      <td>{order.handledBy}</td>
                      <td className="col-2">
                        <ButtonGroup size="sm">
                          <Button
                            size="sm"
                            className={styles.rejectAcceptButton}
                            variant="success"
                            onClick={() => acceptRefund(order.id)}
                            disabled={buttonDisabled(order)}>
                            {accept.isLoading && (
                              <Spinner
                                className={styles.buttonSpinner}
                                as="span"
                                animation="grow"
                                size="sm"
                              />
                            )}
                            {accept.isLoading ? 'henter...' : 'Godkend'}
                          </Button>
                          <Button
                            size="sm"
                            className={styles.rejectAcceptButton}
                            variant="outline-danger"
                            onClick={() => rejectRefund(order.id)}
                            disabled={
                              order.status != 'Created' ||
                              anyMutationIsLoading ||
                              !auth?.user.claims.includes('Kundeoverblik.GodkendUdbetalinger')
                            }>
                            {reject.isLoading && (
                              <Spinner
                                className={styles.buttonSpinner}
                                as="span"
                                animation="grow"
                                size="sm"
                              />
                            )}
                            {reject.isLoading ? 'henter...' : 'Afvis'}
                          </Button>
                        </ButtonGroup>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
          <Pagination
            pageNumber={pageNumber}
            pageSize={pageSize}
            setPageNumber={setPageNumber}
            totalCount={data?.totalCount ?? 1}
          />
        </>
      )}
    </PageLayout>
  );
}
