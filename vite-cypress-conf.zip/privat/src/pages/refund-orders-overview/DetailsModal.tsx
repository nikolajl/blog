import { formatCurrency, formatDate } from '@/utils/format';
import { Button, Col, Container, Modal, Row, Spinner } from 'react-bootstrap';
import { useRefundOrderDetails } from '../../api/refunds';
import { statusOptions } from './RefundOrdersOverview';
import styles from './RefundOrdersOverview.module.scss';
interface Props {
  id: string;
  acceptHandler: (id: string) => void;
  rejectHandler: (id: string) => void;
  disableActions?: boolean;
  disableAccept?: boolean;
}

export default function DetailsModal(props: Props) {
  const { id, acceptHandler, rejectHandler, disableActions, disableAccept } = props;

  const detailsQuery = useRefundOrderDetails(id);

  const detailsData = detailsQuery.data;
  const isLoading = detailsQuery.isLoading;

  return (
    <>
      <Container>
        {isLoading ? (
          <Row>
            <div className="center-block">
              <Spinner animation="border" variant="info"></Spinner>
            </div>
          </Row>
        ) : (
          <Row>
            <Col>
              <h2>Grundlæggende oplysninger</h2>
              <div>
                <strong>Dato: </strong>{' '}
                <div className={styles.right}>{formatDate(detailsData?.creationDate)}</div>
              </div>
              <div>
                <strong>Status: </strong>
                <div className={styles.right}>
                  {statusOptions.find((x) => x.key == detailsData?.status)?.value}
                </div>
              </div>

              <div>
                <strong>Kunde: </strong>
                <div className={styles.right}>{detailsData?.accountNumber}</div>
              </div>
              <div>
                <strong>Oprettet af: </strong>
                <div className={styles.right}>{detailsData?.createdBy}</div>
              </div>
              <div>
                <strong>Godkendt af: </strong>

                <div className={styles.right}>{detailsData?.handledBy}</div>
              </div>
              <div>
                <strong>Reference: </strong>
                <div className={styles.right}>{detailsData?.refundNumber}</div>
              </div>
              <div>
                <strong>Kommentar til kunden: </strong>
                <div className={styles.right}>{detailsData?.noteToCustomer}</div>
              </div>
              <div>
                <strong>Kommentar fra kundecenter: </strong>
                <div className={styles.commentBox}>{detailsData?.comment}</div>
              </div>
            </Col>
            <Col>
              <h2>Detaljer om anmodning</h2>
              <div>
                {detailsData?.refundFullAmount ? (
                  <>
                    <strong>Anmodet om fuldt beløb?</strong>
                    <div className={styles.right}>
                      {detailsData.refundFullAmount ? 'Ja' : 'Nej'}
                    </div>
                    <div>
                      <strong>Tidligste udbetalingsdato:</strong>
                      <div className={styles.right}>
                        {detailsData.effectiveDate
                          ? formatDate(detailsData.effectiveDate)
                          : 'hurtigst muligt'}
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <strong>Beløb: </strong>
                    <div className={styles.right}> {formatCurrency(detailsData?.amount)}</div>
                  </>
                )}
              </div>
              {detailsData?.amountRefunded && (
                <div>
                  <strong>Refunderet beløb: </strong>
                  <div className={styles.right}>{formatCurrency(detailsData?.amountRefunded)}</div>
                </div>
              )}
              <div>
                <strong>Reference: </strong>
                <div className={styles.right}>
                  {detailsData?.sourceType === 'Payment'
                    ? detailsData?.paymentNumber
                    : 'Tilgodehavende'}
                </div>
              </div>
              <div>
                <strong>Type: </strong>
                <div className={styles.right}>
                  {detailsData?.refundChannel === 'BankTransfer' ? 'Alm. udbetaling' : 'Kreditkort'}
                </div>
              </div>
              <div>
                <strong>Udbetales til: </strong>

                {detailsData?.refundChannel === 'BankTransfer' ? (
                  <div>
                    <div>
                      Reg. nr. <span className={styles.right}>{detailsData?.regNr}</span>
                    </div>

                    <div>
                      Kontonr. <span className={styles.right}>{detailsData?.kontoNr}</span>
                    </div>
                  </div>
                ) : (
                  <Row>
                    <Col>
                      <div>Korttype:</div>
                      <div>Kortnr:</div>
                      <div>Udløbsdato:</div>
                    </Col>

                    <Col>
                      <div>{detailsData?.paymentMethodCreditCardType}</div>
                      <div>{detailsData?.paymentMethodCreditCardNumberMask}</div>
                      <div>
                        {detailsData?.paymentMethodCreditCardExpirationMonth}/
                        {detailsData?.paymentMethodCreditCardExpirationYear}
                      </div>
                    </Col>
                  </Row>
                )}

                <div>
                  <strong>Adresse: </strong>
                  <div>{detailsData?.accountBillToContactLabel01}</div>
                  <div>{detailsData?.accountBillToContactLabel02}</div>
                  <div>{detailsData?.accountBillToContactLabel03}</div>
                  <div>{detailsData?.accountBillToContactLabel04}</div>
                  <div>{detailsData?.accountBillToContactLabel05}</div>
                  <div>{detailsData?.accountBillToContactLabel06}</div>
                  <div>{detailsData?.accountBillToContactLabel07}</div>
                  <div>{detailsData?.accountBillToContactLabel08}</div>
                </div>
              </div>
            </Col>
          </Row>
        )}
      </Container>
      <Modal.Footer>
        {detailsData?.status === 'Created' && (
          <>
            <Button
              onClick={() => {
                acceptHandler(id);
              }}
              variant="success"
              disabled={
                disableAccept ||
                (!!detailsData.effectiveDate && new Date(detailsData.effectiveDate) > new Date()) ||
                disableActions
              }>
              Godkend
            </Button>
            <Button
              variant="outline-danger"
              onClick={() => {
                rejectHandler(id);
              }}
              disabled={disableActions}>
              Afvis
            </Button>
          </>
        )}
      </Modal.Footer>
    </>
  );
}
