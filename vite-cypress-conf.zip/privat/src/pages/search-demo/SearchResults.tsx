import { useSearch } from '@/api/search';
import { Col, Row, Spinner, Table } from 'react-bootstrap';

type SearchResultsProp = {
  input: string;
};

export function SearchResults({ input }: SearchResultsProp) {
  const search = useSearch(input);

  if (search.isFetching) {
    return <Spinner animation="border" />;
  }

  return (
    <Row>
      <Col>
        <h2>Resultat af søgning {input} </h2>
        <Table striped>
          <thead>
            <tr>
              <th>Navn</th>
              <th>Email</th>
              <th>Ident</th>
              <th>IdentType</th>
              <th>Datakilde</th>
            </tr>
          </thead>
          <tbody>
            {search.data?.map((x, i) => (
              <tr key={x.ssoId + i}>
                <td>{x.name}</td>
                <td>{x.email}</td>
                <td>{x.zuoraSubscriptionNumber ?? x.zuoraAccountNumber ?? x.ssoId}</td>
                <td>{x.identType}</td>
                <td>{x.dataSource}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Col>
    </Row>
  );
}
