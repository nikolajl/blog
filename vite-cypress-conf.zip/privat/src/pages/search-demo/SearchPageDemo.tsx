import * as yup from 'yup';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { Button, Col, Form, FormControl, InputGroup, Row } from 'react-bootstrap';
import PageLayout from '@/components/layouts/PageLayout';
import { SearchResults } from './SearchResults';

const schema = yup.object({
  search: yup.string().trim().required(),
});

type FormValues = yup.InferType<typeof schema>;

export default function SearchPageDemo() {
  const [input, setInput] = useState('');

  const form = useForm<FormValues>({
    resolver: yupResolver(schema),
  });

  return (
    <PageLayout title="Kundesøgning">
      <Row>
        <Col></Col>
        <Col>
          <Form onSubmit={form.handleSubmit((values) => setInput(values.search))}>
            <InputGroup>
              <FormControl
                type="text"
                {...form.register('search')}
                isInvalid={!!form.formState.errors.search}
              />
              <Button type="submit">Søg</Button>
            </InputGroup>
          </Form>
        </Col>
        <Col></Col>
      </Row>
      {input && <SearchResults input={input} />}
    </PageLayout>
  );
}
