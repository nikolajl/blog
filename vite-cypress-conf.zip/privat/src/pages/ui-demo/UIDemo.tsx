import { /* Button, */ Col, Container, Row } from 'react-bootstrap';
import Button from '@/components/forms/Button';
import { useState } from 'react';
import FormDate from '@/components/forms/FormDate';
import CurrencyInput from '@/components/forms/CurrencyInput';
export default function UIDemo() {
  // Button
  const [loading, setLoading] = useState(false);

  // FormDate
  const [date, setDate] = useState(new Date());

  // CurrencyInput
  const [amount, setAmount] = useState(0);
  return (
    <Container>
      <h1>UI Demo</h1>

      <Row>
        <h2 className="mt-3">Buttons</h2>
        <Col>
          <h3>All variants</h3>
          <Button variant="primary">Primary</Button>
          <Button variant="secondary">Secondary</Button>
          <Button variant="success">Success</Button>
          <Button variant="danger">Danger</Button>
          <Button variant="warning">Warning</Button>
          <Button variant="info">Info</Button>
          <Button variant="light">Light</Button>
          <Button variant="dark">Dark</Button>
          <Button variant="link">Link</Button>
        </Col>
      </Row>
      <h3 className="mt-3">Usage</h3>

      <Row className="mt-2">
        <Col>
          <Button variant="primary">Page Navigation</Button>
          <div>Navigation between pages</div>
        </Col>
      </Row>
      <hr />
      <Row className="mt-2">
        <Col>
          <Button variant="secondary">Local Nav</Button>
          <div>
            <span className="fst-italic">In page</span> navigation. Filters, radiosgroups etc.
          </div>
        </Col>
      </Row>
      <hr />
      <Row className="mt-2">
        <Col>
          <Button variant="success">Action</Button>
          <div>Action buttons, submit, send etc.</div>
        </Col>
        <Col>
          <Button
            variant="success"
            loading={loading}
            onClick={() => {
              setLoading(true);
              setTimeout(() => {
                setLoading(false);
              }, 3000);
            }}>
            {loading ? 'Submitting' : 'Submit'}
          </Button>
          <div>The loading prop set to {loading ? 'true' : 'false'}</div>
        </Col>
      </Row>
      <hr />
      <Row className="mt-2">
        <Col>
          <Button variant="danger">Delete</Button>
          <div>For descructive action types. Delete remove etc.</div>
        </Col>
      </Row>
      <hr />
      <Row className="mt-2">
        <Col>
          <Button variant="warning">Warning</Button>
        </Col>
        <div>Warnings</div>
      </Row>
      <hr />
      <Row className="mt-4">
        <h2>FormDate</h2>
        <Col>
          <FormDate
            selected={date}
            placeholderText="Vælg dato"
            onChange={(date) => {
              date instanceof Date && setDate(date);
            }}
          />
          <div className="mt-2">
            Chosen Date: <strong>{date.toLocaleDateString()}</strong>
          </div>
        </Col>
      </Row>
      <Row className="mt-4">
        <h2>CurrencyInput</h2>
        <Col xs sm="2">
          <CurrencyInput
            value={amount}
            onChange={(value) => {
              value && setAmount(value);
            }}
          />
        </Col>
      </Row>
    </Container>
  );
}
