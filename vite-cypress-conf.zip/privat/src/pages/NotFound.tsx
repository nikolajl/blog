import { Col, Container, Row } from 'react-bootstrap';

export default function NotFound() {
  return (
    <main>
      <Container>
        <Row>
          <Col>
            <h2 className="text-danger">Fejl</h2>
            <p className="text-danger">Den angivne side kan ikke findes</p>
            <p>
              <strong>Fejlkode: 404</strong>
            </p>
          </Col>
        </Row>
      </Container>
    </main>
  );
}
