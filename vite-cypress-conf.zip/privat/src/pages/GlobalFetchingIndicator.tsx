import { useIsFetching } from '@tanstack/react-query';

export default function GlobalFetchingIndicator() {
  const isFetching = useIsFetching();

  return isFetching ? <div>Queries are fetching in the background...</div> : null;
}
