import Guard from '@/components/navigation/Guard';
import NotFound from '@/pages/NotFound';
import RefundOrdersOverview from '@/pages/refund-orders-overview/RefundOrdersOverview';
import { Route } from '@tanstack/react-location';
import customerRoutes from './customers/customer-routes';
import PurchaseSubscriptionPage from './purchase-subscription/PurchaseSubscriptionPage';
import SearchPageDemo from './search-demo/SearchPageDemo';
import UIDemo from './ui-demo/UIDemo';

const DisallowedTenants = ['Watch', 'Monitormedier'];

const routes: Route[] = [
  customerRoutes,
  {
    path: 'refund-orders',
    element: (
      <Guard allow={({ user }) => user.flags.EasyRefund}>
        <RefundOrdersOverview />
      </Guard>
    ),
  },
  {
    path: 'purchase-subscription',
    element: (
      <Guard
        allow={({ user }) => !DisallowedTenants.includes(user.selectedTenant.name)}
        message={
          'Det er ikke muligt at oprette abonnementer via denne side. Brug B2BAdmin i stedet for.'
        }>
        <PurchaseSubscriptionPage />
      </Guard>
    ),
  },
  {
    path: 'search-demo',
    element: <SearchPageDemo />,
  },
  {
    path: 'ui-demo',
    element: <UIDemo />,
  },
  {
    path: '*',
    element: <NotFound />,
  },
];

export default routes;
