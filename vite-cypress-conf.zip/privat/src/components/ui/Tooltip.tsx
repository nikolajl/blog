import { PropsWithChildren } from 'react';
import { OverlayTrigger } from 'react-bootstrap';
import BSTooltip from 'react-bootstrap/Tooltip';
import { FaQuestionCircle } from 'react-icons/fa';
import styles from './Tooltip.module.scss';

type Props = PropsWithChildren;

export default function Tooltip({ children }: Props) {
  return (
    <OverlayTrigger placement="top" overlay={<BSTooltip>{children}</BSTooltip>}>
      <div id={styles.tooltip}>
        <FaQuestionCircle size={16} />
      </div>
    </OverlayTrigger>
  );
}
