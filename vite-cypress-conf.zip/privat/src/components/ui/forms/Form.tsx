import { yupResolver } from '@hookform/resolvers/yup';
import { PropsWithChildren } from 'react';
import { Form, FormProps } from 'react-bootstrap';
import { FieldValues, FormProvider, useForm, UseFormProps } from 'react-hook-form';
import * as yup from 'yup';
import { TypedSchema } from 'yup/lib/util/types';

export type InferType<T extends TypedSchema> = yup.InferType<T>;

export function useYupForm<TFieldValues extends FieldValues, TContext>(
  builder: (schema: typeof yup) => yup.ObjectSchema<TFieldValues>,
  options?: UseFormProps<TFieldValues, TContext>
) {
  const schema = builder(yup);
  const defaultValues = schema.default({});

  const form = useForm({
    resolver: yupResolver(schema),
    defaultValues,
    ...options,
  });

  function YupForm({
    onSubmit,
    children,
    ...props
  }: PropsWithChildren<
    {
      onSubmit: <T extends yup.InferType<typeof schema>>(values: T) => void;
    } & Omit<FormProps, 'onSubmit'>
  >) {
    return (
      <FormProvider {...form}>
        <Form onSubmit={form.handleSubmit(onSubmit)} {...props}>
          {children}
        </Form>
      </FormProvider>
    );
  }

  return {
    YupForm,
    defaultValues,
    form,
    schema,
  };
}

/* TODO: Example of use 
import { FormInput } from './FormInput';

export function TestComponent() {
  const { YupForm, form, schema } = useYupForm((yup) => yup.object({ name: yup.string() }));

  // Watches a specific form value
  const name = form.watch('name');
  console.log({ name });

  // form submit handler; only triggers when form is valid. Use ui/<FormError name="*"/> or form.formState.errors to display validation errors.
  const onSubmit = (values: InferType<typeof schema>) => {
    console.log(values.name);
  };

  return (
    <YupForm onSubmit={onSubmit}>
      <FormInput name="name" />
    </YupForm>
  );
}
*/
