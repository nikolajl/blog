import da from 'date-fns/locale/da';
import { Form, FormControlProps } from 'react-bootstrap';
import DatePicker, {
  ReactDatePickerProps,
  registerLocale,
  setDefaultLocale,
} from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { get, useFormContext } from 'react-hook-form';
import { FaCalendarDay } from 'react-icons/fa';
import cx from 'classnames';

registerLocale('da', da);
setDefaultLocale('da');

type Props = {
  name: string;
} & Omit<ReactDatePickerProps, 'onChange' | 'selected'> &
  Pick<FormControlProps, 'size'> & { isInvalid?: boolean };

/**
 * Controlled DatePicker component served as React-bootstrap Form.Control
 */
export default function FormDate({ name, size, required, ...props }: Props) {
  const form = useFormContext();
  const error = get(form.formState.errors, name);
  const isInvalid = error !== undefined;
  const value = form.watch(name);

  return (
    <div className="position-relative d-inline-block">
      <DatePicker
        name={name}
        {...props}
        className={cx(props.className, { required })}
        dateFormat="dd-MM-yyyy"
        onChange={(date) => form.setValue(name, date ?? undefined)}
        selected={value}
        customInput={<Form.Control type="text" {...{ size, isInvalid }} />}
      />
      {!isInvalid && (
        <FaCalendarDay className="position-absolute top-50 end-0 translate-middle-y me-2" />
      )}
    </div>
  );
}
