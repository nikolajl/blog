import { formatCurrency } from '@/utils/format/currency';
import { Form, FormControlProps, InputGroup } from 'react-bootstrap';
import { get, useFormContext } from 'react-hook-form';
import NumberFormat, { NumberFormatValues } from 'react-number-format';

type Props = Pick<FormControlProps, 'size' | 'disabled'> & {
  dataCy?: string;
  name: string;
  currency?: string;
};

export default function FormCurrency({
  dataCy,
  name,
  size = 'sm',
  currency = 'DKK',
  ...props
}: Props) {
  const form = useFormContext();
  const error = get(form.formState.errors, name);
  const isInvalid = error !== undefined;
  const value = form.watch(name);

  return (
    <>
      <InputGroup>
        <InputGroup.Text>{formatCurrency(currency)}</InputGroup.Text>
        <NumberFormat
          name={name}
          customInput={Form.Control}
          data-cy={dataCy}
          style={{ textAlign: 'right' }}
          size={size}
          thousandSeparator="."
          decimalSeparator=","
          decimalScale={2}
          value={value}
          onValueChange={(values: NumberFormatValues) => {
            form.setValue(name, values.floatValue);
          }}
          isInvalid={isInvalid}
          {...props}
        />
      </InputGroup>
      <Form.Text>{error?.message.toString()}</Form.Text>
    </>
  );
}
