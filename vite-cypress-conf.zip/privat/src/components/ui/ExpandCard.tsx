import cx from 'classnames';

type Props = React.PropsWithChildren<{
  customClass?: string;
  open?: boolean;
}>;

const Summary = ({ children, customClass }: React.PropsWithChildren<Props>) => (
  <summary className={customClass}>{children}</summary>
);
const Section = ({ children, customClass }: React.PropsWithChildren<Props>) => (
  <section className={customClass}>{children}</section>
);

interface ExpandCardSubComponents {
  Summary: React.FC<Props>;
  Section: React.FC<Props>;
}

const ExpandCard: React.FC<Props> & ExpandCardSubComponents = ({
  children,
  customClass,
  open,
}: Props) => {
  return (
    <details className={cx('expand-card', customClass || '')} open={open}>
      {children}
    </details>
  );
};

ExpandCard.Summary = Summary;
ExpandCard.Section = Section;

export default ExpandCard;
