import React, { useState } from 'react';
import cx from 'classnames';
import styles from './Panel.module.scss';
import { Collapse, FormCheck } from 'react-bootstrap';

type Props = {
  title: string;
  className?: string;
  optional?: boolean;
  initialOpen?: boolean;
  toggleHandler?: (checked: boolean) => void;
  disabled?: boolean;
};

export default function Panel({
  title,
  children,
  className,
  optional = false,
  initialOpen = true,
  toggleHandler,
  disabled = false,
}: React.PropsWithChildren<Props>) {
  const [isOpen, setIsOpen] = useState(initialOpen);
  return (
    <div className={cx('mb-3 rounded', className)}>
      <div className={cx(styles.panelHeader, 'rounded-top')}>
        {optional ? (
          <FormCheck
            checked={isOpen}
            disabled={disabled}
            id={title}
            label={title}
            onChange={(e) => {
              toggleHandler && toggleHandler(e.target.checked);
              setIsOpen(e.target.checked);
            }}
          />
        ) : (
          <div>{title}</div>
        )}
      </div>
      <Collapse in={isOpen}>
        <div className={cx(styles.panelBody, 'rounded-bottom')}>{children}</div>
      </Collapse>
    </div>
  );
}
