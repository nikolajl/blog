import { PropsWithChildren, useEffect, useState } from 'react';
import { Container, ProgressBar } from 'react-bootstrap';
import Breadcrumbs, { Crumb } from '../navigation/Breadcrumbs';
import Footer from '../navigation/Footer';

type Props = PropsWithChildren<{
  title: string;
  crumbs?: Crumb[];
  isLoading?: boolean;
  error?: unknown;
}>;

export default function PageLayout({ title, crumbs = [], isLoading, error, children }: Props) {
  // TODO: This sort of error should probably result in an error page, since it means no content is shown.
  // console.log({ error });
  return (
    <>
      <div className="page-header">
        <Container>
          <Breadcrumbs title={title} crumbs={crumbs} />
          <h1>{title}</h1>
        </Container>
        <PretendProgressBar isLoading={isLoading && !error} />
      </div>
      <Container>{children}</Container>
      <Footer />
    </>
  );
}

type PretendProgressBarProps = {
  isLoading?: boolean;
};

function PretendProgressBar({ isLoading }: PretendProgressBarProps) {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const token = setInterval(() => {
      if (isLoading) {
        setProgress((x) => x + (100 - x) / 2);
      } else {
        setProgress(100);
        clearInterval(token);
      }
    }, 500);

    return () => clearInterval(token);
  }, [isLoading]);

  if (!isLoading) return null;

  return <ProgressBar now={progress} style={{ height: 2 }} animated={isLoading} />;
}
