import React, { PropsWithChildren, useReducer } from 'react';
import { Modal, ModalProps } from 'react-bootstrap';

type ModalType = {
  isOpen: boolean;
  title: string;
  content: JSX.Element;
} & ModalProps;

type Action = { type: 'open'; payload: ModalType } | { type: 'close' };
type Dispatch = (action: Action) => void;
type State = ModalType;

const ModalContext = React.createContext<{ state: State; dispatch: Dispatch } | undefined>(
  undefined
);

const initialState: State = {
  isOpen: false,
  title: '',
  content: <></>,
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'open': {
      return action.payload;
    }
    case 'close': {
      return { ...state, isOpen: false };
    }
  }
}

export function useModal() {
  const context = React.useContext(ModalContext);
  if (context === undefined) {
    throw 'useModal was used outside ModalProvider';
  }

  const { dispatch } = context;

  return {
    showModal(title: string, content: JSX.Element, isOpen = true, options?: ModalProps) {
      dispatch({ type: 'open', payload: { title, content, isOpen, ...options } });
    },
    closeModal() {
      dispatch({ type: 'close' });
    },
  };
}

export default function ModalProvider({ children }: PropsWithChildren) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const value = { state, dispatch };
  return (
    <ModalContext.Provider value={value}>
      {children}
      <Modal show={state.isOpen} onHide={() => dispatch({ type: 'close' })} size={state.size}>
        <Modal.Header closeButton>
          <Modal.Title>{state.title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>{state.content}</Modal.Body>
      </Modal>
    </ModalContext.Provider>
  );
}
