import { UserInfo, useUser } from '@/api/user';
import React, { PropsWithChildren, useContext } from 'react';

export type AuthContext = {
  user: UserInfo;
};

const AuthContext = React.createContext<AuthContext | undefined>(undefined);

export function useAuthContext() {
  const value = useContext(AuthContext);
  return value;
}

export default function AuthProvider({ children }: PropsWithChildren) {
  const user = useUser();

  const value = user.data
    ? {
        user: user.data,
      }
    : undefined;

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

/** For use when integration testing, e.g. with cypress */
export function MockAuthProvider({ children, user }: PropsWithChildren<AuthContext>) {
  return <AuthContext.Provider value={{ user }}>{children}</AuthContext.Provider>;
}
