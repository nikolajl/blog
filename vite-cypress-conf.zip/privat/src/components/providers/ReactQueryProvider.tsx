import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import axios, { AxiosError } from 'axios';
import { PropsWithChildren } from 'react';
import { useToastProvider } from '../messages/ToastProvider';

export default function ReactQueryProvider({ children }: PropsWithChildren) {
  const { showError } = useToastProvider();
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        refetchOnWindowFocus: false,
        // TODO: Test if we really want popup mayhem as default
        onError(error) {
          if (isApiError(error)) {
            showError(error.response?.data.message as string);
          }
        },
      },
    },
  });

  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>;
}

function isApiError(error?: unknown): error is AxiosError<ApiError> {
  return axios.isAxiosError(error) && !!(error.response?.data as ApiError).message;
}

type ApiError = {
  message: string;
};
