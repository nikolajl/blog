import { useAccountPayments } from '@/api/accounts';
import { Payment } from '@/api/types/accounts';
import { formatCurrency, formatDate } from '@/utils/format';
import { MakeGenerics, useMatch } from '@tanstack/react-location';
import { useState } from 'react';
import {
  Badge,
  ButtonGroup,
  Container,
  Dropdown,
  DropdownButton,
  Spinner,
  Table,
} from 'react-bootstrap';
import Pagination from './Pagination';

type RouteProps = MakeGenerics<{
  Params: {
    ssoId: string;
    accountNumber: string;
    invoiceId?: string;
  };
}>;

export function PaymentsTable() {
  const { params } = useMatch<RouteProps>();

  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const { data, isLoading } = useAccountPayments(params.accountNumber, pageSize, pageNumber);

  const pageSizeOptions: number[] = [20, 40];

  const getPaymentMethod = (payment: Payment): string | null => {
    const { creditCard, paymentMethodType } =
      data?.paymentMethods.find((x) => x.id.toString() === payment.paymentMethodID) ?? {};

    if (creditCard) return creditCard.cardType;
    if (payment.mpPaymentStatus && payment.mpPaymentStatus != 'N/A') return 'MobilePay';
    return paymentMethodType?.toString() ?? null;
  };

  // TODO: Use formatPaymentStatus ?
  const displayPaymentStatus = {
    Draft: 'Kladde',
    Processing: 'Gennemføres',
    Processed: 'Gennemført',
    Error: 'Fejl',
    Voided: 'Anulleret af forretningen',
    Canceled: 'Annulleret af kunden',
    Posted: 'Sendt',
  };

  return (
    <>
      <DropdownButton
        variant="secondary"
        as={ButtonGroup}
        title={`Antal per side: ${pageSize}`}
        className={'mb-2'}>
        {pageSizeOptions.map((option) => (
          <Dropdown.Item
            key={option}
            onClick={() => {
              setPageSize(option);
              setPageNumber(1);
            }}>
            {option}
          </Dropdown.Item>
        ))}
      </DropdownButton>
      <Table striped hover variant="light">
        <thead>
          <tr>
            <th>Betalingsdato</th>
            <th>Beløb</th>
            <th>Betalingsnummer</th>
            <th>Faktura(er)</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {!isLoading &&
            data?.payments
              ?.filter((x) =>
                params.invoiceId
                  ? x.paidInvoices.find((x) => x.invoiceId === params.invoiceId)
                  : true
              )
              .map((payment) => (
                <tr key={payment.id}>
                  <td>{formatDate(payment.effectiveDate)}</td>
                  <td>
                    {formatCurrency(payment.amountAsDecimal)}
                    {getPaymentMethod(payment) && (
                      <>
                        {' '}
                        <Badge bg={'secondary'}>{getPaymentMethod(payment)}</Badge>
                      </>
                    )}
                  </td>
                  <td>{payment.paymentNumber}</td>
                  <td>
                    {payment.paidInvoices
                      .map((x) => x.invoiceNumber)
                      .map((invoiceNumber) => (
                        <span key={invoiceNumber} style={{ display: 'block' }}>
                          <a href={`/Customer/Results?input=${invoiceNumber}`}>{invoiceNumber}</a>
                        </span>
                      ))}
                  </td>
                  <td>{displayPaymentStatus[payment.status]}</td>
                </tr>
              ))}
        </tbody>
      </Table>
      {isLoading && (
        <Container className="mx-auto text-center">
          <Spinner size="sm" animation="border" />
          Henter data...
        </Container>
      )}
      <Pagination
        pageNumber={pageNumber}
        pageSize={pageSize}
        hasNextPage={data?.hasNextPage}
        setPageNumber={setPageNumber}
      />
    </>
  );
}
