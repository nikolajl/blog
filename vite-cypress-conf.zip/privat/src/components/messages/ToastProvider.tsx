import React, { createContext, PropsWithChildren, useReducer } from 'react';
import { Toast, ToastContainer } from 'react-bootstrap';
import cx from 'classnames';

type Variant = 'success' | 'danger' | 'warning' | 'info';
type Message = {
  show: boolean;
  variant: Variant;
  id: number;
  title: string;
  info?: string;
  body: string;
  delay?: number;
};

type Action = { type: 'add'; payload: Message } | { type: 'remove'; payload: Message };
type Dispatch = (action: Action) => void;
type State = Message[];

const ToastContext = createContext<{ state: State; dispatch: Dispatch } | undefined>(undefined);

let id = 1;
const initialState: Message[] = [];
function reducer(tmp: State = [], action: Action) {
  const state = tmp.filter((x) => x.show);
  switch (action.type) {
    case 'add': {
      return [...state, action.payload];
    }
    case 'remove': {
      return state.map((x) => (x === action.payload ? { ...x, show: false } : x));
    }
  }
}

function addMessage(title: string, body: string, variant: Variant, delay?: number): Action {
  return {
    type: 'add',
    payload: {
      id: id++,
      title,
      variant,
      delay,
      show: true,
      body,
    },
  };
}

export function useToastProvider() {
  const context = React.useContext(ToastContext);
  if (context === undefined) {
    throw 'useToastProvider was used outside ToastProvider';
  }

  const { dispatch } = context;
  return {
    showError(body: string, title = 'Fejl', delay?: number) {
      dispatch(addMessage(title, body, 'danger', delay));
    },
    showSuccess(body: string, title = 'Succes', delay?: number) {
      dispatch(addMessage(title, body, 'success', delay));
    },
    showInfo(body: string, title = 'Info', delay?: number) {
      dispatch(addMessage(title, body, 'info', delay));
    },
  };
}

export default function ToastProvider({ children }: PropsWithChildren) {
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <ToastContext.Provider value={{ state, dispatch }}>
      {children}
      <ToastContainer position="top-end" className="p-3 h-100">
        <div className="sticky">
          {state.map((x) => (
            <Toast
              key={x.id}
              onClose={() => dispatch({ type: 'remove', payload: x })}
              bg={x.variant}
              className={cx({ 'text-light': x.variant === 'danger' })}
              show={x.show}
              delay={x.delay}
              autohide={!!x.delay}>
              <Toast.Header>
                <strong className="me-auto">{x.title}</strong>
                <small className="text-muted">{x.info}</small>
              </Toast.Header>
              <Toast.Body>{x.body}</Toast.Body>
            </Toast>
          ))}
        </div>
      </ToastContainer>
    </ToastContext.Provider>
  );
}
