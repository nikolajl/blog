import { Pagination as BootstrapPagination } from 'react-bootstrap';

type Props = {
  pageSize: number;
  totalCount?: number;
  pageNumber: number;
  hasNextPage?: boolean;
  setPageNumber: (pageNumber: number) => void;
};

export default function Pagination(props: Props) {
  const { pageNumber, pageSize, setPageNumber, totalCount, hasNextPage } = props;

  let pageCount = 1;
  if (totalCount) {
    pageCount = Math.ceil(totalCount / pageSize);
  } else if (hasNextPage) {
    pageCount = pageNumber + 1;
  } else {
    pageCount = pageNumber;
  }

  const pagination: JSX.Element[] = [];

  for (let i = Math.max(pageNumber - 2, 1); i <= Math.min(pageNumber + 2, pageCount); i++) {
    pagination.push(
      <BootstrapPagination.Item key={i} active={i === pageNumber} onClick={() => setPageNumber(i)}>
        {i}
      </BootstrapPagination.Item>
    );
  }

  return (
    <BootstrapPagination>
      <BootstrapPagination.First disabled={pageNumber <= 1} onClick={() => setPageNumber(1)} />
      <BootstrapPagination.Prev
        disabled={pageNumber <= 1}
        onClick={() => setPageNumber(pageNumber - 1)}
      />
      {pagination}
      <BootstrapPagination.Next
        disabled={pageNumber >= (pageCount ?? 1)}
        onClick={() => setPageNumber(pageNumber + 1)}
      />
      <BootstrapPagination.Last
        disabled={pageNumber >= (pageCount ?? 1)}
        onClick={() => setPageNumber(pageCount ?? 1)}
      />
    </BootstrapPagination>
  );
}
