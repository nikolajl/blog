import cx from 'classnames';
import styles from './Footer.module.scss';

export default function Footer() {
  return (
    <footer className={cx('text-center', styles.footer)}>
      <p>Kundeoverblik © 2022 JP/Politikens Hus - Jp-afdeling</p>
    </footer>
  );
}
