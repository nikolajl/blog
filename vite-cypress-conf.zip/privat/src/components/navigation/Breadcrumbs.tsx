import { useSsoUser } from '@/api/customer';
import { useMatch } from '@tanstack/react-location';
import { Breadcrumb } from 'react-bootstrap';
import styles from './Breadcrumbs.module.css';

export type Crumb = {
  title: string;
  href: string;
};

type Props = {
  title: string;
  crumbs?: Crumb[];
};
export default function Breadcrumbs({ title, crumbs = [] }: Props) {
  const {
    params: { ssoId },
  } = useMatch();

  const { data } = useSsoUser(ssoId);
  const email = data?.email;

  return (
    <Breadcrumb>
      <Breadcrumb.Item className={styles.link} href="/">
        Kundeoverblik
      </Breadcrumb.Item>
      {ssoId && (
        <Breadcrumb.Item className={styles.link} href={`/Customer/ViewCustomer/${ssoId}`}>
          {email || ssoId}
        </Breadcrumb.Item>
      )}
      {crumbs.map((a) => (
        <Breadcrumb.Item className={styles.link} href={a.href} key={a.href}>
          {a.title}
        </Breadcrumb.Item>
      ))}
      <Breadcrumb.Item className={styles.link} active>
        {title}
      </Breadcrumb.Item>
    </Breadcrumb>
  );
}
