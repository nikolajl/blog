import { useSetTenantMutation, useUser } from '@/api/user';
import { Badge, Container, Nav, Navbar, NavDropdown } from 'react-bootstrap';
import { FaRegUser, FaServer, FaSignOutAlt } from 'react-icons/fa';
import cx from 'classnames';
import styles from './Header.module.css';
import { useRecent } from '@/api/search';
import { formatDate } from '@/utils/format';

export default function Header() {
  const { mutate } = useSetTenantMutation();
  const user = useUser();
  const recent = useRecent();
  const tenant = user.data?.selectedTenant.name || 'Jp';

  const switchTenant = (key: string) => {
    if (window.location.hostname === 'localhost') {
      mutate(key);
    } else {
      window.location.assign(
        window.location
          .toString()
          .replace(
            `${tenant}-kundeoverblik.jppol.dk`.toLowerCase(),
            `${key}-kundeoverblik.jppol.dk`.toLowerCase()
          )
      );
    }
  };

  return (
    <Navbar bg="dark" variant="dark" className={cx(styles.navbar, styles[`tenant-${tenant}`])}>
      <Container>
        <Navbar.Brand href="/">
          <img src={`/images/logos/logo${tenant}.png`} height="25" width="25" alt={tenant} />
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <NavDropdown title="Statusoversigter">
              <NavDropdown.Item href="/SubscriptionOrders/OrdersSummary">
                Ordreoversigt
              </NavDropdown.Item>
              <NavDropdown.Item href="/Invoice/InvoiceOverview">Fakturaoversigt</NavDropdown.Item>
              <NavDropdown.Item href="/Invoice/RvsInvoiceOverview">RVS-oversigt</NavDropdown.Item>
              <NavDropdown.Item href="/TIM/TimSalesSummary">Telesalg</NavDropdown.Item>
              {user.data?.flags['EasyRefund'] && (
                <NavDropdown.Item href="/refund-orders">Refusion oversigt</NavDropdown.Item>
              )}
            </NavDropdown>
            {user.data?.flags['SpaNewCustomer'] && (
              <Nav.Link href="/purchase-subscription">Ny kunde</Nav.Link>
            )}
            <Nav.Link href="/Customer/NewCustomer">(Tidligere) Ny kunde</Nav.Link>
          </Nav>
          <Nav>
            {recent.data && (
              <NavDropdown
                title={
                  <>
                    <span>Seneste indlæste kunder</span>
                    <Badge pill bg="secondary" className="ms-1">
                      {recent.data?.length ?? '...'}
                    </Badge>
                  </>
                }>
                {recent.data?.map(({ ssoId, displayName, loadedAt }) => (
                  <NavDropdown.Item key={ssoId} href={`/Customer/SearchResults?input=${ssoId}`}>
                    <b>{displayName}</b>
                    <span className="text-muted fst-italic ms-1">
                      {formatDate(loadedAt, 'HH:mm')}
                    </span>
                  </NavDropdown.Item>
                ))}
              </NavDropdown>
            )}
            <NavDropdown
              title={
                <>
                  <FaRegUser /> {user.data?.user}
                </>
              }>
              {user.data?.tenants.map((x) => (
                <NavDropdown.Item key={x.key} onClick={() => switchTenant(x.key)}>
                  {x.name}
                </NavDropdown.Item>
              ))}
              <NavDropdown.Divider />
              <NavDropdown.Item href="/System/Info">
                <FaServer /> System info
              </NavDropdown.Item>
              <NavDropdown.Item href="/System/Signout">
                <FaSignOutAlt /> Log ud
              </NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}
