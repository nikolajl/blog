import { AuthContext, useAuthContext } from '../providers/AuthProvider';

type Props = {
  allow: (context: AuthContext) => boolean;
  children: JSX.Element;
  message?: string;
};

export default function Guard({ allow, children, message }: Props) {
  const context = useAuthContext();
  if (!context) {
    return null;
  }

  if (allow(context)) {
    return children;
  }

  // TODO: Create pretty 403 forbidden page
  if (message) return <h1>{message}</h1>;
  return <h1>Not allowed</h1>;
}
