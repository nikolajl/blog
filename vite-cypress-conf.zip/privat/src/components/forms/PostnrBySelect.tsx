import { DistributionAddress } from '@/api/types/distribution';
import { useLookupAddress } from '@/api/distribution';
import { useState } from 'react';
import Select from 'react-select';
import styles from './Select.module.scss';
import cx from 'classnames';
import { get, useFormContext } from 'react-hook-form';

type Props = {
  label?: string;
  onChange: (value: DistributionAddress | null) => void;
  required?: boolean;
  name: string;
};

export default function PostnrBySelect({ name, required, label = '', onChange }: Props) {
  const [selected, setSelected] = useState<DistributionAddress | null>();
  const { data } = useLookupAddress();
  const { formState } = useFormContext();
  const invalid = get(formState.errors, name) !== undefined;
  return (
    <Select
      className={cx(
        {
          required,
        },
        { invalid: invalid },
        styles.bstBorder
      )}
      isClearable
      placeholder={label}
      isLoading={!data}
      options={data ?? []}
      onChange={(value) => {
        setSelected(value);
        onChange(value);
      }}
      value={selected}
      noOptionsMessage={() => 'Ingen resultater'}
      getOptionLabel={(address) => `${address.zipCode} ${address.postalDistrict}`}
      getOptionValue={(address) => `${address.zipCode} ${address.postalDistrict}`}
    />
  );
}
