import da from 'date-fns/locale/da';
import { Form, FormControlProps } from 'react-bootstrap';
import DatePicker, {
  ReactDatePickerProps,
  registerLocale,
  setDefaultLocale,
} from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { FaCalendarDay } from 'react-icons/fa';

registerLocale('da', da);
setDefaultLocale('da');

type Props = ReactDatePickerProps & Pick<FormControlProps, 'size'> & { isInvalid?: boolean };

/**
 * Controlled DatePicker component served as React-bootstrap Form.Control
 */
export default function FormDate({ size, isInvalid, ...props }: Props) {
  return (
    <div className="position-relative d-inline-block">
      <DatePicker
        {...props}
        dateFormat="dd-MM-yyyy"
        customInput={<Form.Control type="text" size={size} isInvalid={isInvalid} />}
      />
      <FaCalendarDay className="position-absolute top-50 end-0 translate-middle-y me-2" />
    </div>
  );
}
