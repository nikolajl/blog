import { useAutoCompleteAddresses, DawaAutoCompleteResult } from '@/api/dawa';
import { useState } from 'react';
import Select, { StylesConfig } from 'react-select';
import cx from 'classnames';
import { get, useFormContext } from 'react-hook-form';
import styles from './Select.module.scss';

type Props = {
  label?: string;
  onChange: (value: DawaAutoCompleteResult | null) => void;
  required?: boolean;
  name: string;
};

export default function AddressSelect({ name, required, label = '', onChange }: Props) {
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<DawaAutoCompleteResult | null>();

  const { data } = useAutoCompleteAddresses(query);

  const { formState } = useFormContext();
  const error = get(formState.errors, name);
  const invalid = error !== undefined;

  const customStyle: StylesConfig<DawaAutoCompleteResult, false> = {
    control: (provided) => ({
      ...provided,
      borderRadius: '3px',
    }),
  };

  return (
    <Select
      className={cx(
        {
          required,
        },
        'dawa-autocomplete',
        'react-select',
        { invalid: invalid },
        styles.bstBorder
      )}
      isClearable
      styles={customStyle}
      placeholder={label}
      options={data ?? []}
      onChange={(value) => {
        setSelected(value);

        onChange(value);
      }}
      onInputChange={(value, event) => {
        if (event.action === 'input-change') {
          if (value === '') {
            setSelected(null);
          }
        }
        setQuery(value);
      }}
      onBlur={() => !selected && onChange(null)}
      noOptionsMessage={() => 'Ingen resultater'}
      filterOption={() => true}
      onMenuOpen={() => selected && setQuery(selected.forslagstekst)}
      inputValue={query}
      value={selected}
      getOptionLabel={(address) => address?.forslagstekst ?? ''}
      getOptionValue={(address) => address?.forslagstekst ?? ''}
    />
  );
}
