import { Form } from 'react-bootstrap';
import { useFormContext, get } from 'react-hook-form';

type Radio = {
  id?: string;
  value: string | number;
  label: string;
  disabled?: boolean;
};

type Props = {
  name: string;
  options: Radio[];
};

export default function InputRadioGroup({ name, options }: Props) {
  const form = useFormContext();
  const error = get(form.formState.errors, name);
  return (
    <Form.Group>
      {options.map((x, i) => (
        <Form.Check
          key={i}
          id={x.id ? x.id : `${name}-${i}`}
          type="radio"
          {...x}
          {...form.register(name)}
        />
      ))}
      <Form.Text>{error?.message?.toString()}</Form.Text>
    </Form.Group>
  );
}
