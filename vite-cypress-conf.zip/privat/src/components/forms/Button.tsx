import { Button as BootstrapButton, ButtonProps, Spinner } from 'react-bootstrap';

type Props = ButtonProps & {
  loading?: boolean;
  animation?: 'border' | 'grow';
};

export default function Button({ variant = 'primary', loading = false, children, ...rest }: Props) {
  return (
    <BootstrapButton {...rest} variant={variant}>
      {loading ? (
        <Spinner
          style={{ marginRight: '0.5rem' }}
          as="span"
          animation="border"
          size="sm"
          role="status"
          aria-hidden="true"
        />
      ) : null}
      {children}
    </BootstrapButton>
  );
}
