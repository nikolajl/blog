import { DistributionCountry } from '@/api/types/distribution';
import { useGetCountries } from '@/api/distribution';
import { useState } from 'react';
import Select from 'react-select';
import styles from './Select.module.scss';
import { get, useFormContext } from 'react-hook-form';
import cx from 'classnames';

type Props = {
  label?: string;
  required?: boolean;
  name: string;
};

export default function CountriesSelect({ name, required = false, label = '' }: Props) {
  const [selected, setSelected] = useState<DistributionCountry | null>();
  // const form = useFormContext();
  const { formState, register, setValue } = useFormContext();
  const error = get(formState.errors, name);

  const { data } = useGetCountries();

  const invalid = error !== undefined;

  register(name);

  return (
    <Select
      className={cx(
        { required },
        styles.bstBorder,
        {
          invalid: invalid,
        },
        'countries-select'
      )}
      isClearable
      placeholder={label}
      isLoading={!data}
      options={data ?? []}
      onChange={(value) => {
        setSelected(value);
        setValue(name, value ? value.isoCodeA2 : null, { shouldValidate: true });
      }}
      value={selected}
      noOptionsMessage={() => 'Ingen resultater'}
      getOptionLabel={(country) => country.nameDk}
      getOptionValue={(country) => country.nameDk}
    />
  );
}
