import { Form, FormControlProps, InputGroup } from 'react-bootstrap';
import NumberFormat, { NumberFormatValues } from 'react-number-format';

type Props = Pick<FormControlProps, 'size' | 'disabled' | 'isInvalid'> & {
  dataCy?: string;
  value: number | undefined;
  onChange: (value: number | undefined) => void;
  currency?: 'DKK' | 'NOK' | 'EUR';
};

export const currencyMap = {
  DKK: { display: 'kr.' },
  NOK: { display: 'nok.' },
  EUR: { display: '€' },
};

export default function CurrencyInput({
  dataCy,
  value,
  onChange,
  disabled,
  isInvalid,
  size = 'sm',
  currency = 'DKK',
}: Props) {
  return (
    <InputGroup>
      <InputGroup.Text>{currencyMap[currency].display}</InputGroup.Text>
      <Form.Control
        data-cy={dataCy}
        style={{ textAlign: 'right' }}
        size={size}
        as={NumberFormat}
        thousandSeparator="."
        decimalSeparator=","
        decimalScale={2}
        value={value}
        onValueChange={(values: NumberFormatValues) => {
          onChange(values.floatValue);
        }}
        disabled={disabled}
        isInvalid={isInvalid}
      />
    </InputGroup>
  );
}
