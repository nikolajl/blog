import { FormControl, FormControlProps, FormText, InputGroup } from 'react-bootstrap';
import { useFormContext, get } from 'react-hook-form';
import cx from 'classnames';

type Props = FormControlProps & {
  name: string;
  label?: string;
  maxLength?: number;
  required?: boolean;
  min?: number;
  unit?: string;
};

export function InputText({ name, label, required, type = 'text', ...props }: Props) {
  const form = useFormContext();
  const error = get(form.formState.errors, name);
  const isInvalid = error !== undefined;

  return (
    <>
      <InputGroup>
        <FormControl
          type={type}
          className={cx({
            required,
          })}
          autoComplete="autocomplete_off_hack_xfr4!k"
          placeholder={label}
          {...form.register(name)}
          isInvalid={isInvalid}
          {...props}
        />
      </InputGroup>
      {error?.message && <FormText>{error.message.toString()}</FormText>}
    </>
  );
}
