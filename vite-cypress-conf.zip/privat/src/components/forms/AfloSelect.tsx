import { useGetAfloCodes } from '@/api/distribution';
import { AfloCode } from '@/api/types/distribution';
import { useState } from 'react';
import { FormControl } from 'react-bootstrap';
import styles from './Select.module.scss';
import { get, useFormContext } from 'react-hook-form';
import Select from 'react-select';
import cx from 'classnames';

type Props = {
  name: string;
  required?: boolean;
};
export default function AfloSelect({ name, required }: Props) {
  const { data } = useGetAfloCodes();

  const { formState, register, setValue } = useFormContext();
  const invalid = get(formState.errors, name) !== undefined;

  const [selected, setSelected] = useState<AfloCode | null>();

  register(name);
  return (
    <>
      <Select
        className={cx({ required }, invalid ? styles.invalid : null, styles.bstBorder)}
        placeholder="Vælg AFLO"
        options={data ?? []}
        onChange={(value) => {
          setSelected(value);
          setValue(name, value?.code);
          if (value?.userFreeText === 'Y') {
            setValue('deliveryAddress.afloText', null, { shouldValidate: true });
          }
        }}
        value={selected}
        getOptionLabel={(aflocode) => {
          return `${aflocode.code} - ${aflocode.text !== '' ? aflocode.text : 'Fritekst'}`;
        }}
        getOptionValue={(aflocode) => {
          return `${aflocode.code} - ${aflocode.text !== '' ? aflocode.text : 'Fritekst'}`;
        }}
      />
      {selected && selected.userFreeText === 'Y' && (
        <FormControl
          className="mt-1"
          as="textarea"
          placeholder="fritekst..."
          {...register('deliveryAddress.afloText', { value: '', shouldUnregister: true })}
        />
      )}
    </>
  );
}
