import { Outlet, ReactLocation, Router } from '@tanstack/react-location';
import ReactDOM from 'react-dom/client';
import './global.scss';

import Header from '@/components/navigation/Header';
import routes from '@/pages/routes';
import AuthProvider from '@/components/providers/AuthProvider';
import ModalProvider from './components/providers/ModalProvider';
import { GlobalHotKeys } from 'react-hotkeys';
import ReactQueryProvider from './components/providers/ReactQueryProvider';
import ToastProvider from './components/messages/ToastProvider';

// All common, global shared shortcuts here:
//const KeyboardShortcuts: KeyBinding[] = [{ key: 'n', fkey: 'alt', action: 'HOME' }];

function App() {
  const location = new ReactLocation();

  const keyMap = {
    HOME: 'Alt+n',
  };
  const hotkeyHandlers = {
    HOME: () => window.location.assign('/'),
  };

  return (
    <ToastProvider>
      <ReactQueryProvider>
        <Router location={location} routes={routes}>
          <GlobalHotKeys keyMap={keyMap} handlers={hotkeyHandlers} />
          <AuthProvider>
            <ModalProvider>
              <Header />
              <Outlet />
            </ModalProvider>
          </AuthProvider>
        </Router>
      </ReactQueryProvider>
    </ToastProvider>
  );
}

const element = document.getElementById('root');
if (element) {
  ReactDOM.createRoot(element).render(<App />);
}
